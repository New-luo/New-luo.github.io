import request from '../../utils/request'

export function pay_the_fees_finance(params){
    return request({
        url: '/open-finance/pay_the_fees-finance',
        method: 'post',
        params
    })
}