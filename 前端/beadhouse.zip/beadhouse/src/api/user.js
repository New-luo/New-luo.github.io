import request from '../utils/request'
//新增.修改
export function add(data) {
    return request({
      url: 'user/uploadPic',
      method: 'post',
      data,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  }


//修改个人密码
export function getpassword(data) {
    return request({
      url: 'user/getpassword',
      method: 'post',
      data
    });
  }

  export function password(data) {
    return request({
      url: 'user/password',
      method: 'post',
      data
    });
  }


//列表
export function list(data){
    return request({
        url:'user/fy',
        method:'post',
        data
    })
}

//搜索条件自动
export function zd(data){
    return request({
        url:'user/zd',
        method:'post',
        data
    })
}


//删除
export function del(id){
    return request({
        url:'user/del/'+id,
        method:'get'
    })
}
//查询对应id渲染修改页
export function getid(id){
    return request({
        url:'user/update/'+id,
        method:'get'
    })
}



//状态
export function changeStatus(id,status){
    return request({
        url:'user/status/'+ id + '/' + status,
        method:'get'
    })
}


export function initPwd(id){
    return request({
        url:'api/sysUser/initPwd/'+id,
        method:'get'
    })
}

export function changePwd(data){
    return request({
        url:'api/sysUser/changePwd',
        method:'post',
        data
    })
}

export function list2(data){
    return request({
        url:'roleController/list2',
        method:'post',
        data
    })
}