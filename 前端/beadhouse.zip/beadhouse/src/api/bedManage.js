import request from '../utils/request'

export function selectPage(params){
    console.log(params)
    return request({
        url: '/open-bed/selectPage-bed',
        method: 'post',
        params
    })
}