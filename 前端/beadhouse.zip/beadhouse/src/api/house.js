import request from '../utils/request'

export function list(params){
    return request({
        url: 'house/init',
        method: 'post',
        params
    })
}
export function insert(params){
    return request({
        url: 'house/insert',
        method: 'post',
        params
    })
}
export function update(params){
    return request({
        url: 'house/update',
        method: 'post',
        params
    })
}
export function del(params){
    return request({
        url: 'house/del/' + params,
        method: 'get'
    })
}