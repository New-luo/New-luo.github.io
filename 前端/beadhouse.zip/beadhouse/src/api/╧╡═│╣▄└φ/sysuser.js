// api/系统管理/sysuser.js

import request from '../../utils/request'

// 列表
export function list(data) {
  return request({
    url: '/sysuser/list', // 更新为正确的后端接口地址
    method: 'post', // 根据后端接口定义的方式，可能需要调整为 'get' 或其他方法
    data
  })
}

export function search(data) {
  return request({
    url: '/sysuser/search', // 更新为正确的后端接口地址
    method: 'get', // 根据后端接口定义的方式，可能需要调整为 'get' 或其他方法
    data
  })
}
