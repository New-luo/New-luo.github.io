import request from '../utils/request'

export function add(data) {
    return request({
      url: 'Stayinfo/add',
      method: 'post',
      data
    });
  }


//列表
export function list(data){
    return request({
        url:'/Stayinfo/fy',
        method:'post',
        data
    })
}

// //搜索条件自动
export function zd(data){
    return request({
        url:'Stayinfo/zd',
        method:'post',
        data
    })
}


//删除
export function del(stayId){
    return request({
        url:'Stayinfo/del/'+stayId,
        method:'get'
    })
}

//查询对应id渲染修改页

export function getid(stayId){
    return request({
        url:'Stayinfo/getid/'+stayId, 
        method:'get'
    })
}