//药品订单信息
import request from '../../utils/request'

export function add(data) {
    return request({
      url: 'Ord/get',
      method: 'post',
      data
    });
  }
  export function add1(data) {
    return request({
      url: 'Ord/get',
      method: 'post',
      data
    });
  }

