//物品订单信息
import request from '../../utils/request'

export function add(data) {
    return request({
      url: 'Orders/get',
      method: 'post',
      data
    });
  }
  export function list(data) {
    return request({
      url: 'Cords/list',
      method: 'post',
      data
    });
  }
  export function list2(data) {
    return request({
      url: 'Cords/list2',
      method: 'post',
      data
    });
  }

  //删除订单
  export function del(id){
    return request({
        url:'Cords/del/'+id,
        method:'get'
    })
  }
  //删除订单
  export function del2(id){
    return request({
        url:'Cords/del2/'+id,
        method:'get'
    })
  }
  
//查询对应订单id入库
export function getid(id){
  return request({
      url:'Cords/getid/'+id,
      method:'get'
  })
  
}
