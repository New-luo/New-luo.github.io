//药品信息
import request from '../../utils/request'
// //新增.修改
export function add(data) {
    return request({
      url: 'Product/add',
      method: 'post',
      data,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  }

//列表
export function list(data){
    return request({
        url:'Product/fy',
        method:'post',
        data
    })
}

//搜索条件自动
export function zd(data){
    return request({
        url:'Product/zd',
        method:'post',
        data
    })
}


//删除
export function del(ProductID){
    return request({
        url:'Product/del/'+ProductID,
        method:'get'
    })
}

//查询对应id渲染修改页

export function getid(ProductID){
    return request({
        url:'Product/getid/'+ProductID,
        method:'get'
    })
}

export function fp() {
    return request({
      url: 'Product/fp',
      method: 'post',
    });
  }
