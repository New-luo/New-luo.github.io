//药品订单信息
import request from '../../utils/request'
//订单列表
export function list(data) {
    return request({
      url: 'Cord/list',
      method: 'post',
      data
    });
  }

  export function list2(data) {
    return request({
      url: 'Cord/list2',
      method: 'post',
      data
    });
  }


//删除订单
export function del(id){
  return request({
      url:'Cord/del/'+id,
      method:'get'
  })
}
export function del2(id){
  return request({
      url:'Cord/del2/'+id,
      method:'get'
  })
}
//查询对应订单id入库
export function getid(id){
  return request({
      url:'Cord/getid/'+id,
      method:'get'
  })
  }
//查询仓库药品信息
export function DetailsList(data) {
  return request({
    url: 'Details/list',
    method: 'post',
    data
  })
  }

  export function DetailsList2(data) {
    return request({
      url: 'Details/list2',
      method: 'post',
      data
    })
    }
  


  export function add(data) {
    return request({
      url: 'Details/get',
      method: 'post',
      data
    });
  }

  export function adds(data) {
    return request({
      url: 'Details/gets',
      method: 'post',
      data
    });
  }


  
  export function updates(data) {
    return request({
      url: 'Details/updates',
      method: 'post',
      data
    });
  }

  export function update(data) {
    return request({
      url: 'Details/update',
      method: 'post',
      data
    });
  }


  export function fp() {
    return request({
      url: 'Details/fp',
      method: 'post',
    });
  }
