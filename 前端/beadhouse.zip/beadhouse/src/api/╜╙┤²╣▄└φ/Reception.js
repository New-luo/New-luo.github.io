//接待登记
import request from '../../utils/request'
// //新增.修改
export function add(data) {
    return request({
      url: 'Reception/add',
      method: 'post',
      data
    });
  }


//列表
export function list(data){
    return request({
        url:'Reception/fy',
        method:'post',
        data
    })
}

// //搜索条件自动
export function zd(data){
    return request({
        url:'Reception/zd',
        method:'post',
        data
    })
}


//删除
export function del(manualRecordId){
    return request({
        url:'Reception/del/'+manualRecordId,
        method:'get'
    })
}

//查询对应id渲染修改页

export function getid(manualRecordId){
    return request({
        url:'Reception/getid/'+manualRecordId,
        method:'get'
    })
}



// //状态
// export function changeStatus(id,status){
//     return request({
//         url:'upload/status/'+ id + '/' + status,
//         method:'get'
//     })
// }


// export function initPwd(id){
//     return request({
//         url:'api/sysUser/initPwd/'+id,
//         method:'get'
//     })
// }

// export function changePwd(data){
//     return request({
//         url:'api/sysUser/changePwd',
//         method:'post',
//         data
//     })
// }