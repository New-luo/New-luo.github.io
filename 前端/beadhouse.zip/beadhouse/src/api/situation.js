import request from '../utils/request'

export function add(data){
    return request({
        url:'situation/add',
        method:'post',
        data
    })
}

export function list(data){
    return request({
        url:'situation/list',
        method:'post',
        data
    })
}

export function del(id){
    return request({
        url:'situation/del/'+id,
        method:'get'
    })
}

export function getId(id){
    return request({
        url:'situation/getId/'+id,
        method:'get'
    })
}