import request from '../../utils/request'

export function add(data) {
    return request({
      url: 'storage/add',
      method: 'post',
      data
    });
  }


//列表
export function list(data){
    return request({
        url:'/storage/fy',
        method:'post',
        data
    })
}

// //搜索条件自动
export function zd(data){
    return request({
        url:'storage/zd',
        method:'post',
        data
    })
}


//删除
export function del(storageId){
    return request({
        url:'storage/del/'+storageId,
        method:'get'
    })
}

//查询对应id渲染修改页

export function getid(storageId){
    return request({
        url:'storage/getid/'+storageId, 
        method:'get'
    })
}