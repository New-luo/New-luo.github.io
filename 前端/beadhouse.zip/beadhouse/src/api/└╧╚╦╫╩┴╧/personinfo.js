import request from '../../utils/request'

export function add(data) {
    return request({
      url: '/open-personinfo/Add-personinfo',
      method: 'post',
      data
    });
  }

export function Update(params){
    return request({
        url: '/open-personinfo/Update-personinfo',
        method: 'post',
        params
    })
}

export function selectPage(params){
    return request({
        url: '/open-personinfo/selectPage',
        method: 'post',
        params
    })
}

export function getId(params){
    return request({
        url:'/open-personinfo/getId',
        method:'post',
        params
    })
}

//列表
export function list(data){
    return request({
        url:'/personinfo/fy',
        method:'post',
        data
    })
}

// //搜索条件自动
export function zd(data){
    return request({
        url:'personinfo/zd',
        method:'post',
        data
    })
}


//删除
export function del(PersonId){
    return request({
        url:'personinfo/del/'+PersonId,
        method:'get'
    })
}

export function get_item_excepts(params){
    return request({
        url: '/open-personinfo/get-item_excepts',
        method: 'post',
        params
    })
}

export function item_excepts_get(params){
    return request({
        url: '/open-personinfo/update_item_excepts_state1',
        method: 'post',
        params
    })
}

export function item_excepts_deleteBatch(params){
    return request({
        url: '/open-personinfo/item_excepts_deleteBatch',
        method: 'post',
        params
    })
}

export function item_Excepts_cancellation(params){
    return request({
        url: '/open-personinfo/item_Excepts_cancellation',
        method: 'post',
        params
    })
}

export function to_update_face(params){
    return request({
        url: '/open-personinfo/to_update_face/to_update_face',
        method: 'post',
        params
    })
}