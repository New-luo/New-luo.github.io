import request from '../utils/request'


export function add(data){
    return request({
        url:'housepic/add',
        method: 'post',
        data
    })
}

export function list(data){
    return request({
        url: 'housepic/list',
        method:'post',
        data
    })
}

export function del(id){
    return request({
        url:'housepic/del/'+id,
        method:'get'
    })
}

export function getId(id){
    return request({
        url:'housepic/getId/'+id,
        method:'get'
    })
}