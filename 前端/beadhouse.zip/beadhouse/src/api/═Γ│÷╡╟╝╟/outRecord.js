import request from '../../utils/request'

export function listPage(params){
    return request({
        url: '/open-outRecord/selectPage-outRecord',
        method: 'post',
        params
    })
}

export function listPage2(params){
    return request({
        url: '/open-outRecord/selectPage2-outRecord',
        method: 'post',
        params
    })
}

export function Add(params){
    return request({
        url: '/open-outRecord/Add-outRecord',
        method: 'post',
        params
    })
}

export function selectById(params){
    return request({
        url: '/open-outRecord/getId-outRecord',
        method: 'post',
        params
    })
}

export function UpdateOutRecord(params){
    return request({
        url: '/open-outRecord/Update-outRecord',
        method: 'post',
        params
    })
}

export function daleteOutRecord(params){
    return request({
        url: '/open-outRecord/getId-outRecord',
        method: 'post',
        params
    })
}