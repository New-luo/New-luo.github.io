import request from '../../utils/request'

export function logins(params){
    return request({
        url: '/open-outRecord/Login-outRecord',
        method: 'post',
        params
    })
}