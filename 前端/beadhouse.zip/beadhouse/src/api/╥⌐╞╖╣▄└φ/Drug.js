//药品信息
import request from '../../utils/request'
// //新增.修改
export function add(data) {
    return request({
      url: 'Drug/add',
      method: 'post',
      data,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  }
//列表
export function list(data){
    return request({
        url:'Drug/fy',
        method:'post',
        data
    })
}

//搜索条件自动
export function zd(data){
    return request({
        url:'Drug/zd',
        method:'post',
        data
    })
}


//删除
export function del(DrugID){
    return request({
        url:'Drug/del/'+DrugID,
        method:'get'
    })
}

//查询对应id渲染修改页

export function getid(DrugID){
    return request({
        url:'Drug/getid/'+DrugID,
        method:'get'
    })
}



