import request from '../../utils/request'

export function add(data) {
    return request({
      url: '/drugs/add',
      method: 'post',
      data
    });
  }


//列表
export function list(data){
    return request({
        url:'/drugs/fy',
        method:'post',
        data
    })
}

// //搜索条件自动
export function zd(data){
    return request({
        url:'drugs/zd',
        method:'post',
        data
    })
}


//删除
export function del(drugsId){
    return request({
        url:'drugs/del/'+drugsId,
        method:'get'
    })
}

//查询对应id渲染修改页

export function getid(drugsId){
    return request({
        url:'drugs/getid/'+drugsId, 
        method:'get'
    })
}