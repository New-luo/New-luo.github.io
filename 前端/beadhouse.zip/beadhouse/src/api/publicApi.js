import request from '../utils/request'

export function list(params,url){
    return request({
        url: '/' + url,
        method: 'post',
        params
    })
}
export function insert(params,url){
    return request({
        url: '/' + url,
        method: 'post',
        params
    })
}
export function update(params,url){
    return request({
        url: '/' + url,
        method: 'post',
        params
    })
}
export function del(params,url){
    return request({
        url: '/'+ url + '/' + params,
        method: 'get'
    })
}

// 测试请求
export function test(params,url){
    return request({
        url: url,
        method: 'post',
        params
    })
}