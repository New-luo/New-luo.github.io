import Vue from 'vue'
/**
 * VUE自定义权限指令
 * @auth or tjh
 * @desc 功能权限判断-可以移除和禁用 目前只启用禁用
 * @use v-permission = "'action:add'"
 * @see https://cn.vuejs.org/v2/guide/custom-directive.html
 */
Vue.directive('permission', {
  inserted(el, binding) {
    const perms = JSON.parse(window.sessionStorage.getItem('perms') || '[]');

    if (perms && !perms.includes(binding.value)) {
      // 隐藏其他控件
      if (el.tagName !== 'BUTTON') {
        el.style.display = 'none';
      }
      
      // 禁用按钮
      if (el.tagName === 'BUTTON') {
        el.disabled = true;
        el.classList.add('is-disabled');
      }
    }
  }
})
// eslint-disable-next-line no-extend-native
Array.prototype.contains = function (val) {
  return this.indexOf(val) !== -1
}
