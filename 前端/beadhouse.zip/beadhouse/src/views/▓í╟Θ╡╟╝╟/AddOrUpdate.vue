<template>
    <el-dialog
        :title="dataForm.situationId>0?'修改':'新增'"
        :visible.sync="dialogVisible"
        width="30%"
        height="400"
        :close-on-click-modal="false"
        :before-close="handleClose"
    >
        <el-form :model="dataForm" ref="dataForm" :rules="dataRule" inline label-width="100px"  @keyup.enter.native="saveOrUpdate()">
            <el-row>
                <el-col :span="24">
                    <el-form-item prop="personId" label="人员ID:">
                        <el-input v-model="dataForm.personId" v-if="dataForm.situationId > 0" style="width:215px" :disabled="true"/>

                        <el-select v-model="selectedPersonId" v-if="dataForm.situationId===0" style="width:215px" clearable filterable>
                            <el-option v-for="(item, index) in personinfoList" :key="index.personId" :value="item.personId" :label="item.personId"/>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item prop="realName" label="老人姓名:">
                        <el-input v-model="dataForm.realName" v-if="dataForm.situationId > 0" style="width:215px" :disabled="true"/>

                        <el-input v-model="dataForm.realName" v-if="dataForm.situationId===0" style="width:215px" placeholder="请输入老人姓名"/>

                        <!-- <el-select v-model="dataForm.realName" v-if="dataForm.situationId===0" style="width:215px" clearable filterable>
                            <el-option v-for="(rn, rns) in personinfoList" :key="rns.realName" :value="rn.realName" :label="rn.realName"/>
                        </el-select> -->
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item prop="relativeName" label="亲属姓名:">
                        <el-input v-model="dataForm.relativeName" v-if="dataForm.situationId > 0" style="width:215px" :disabled="true"/>

                        <el-input v-model="dataForm.relativeName" v-if="dataForm.situationId===0" style="width:215px" placeholder="请输入亲属姓名"/>
                            
                        <!-- <el-select v-model="dataForm.relativeName" v-if="dataForm.situationId===0" style="width:215px" clearable filterable>
                            <el-option v-for="(rln, rlns) in relativeList" :key="rlns.relativeName" :value="rln.relativeName" :label="rln.relativeName"/>
                        </el-select> -->
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item prop="mobile" label="亲属电话:">
                        <el-input v-model="dataForm.mobile" v-if="dataForm.situationId > 0" style="width:215px" :disabled="true"/>
                        <el-input v-model="dataForm.mobile" v-if="dataForm.situationId===0" style="width:215px" placeholder="请输入亲属电话"/>
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item prop="illDate" label="生病时间:">
                        <el-date-picker
                        v-model="dataForm.illDate"
                        type="datetime"
                        placeholder="请选择日期时间"
                        style="width:215px">
                        </el-date-picker>
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item prop="reason" label="病情原因:">
                        <el-input v-model="dataForm.reason" style="width:215px" placeholder="请输入病情原因"/>
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item prop="remark" label="处理结果:">
                        <el-input v-model="dataForm.remark" style="width:215px" placeholder="请输入处理结果"/>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button @click="dialogVisible = false">取消</el-button>
            <el-button type="primary" @click="saveOrUpdate()">保存</el-button>
        </span>
    </el-dialog>
</template>
<script>
    import {add,getId} from '../../api/situation'
    import moment from 'moment'

    export default({
        name:'Situation_',
        data(){
            return{
                
                dataForm:{
                    situationId:0,
                    personId:'',
                    realName:'',
                    relativeName:'',
                    mobile:'',
                    illDate:'',
                    reason:'',
                    remark:''
                },
                selectedPersonId: '',
                situationList:[],
                personinfoList:[],
                relativeList:[],
                dialogVisible:false,
                dataRule:{
                    personId:[
                        {required: true, message: '人员ID不能为空', trigger: 'blur'}
                    ],
                    realName:[
                        {required: true, message: '老人姓名不能为空', trigger: 'blur'}
                    ],
                    relativeName:[
                        {required: true, message: '亲属姓名不能为空', trigger: 'blur'}
                    ],
                    mobile:[
                        {required: true, message: '亲属电话不能为空', trigger: 'blur'},
                        { min: 8, max:20,message: '亲属电话必须在8~20位之间', trigger: 'blur' }  
                    ],
                    illDate:[
                        {required: true, message: '生病时间不能为空', trigger: 'blur'}
                    ],
                    reason:[
                        {required: true, message: '病情原因不能为空', trigger: 'blur'}
                    ],
                    remark:[
                        {required: true, message: '处理结果不能为空', trigger: 'blur'}
                    ],
                }
            }
        },
        watch: {
            selectedPersonId(newVal) {
                // 根据选择的人员ID更新其他字段的值
                const selectedPerson = this.personinfoList.find(item => item.personId === newVal);
                const selectedPersons = this.relativeList.find(item => item.personId === newVal);
                if (selectedPerson) {
                    this.dataForm.realName = selectedPerson.realName;
                }
                if(selectedPersons){
                    this.dataForm.relativeName = selectedPersons.relativeName;
                    this.dataForm.mobile = selectedPersons.mobile;
                }
            },
        },
        methods:{
            init(situationId){
                this.dataForm.situationId = situationId
                this.dialogVisible=true
                getId(situationId).then(res => {
                    this.personinfoList = res.data.personinfoList
                    this.relativeList = res.data.relativeList
                    if(situationId>0){
                        this.dataForm.situationId = res.data.situation.situationId
                        this.dataForm.personId = res.data.situation.personId
                        this.dataForm.realName = res.data.situation.realName
                        this.dataForm.relativeName = res.data.situation.relativeName
                        this.dataForm.mobile = res.data.situation.mobile
                        if (res.data.situation.illDate) {
                            const date = new Date(res.data.situation.illDate);
                            this.dataForm.illDate = date
                        }
                        this.dataForm.reason = res.data.situation.reason
                        this.dataForm.remark = res.data.situation.remark
                    }
                    if(situationId===0){
                        this.dataForm.situationId = 0
                        this.dataForm.personId = ''
                        this.dataForm.realName = ''
                        this.dataForm.relativeName = ''
                        this.dataForm.mobile = ''
                        this.dataForm.illDate = ''
                        this.dataForm.reason = ''
                        this.dataForm.remark = ''
                    }
                }).catch(error => {
                    // this.$message('修改失败' + err)
                    this.$message.error('你没有修改数据的权限,请与系统管理员联系');
                })  
            },

            handleClose(){
                this.$confirm('关闭确认','提示信息').then(() => {
                    this.dialogVisible = false
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消关闭',
                    });
                });
            },

            saveOrUpdate(){
                let data = new FormData();
                if(this.dataForm.situationId === 0){
                    this.dataForm.personId = this.selectedPersonId
                }
                data.append("situationId",this.dataForm.situationId)
                data.append("personId",this.dataForm.personId)
                data.append("realName",this.dataForm.realName)
                data.append("relativeName",this.dataForm.relativeName)
                data.append("mobile",this.dataForm.mobile)

                if (this.dataForm.illDate) {
                    const date = new Date(this.dataForm.illDate);
                    data.append("illDate",moment(date).format('YYYY-MM-DD HH:mm:ss'))
                }

                data.append("reason",this.dataForm.reason)
                data.append("remark",this.dataForm.remark)
                
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        add(data).then(res => {
                            this.dialogVisible = false
                            this.$message({
                                message: res.msg,
                                type: 'success'
                            })
                            this.$emit('refreshReturnData')
                        }).catch(error => {
                            // this.$message('新增失败：' + err)
                            this.$message.error('你没有新增数据的权限,请与系统管理员联系');
                        })
                    }
                })
            }
        }
    })
</script>
<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 80px;
    height: 40px;
    line-height: 40px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>