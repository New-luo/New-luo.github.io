<template>
    <div  v-permission="'26'">
      <table align="center" width="900px">
        <tr>
          <td>
            <el-form :inline="true" v-model="listQuery">
              <el-row :span="24">
                <el-form-item prop="personId">
                  <el-input v-model="listQuery.personId" placeholder="请输入人员ID" @change="refreshSchoolList()"/>
                </el-form-item>
                <el-form-item prop="realName">
                  <el-input v-model="listQuery.realName" placeholder="请输入老人姓名" @change="refreshSchoolList()"/>
                </el-form-item>
                <el-form-item prop="mobile">
                  <el-input v-model="listQuery.mobile" placeholder="请输入亲属电话" @change="refreshSchoolList()"/>
                </el-form-item>
                <el-button
                  type="primary"
                  style="margin-top: 8px; margin-left: 8px"
                  icon="el-icon-search"
                  @click="refreshSchoolList()"
                  >搜索</el-button
                >
                <el-button
                  type="primary"
                  style="margin-top: 8px"
                  icon="el-icon-plus"
                  @click="add(0)"
                  plain
                  v-permission="'23'"
                  >新增</el-button
                >
              </el-row>
            </el-form>
          </td>
        </tr>
      </table>
      <el-table :data="situationList" border style="width: 100%" fit>
        <el-table-column prop="situationId" label="ID"></el-table-column>
        <el-table-column prop="personId" label="人员ID"></el-table-column>
        <el-table-column prop="realName" label="老人姓名"></el-table-column>
        <el-table-column prop="relativeName" label="亲属姓名"></el-table-column>
        <el-table-column prop="mobile" label="亲属电话"></el-table-column>
        <el-table-column prop="illDate" label="生病时间"></el-table-column>
        <el-table-column prop="reason" label="病情原因"></el-table-column>
        <el-table-column prop="remark" label="处理结果"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              type="primary"
              v-permission="'24'"
              @click="add(scope.row.situationId)"
              icon="el-icon-edit"
            ></el-button>
            <el-button
              type="danger"
              v-permission="'25'"
              @click="dele(scope.row.situationId)"
              icon="el-icon-delete"
            ></el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pager.current"
          :page-sizes="[5, 10, 20, 50]"
          :page-size="listQuery.size"
          layout="total, sizes, prev, pager, next, jumper"
          :total="pager.total"
        >
          <!-- //总页数 -->
        </el-pagination>
      </div>
      <add-or-update
        v-if="addOrUpdateVisible"
        ref="AddOrUpdate"
        @refreshReturnData="refreshSchoolList"
      />
    </div>
  </template>
    
    <script>
  import AddOrUpdate from "./AddOrUpdate.vue";
  import {list, del} from "../../api/situation";
  export default {
    name: "SituationIndex_",
    components: {
      AddOrUpdate,
    },
    data() {
      return {
        personinfoList:[],
        relativeList:[],
        pager:{
          current: 1,
          total: 0,
        },
        listQuery: {
          size: 5,
          curPage:1,
          situationId:'',
          personId:'',
          realName:'',
          mobile:''
        },
        situationList: [],
        addOrUpdateVisible: false,
      };
    },
    methods: {
      handleSizeChange(val) {
        // console.log(`每页 ${val} 条`);
        this.listQuery.size = val;
        this.refreshSchoolList();
      },
      handleCurrentChange(val) {
        //   console.log(`当前页: ${val}`);
        this.pager.current = val;
        this.refreshSchoolList();
      },

      add(id){
        this.addOrUpdateVisible=true;
        if(id===0){
            this.$nextTick(() => {
                this.$refs.AddOrUpdate.init(0);
            })
        }else{
            this.$nextTick(() => {
                this.$refs.AddOrUpdate.init(id);
            })
        }
      },
  
      //删除
      dele(situationId) {
        this.$confirm("此操作将永久删除该记录, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        }).then(() => {
            del(situationId).then((res) => {
                if (res.code == 200) {
                  this.pager.current=1;
                  this.$message({
                    type: "success",
                    message: "删除成功!",
                  });
                  this.refreshSchoolList();
                }
              }).catch((error) => {
                this.$message.error("你没有删除数据的权限,请与系统管理员联系");
              });
          }).catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除",
            });
          });
      },
  
      //条件.分页.查询列表
      refreshSchoolList() {

        this.listQuery.curPage = this.pager.current;
         
        list(this.listQuery).then(res => {
            this.personinfoList = res.personinfoList
            this.relativeList = res.relativeList
            this.pager = res.pager;
            this.situationList = res.pager.records;
            this.pager.total = res.pager.total;
          })
          .catch(err => {
            this.$message.error("你没有查询学校表数据的权限,请与系统管理员联系");
            // this.$message(err)
          });
      },
    },
    created() {
      this.refreshSchoolList();
    },
  };
  </script>
  
    
    