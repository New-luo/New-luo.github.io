<template>
    <div v-permission="'53'">
    <table align="center" width="900px">
        <tr>            
          <td>
            <el-form :inline="true" v-model="listQuery">
              <el-row :span="24">
                <!-- <el-form-item  prop="userId">
                      <el-input  placeholder="请输入用户ID" v-model="listQuery.userId" clearable/>
                  </el-form-item> -->
                  <el-autocomplete
      v-model="listQuery.userName"
      :fetch-suggestions="querySearch"
      clearable
      class="inline-input w-50"
      placeholder="请输入用户名称"
      @select="handleSelect"
    />
    <el-autocomplete
      v-model="listQuery.age"
      :fetch-suggestions="querySearch2"
      clearable
      style="margin-left:8px"
      class="inline-input w-50"
      placeholder="请输入用户年龄"
      @select="handleSelect"
    />
                  <el-button type="primary"  style=" margin-top: 8px;margin-left:8px" icon="el-icon-search" @click="refreshSchoolList()">搜索</el-button>
                    <el-button type="primary" style=" margin-top: 8px;"  icon="el-icon-plus"  v-permission="'51'"   @click="add(0)"plain>新增</el-button>

<el-tooltip content="密码初始为1234" placement="bottom" effect="light">
<el-button  :disabled="!selectedIds || selectedIds.length === 0" @click="getSelectedIds">初始化密码</el-button>
</el-tooltip>
              </el-row>              
          </el-form>
          </td>
        </tr>
    </table>
        
   
    <el-table :data="schools" border style="width: 100%" fit @selection-change="handleSelectionChange" :show-selection="true">
      <el-table-column type="selection"></el-table-column>
      <el-table-column prop="userId" label="用户ID"></el-table-column>
      <el-table-column prop="userName" label="用户名字"></el-table-column>
      <el-table-column prop="drugPic" label="头像">
        <template slot-scope="scope">
          <div v-if="!scope.row.drugPic">待上传</div>
          <img
            v-else
            :src="baseApi + scope.row.drugPic"
            alt="已上传"
            width="100"
            height="100"
          />
        </template>
      </el-table-column>
      <el-table-column prop="age" label="用户年龄"></el-table-column>
      <!-- <el-table-column prop="passWord" label="用户密码"></el-table-column> -->
      <el-table-column prop="time" label="近期登录时间"></el-table-column>
      <el-table-column prop="sex" label="性别"></el-table-column>
      <el-table-column prop="tel" label="电话"></el-table-column>
      <el-table-column prop="remark" label="备注"></el-table-column>
      <el-table-column prop="role" label="角色"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="primary" @click="add(scope.row.userId)" v-permission="'54'"  icon="el-icon-edit" circle></el-button>
          <el-button type="danger" @click="dele(scope.row.userId)"  v-permission="'52'"  icon="el-icon-delete" circle></el-button>
        </template>
      </el-table-column>
    </el-table>
<div class="block">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="listQuery.Current"
      :page-sizes="[3,5, 10, 20, 50]"
      :page-size="listQuery.size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="listQuery.total">
      <!-- //总页数 -->
    </el-pagination>
  </div>
  <add-or-update v-if="addOrUpdateVisible" ref="AddOrUpdate" @refreshReturnData="refreshSchoolList"/>
    </div>
  </template>
  
  <script>
  import AddOrUpdate from './adduser.vue'
  import {list,zd,del,changeStatus,password} from '../../../api/user'
  export default {
    name:"scool",
    components:{
        AddOrUpdate
    },
    data() {
      return {
        dialogVisible: false, // 弹窗是否可见
        selectedIds: [], // 存储选中的id
        suggestions: [],//用户名称自动弹窗
        suggestions2: [],//用户年龄自动弹窗
        listQuery:{        //添加查询条件
          userId:'',        //用户id
          userName:'',      //用户名称
          age:'',   //用户年龄
          size: 3 ,      //每页多少条数据
          Current:1,    //默认第一页
          total:0,     //总页数
          },
        schools: [],//用户列表
        baseApi:process.env.VUE_APP_BASE_API,//后台接口年龄
        addOrUpdateVisible:false,//新增修改弹窗
      };
    },
methods:{
  getSelectedIds() {
    this.$confirm('此操作将初始化用户密码, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          password(this.selectedIds).then(res => {
            if(res.code==200){
              this.$message({
            type: 'success',
            message: '操作成功!'
          });
          this.refreshSchoolList(); 
            } 
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消操作'
          });          
        });
  },

  handleSelectionChange(selection) {
    this.selectedIds = selection.map(item => item.userId);
  },
  querySearch(queryString, cb) {
  this.listQuery.userName = queryString;
  zd(this.listQuery).then(res => {
      // 使用 Set 来过滤不重复的 item.userName 值
      const uniqueNames = new Set();
      this.suggestions2 = res.list.reduce((uniqueList, item) => {
        if (!uniqueNames.has(item.userName)) {
          uniqueNames.add(item.userName);
          uniqueList.push({
            value: item.userName,
            link: item.link
          });
        }
        return uniqueList;
      }, []);
      cb(this.suggestions2);
    })
    .catch(error => {
      console.error('Error fetching restaurant list:', error);
    });
},
    handleSelect(item) {
      console.log(item);
    },


    
    querySearch2(queryString, cb) {
  this.listQuery.age = queryString;
  zd(this.listQuery).then(res => {
      // 使用 Set 来过滤不重复的 item.userName 值
      const uniqueNames = new Set();
      this.suggestions2 = res.list.reduce((uniqueList, item) => {
        if (!uniqueNames.has(item.age)) {
          uniqueNames.add(item.age);
          uniqueList.push({
            value: item.age,
            link: item.link
          });
        }
        return uniqueList;
      }, []);
      cb(this.suggestions2);
    })
    .catch(error => {
      console.error('Error fetching restaurant list:', error);
    });
},










    
      handleSizeChange(val) {
       // console.log(`每页 ${val} 条`);
        this.listQuery.size = val
        this.refreshSchoolList(); 
      },
      handleCurrentChange(val) {
     //   console.log(`当前页: ${val}`);
        this.listQuery.Current = val 
        this.refreshSchoolList(); 
      },


    
  //删除
    dele(id) {
        this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          del(id).then(res => {
            if(res.code==200){
              this.$message({
            type: 'success',
            message: '删除成功!'
          });
          this.refreshSchoolList(); 
            } 
          })
          .catch(error => {
            this.$message.error('你没有删除数据的权限,请与系统管理员联系');
      });
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
      },





//条件.分页.查询列表
    refreshSchoolList() {
     list(this.listQuery).then(res => {
        this.schools = res.page.records;  
        this.listQuery.total = res.page.total;
      })
      .catch(error => {
        this.$message.error('你没有查询用户表数据的权限,请与系统管理员联系');
      });
  },




           add(id){
           this.addOrUpdateVisible=true;
           if(id===0){
                //$nextTick异步处理，调用对话框的初始化函数
                this.$nextTick(() => {
                    this.$refs.AddOrUpdate.init(0);
                })  
            }else {
              this.$nextTick(() => {
                    this.$refs.AddOrUpdate.init(id);
                }) 
            }

},
    },
    created() {
        this.refreshSchoolList(); 
    }
  };
  </script>
  
