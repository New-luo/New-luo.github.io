<template>
    <div v-permission="'11'">
    <table align="center" width="900px">
        <tr>            
          <td>
            <el-form :inline="true" v-model="listQuery">
              <el-row :span="24">
                <el-form-item  prop="id">
                      <el-input  placeholder="请输入角色ID" v-model="listQuery.id" clearable/>
                  </el-form-item>
                  <el-autocomplete
      v-model="listQuery.role"
      :fetch-suggestions="querySearch"
      clearable
      class="inline-input w-50"
      placeholder="请输入角色名称"
      @select="handleSelect"
    />
    <el-autocomplete
      v-model="listQuery.work"
      :fetch-suggestions="querySearch2"
      clearable
      style="margin-left:8px"
      class="inline-input w-50"
      placeholder="请输入角色管理范围"
      @select="handleSelect"
    />
                  <el-button type="primary"  style=" margin-top: 8px;margin-left:8px" icon="el-icon-search" @click="refreshSchoolList()">搜索</el-button>
                  <el-button type="primary" style=" margin-top: 8px;"  icon="el-icon-plus"   @click="add(0)" plain>新增</el-button>
              </el-row>
              
          </el-form>
          
          </td>
        </tr>

    </table>
<el-table :data="schools" border style="width: 100%" fit>
      <el-table-column prop="id" label="角色ID"></el-table-column>
      <el-table-column prop="role" label="角色名字"></el-table-column>
      <el-table-column prop="work" label="角色管理范围"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="primary" v-permission="'9'"  @click="update2(scope.row.id)" icon="el-icon-edit" circle></el-button>
          <el-button type="danger" v-permission="'10'"  @click="dele(scope.row.id)" icon="el-icon-delete" circle></el-button>
          <el-button type="primary" plain v-permission="'55'"  @click="handleClick(scope.row.id)">权限控制</el-button>
        </template>
      </el-table-column>
    </el-table>
<div class="block">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="Current"
      :page-sizes="[3,5, 10, 20, 50]"
      :page-size="size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
      <!-- //总页数 -->
    </el-pagination>
  </div>
  <el-dialog
  :title="id > 0 ? '🎉修改🎉' : '🎉新增🎉'"
  :visible.sync="centerDialogVisible"
  width="40%"
  center>
  <div style="display: flex; justify-content: space-around;">
  <div style="text-align: left;">
    <!-- 左侧内容 -->
    角色名字：<br>
    <input type="text" v-model="role"><br>
    <span style="color:red" v-if="!role" class="error-message">请输入角色名字</span><br>
    角色管理范围：<br>
    <input type="text" style="width:300px;height:100px" v-model="work"><br>
    <span style="color:red" v-if="!work" class="error-message">请输入角色管理范围</span><br>   
  </div>
  <div>

  </div>
</div>

  <span slot="footer" class="dialog-footer">
    <el-button @click="centerDialogVisible = false">取 消</el-button>
    <el-button type="primary" :disabled="!canUpload" @click="upload()">确 定</el-button>
  </span>
</el-dialog>



<!--权限弹窗-->
<el-dialog
  :title="id > 0 ? '🎉修改🎉' : '🎉新增🎉'"
  :visible.sync="centerDialogVisibles"
  width="40%"
  center>
  <el-tree
      class="filter-tree"
      :data="treeData"
      :props="defaultProps"
      :filter-node-method="filterNode"
      :show-checkbox="true"
      node-key="id"
      :default-checked-keys="treeDatas"
      ref="tree"
    >
  </el-tree>
  <span slot="footer" class="dialog-footer">
    <el-button @click="centerDialogVisibles = false">取 消</el-button>
    <el-button type="primary"  @click="handleButtonClick()">确 定</el-button>
  </span>
</el-dialog>

    </div>
  </template>
  
  <script>
  import axios from 'axios';
  import {list2} from "../../api/user";
  export default {
    name:"scool",
    data() {
      return {
        //更新图片
        suggestions: [],//角色名称自动弹窗
        suggestions2: [],//角色地址自动弹窗
        id:0,//角色id
      role: '',//角色名称
      work: '',//角色管理范围
      status:0,
      isFileSelected:false,
        listQuery:{//添加查询条件
          id:'',
          role:'',
          work:'',
              },
        centerDialogVisibles:false,
        schools: [],
        size: 3 ,//每页多少条数据
        Current:1,//默认第一页
        total:0,//总页数
        baseApi:process.env.VUE_APP_BASE_API,//后台接口地址
        centerDialogVisible: false,//新增修改弹窗
        treeData: [],//权限父菜单
        treeDatas: [],//权限子菜单
        defaultProps: {//权限配置
        children: 'children',
        label: 'name',
        listQuery: {
                token : '', 
      },
      }
      };
    },
    computed: {
  canUpload() {
    return this.role && this.work;
  },
},
methods:{
  filterNode(value, data) {
      if (!value) return true;
      return data.label.indexOf(value) !== -1;
    },
  querySearch(queryString, cb) {
  const data = new FormData();
  data.append('role', queryString);
  const token = this.$Cookie.get('token');
  axios.post(this.baseApi + '/roleController/zd/', data,

    {
    headers: {
    Authorization: `${token}`,
    }

  })
    .then(response => {
      // 使用 Set 来过滤不重复的 item.slname 值
      const uniqueNames = new Set();
      this.suggestions2 = response.data.list.reduce((uniqueList, item) => {
        if (!uniqueNames.has(item.role)) {
          uniqueNames.add(item.role);
          uniqueList.push({
            value: item.role,
            link: item.link
          });
        }
        return uniqueList;
      }, []);
      cb(this.suggestions2);
    })
    .catch(error => {
      console.error('Error fetching restaurant list:', error);
    });
},

    handleSelect(item) {
      console.log(item);
    },




    querySearch2(queryString, cb) {
  const data = new FormData();
  data.append('work', queryString);
  axios.post(this.baseApi + '/roleController/zd/', data)
    .then(response => {
      // 使用 Set 来过滤不重复的 item.slname 值
      const uniqueNames = new Set();
      this.suggestions2 = response.data.list.reduce((uniqueList, item) => {
        if (!uniqueNames.has(item.work)) {
          uniqueNames.add(item.work);
          uniqueList.push({
            value: item.work,
            link: item.link
          });
        }
        return uniqueList;
      }, []);
      cb(this.suggestions2);
    })
    .catch(error => {
      console.error('Error fetching restaurant list:', error);
    });
},

handleClick(id){
  this.centerDialogVisibles = true;
  this.id = id
  const userId = id;
      axios
        .post(this.baseApi + '/privileges/update/'+userId)
        .then(response => {
          console.log(response)
          this.treeData = response.data.data;
          const conditionArray =response.data.list ;
          const sPIDArray = conditionArray.map(item => item.sPID);
          this.treeDatas = sPIDArray;
        })
        .catch(error => {
          console.error('Error fetching school list:', error);
        });
    },
    

    

    handleButtonClick() {
      const userId = this.id;
      const c = 0;
      const checkedNodes = this.$refs.tree.getCheckedNodes();
      let data = null;
      console.log('Checked nodes:', checkedNodes);
      if(checkedNodes.length==0){
      axios.post( this.baseApi + '/privileges/list/'+userId+'/'+ 0)
         .then(response => {
          this.centerDialogVisibles = false;
      })
      .catch(error => {
        console.error('Error fetching school list:', error);
      });
}else{
      if (Array.isArray(checkedNodes)) {
        const selectedIds = checkedNodes.map(node => node.id);
        console.log('Selected IDs:', selectedIds);
         data = selectedIds;
        axios.post( this.baseApi + '/privileges/list/'+userId+'/'+data)
         .then(response => {
          this.centerDialogVisibles = false;
          this.$message({
          message: '操作成功',
          type: 'success'
        });
         this.listQuery.token=  this.$Cookie.get('token');
          list2(this.listQuery)
        .then((res) => {
          let perms = res.list.map(num => num.toString());
          window.sessionStorage.setItem('perms', JSON.stringify(perms));
        })
    


      })
      .catch(error => {
        console.error('Error fetching school list:', error);
      });
      }
  }
    },
    
      handleSizeChange(val) {
       // console.log(`每页 ${val} 条`);
        this.size = val
        this.refreshSchoolList(); 
      },
      handleCurrentChange(val) {
     //   console.log(`当前页: ${val}`);
        this.Current = val 
        this.refreshSchoolList(); 
      },

    

      update2(id){
      //   if (this.$Cookie.get('token') === undefined || this.$Cookie.get('token') === '') {
      //     this.centerDialogVisible = false;
      // }
        this.centerDialogVisible = true
         id = id;
        axios.post(this.baseApi +'/roleController/update/'+id,{
      }).then(response => {
        if (response.data.code == 200) {
      const dataList = response.data.data;
      this.role = dataList[0].role;
      this.work = dataList[0].work;
      this.id = dataList[0].id;
      this.isFileSelected= true
        }else{
          alert("请求错误！");
        }
}).catch(error => {
  this.centerDialogVisible = false;
  this.$message.error('你没有修改数据的权限,请与系统管理员联系');
});
    },


    onFileChange(event) {
      this.isFileSelected= true
    const files = event.target.files;
    if (files && files.length) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.previewImage = e.target.result; // 将图片的数据URL赋值给previewImage
      };
      reader.readAsDataURL(files[0]); // 读取文件并将其转换为数据URL
      this.update = true; // 标记为已更新
      this.selectedFiles = files; // 将选择的文件保存到selectedFiles中
    }
  },
  upload() {
      const formData = new FormData();
      formData.append('id', this.id);
      formData.append('role', this.role);
      formData.append('work', this.work);
       this.centerDialogVisible = false
      axios.post( this.baseApi + '/roleController/uploadPic', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(response => {
        this.$message({
          message: response.data.msg,
          type: 'success'
        });
        this.refreshSchoolList(); 
      }).catch(error => {
        this.centerDialogVisible = false;
 
});
    },
    dele(id) {
        this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
           id = id;
          axios.post(this.baseApi +'/roleController/del/'+id, {
          }).then(response => {
        
            if(response.data.code==200){
              this.$message({
            type: 'success',
            message: '删除成功!'
          });
          this.refreshSchoolList(); 
            }
          })
          .catch(error => {
     
      });

        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
      },

    refreshSchoolList() {
    const Data = new FormData();
    Data.append('size', this.size);
    Data.append('Current', this.Current);
    Data.append('id', this.listQuery.id);
    Data.append('role', this.listQuery.role);
    Data.append('work', this.listQuery.work);
    const token = this.$Cookie.get('token');
    axios.post( this.baseApi + '/roleController/fy/',Data,
    {
    headers: {
    Authorization: `${token}`,
    }
  })  
      .then(response => {
        ///console.log(response.data.page.total);
        this.schools = response.data.page.records;  
        console.log(response.data.page.records)
        this.total = response.data.page.total;  
      })
      .catch(error => {
      
      });
  },
  add(id){
    this.centerDialogVisible = true
    this.role = '';
    this.work = '';
    this.id = 0 ;
},
    },
    created() {
        this.refreshSchoolList(); 
    }
  };





  </script>
  
