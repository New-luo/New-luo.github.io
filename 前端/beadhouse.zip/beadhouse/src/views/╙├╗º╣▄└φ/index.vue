<template>
  <div>
    <!-- 搜索条件 -->
    <!-- 模糊查询框 -->
    <el-form :inline="true" class="search-form">
      <el-form-item label="模糊查询">
        <el-input v-model="listQuery.keyword" placeholder="请输入搜索关键词"></el-input>
      </el-form-item>
       <!-- 搜索按钮 -->
       <el-form-item>
        <el-button type="primary" @click="searchput()">搜索</el-button>
      </el-form-item>
    </el-form>

    <!-- 下拉框 - 角色 -->
    <el-select v-model="roleFilter" placeholder="请选择角色" @change="handleRoleChange">
      <!-- 角色选项 -->
      <el-option v-for="role in roles" :key="role.id" :label="role.name" :value="role.id"></el-option>
    </el-select>

    <!-- 下拉框 - 状态 -->
    <el-select v-model="statusFilter" placeholder="请选择状态" @change="handleStatusChange">
      <!-- 状态选项 -->
      <el-option v-for="status in statuses" :key="status.id" :label="status.name" :value="status.id"></el-option>
    </el-select>

    <!-- 用户列表 -->
    <el-table :data="filteredData" border>
      <!-- 列定义 -->
      <!-- ... -->
    </el-table>

    <!-- 分页组件 -->
    <!-- ... -->
  </div>
</template>

<script>
import { list,search } from "../../api/系统管理/sysuser";

export default {
  data() {
    return {
      userData: [], // 用户数据
      listQuery: {
        keyword: "", // 模糊查询关键词
      },
      roleFilter: "", // 角色下拉框选项
      statusFilter: "", // 状态下拉框选项
      roles: [], // 角色列表
      statuses: [], // 状态列表
    };
  },
  created() {
    // 初始化角色和状态列表
    this.initFilters();
    // 初始化页面数据
    this.refreshSchoolList();
  },
  methods: {
    initFilters() {
      // 通过 API 获取角色和状态列表
      // 例如：调用获取角色列表的 API 方法，然后赋值给 this.roles
      // 例如：调用获取状态列表的 API 方法，然后赋值给 this.statuses
    },
    handleRoleChange() {
      // 角色下拉框选择事件，根据选中的角色过滤页面数据
      this.refreshSchoolList();
    },
    handleStatusChange() {
      // 状态下拉框选择事件，根据选中的状态过滤页面数据
      this.refreshSchoolList();
    },
    refreshSchoolList() {
      // 调用后端 API 获取数据
      // 可以根据 this.listQuery.keyword、this.roleFilter 和 this.statusFilter 作为参数传递给 API
      list(this.listQuery)
        .then((res) => {
          // 更新数据和分页信息
          this.userData = res.data; // 假设返回的数据放在 data 字段里
        })
        .catch((error) => {
          this.$message.error("获取数据失败，请联系管理员");
        });
    },
    // 其他方法...
  },
  searchput() {
      // 调用后端 API 进行模糊查询
      search({ keyword: this.listQuery.keyword })
        .then((res) => {
          // 更新模糊查询后的数据
          this.userData = res.data; // 假设返回的数据放在 data 字段里
        })
        .catch((error) => {
          this.$message.error("模糊查询失败，请联系管理员");
        });
    },
  computed: {
    filteredData() {
      // 根据角色和状态下拉框选项筛选数据
      let filtered = this.userData;
      if (this.roleFilter) {
        filtered = filtered.filter((user) => user.roleid === this.roleFilter);
      }
      if (this.statusFilter) {
        filtered = filtered.filter((user) => user.status === this.statusFilter);
      }
      return filtered;
    },
  },
};
</script>
