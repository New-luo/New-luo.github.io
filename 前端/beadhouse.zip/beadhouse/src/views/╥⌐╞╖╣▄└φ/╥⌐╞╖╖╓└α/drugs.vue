<template>
    <div  v-permission="'63'">
      <div>
        <h2>药品分类</h2>
      </div>
  <table align="center" width="900px">
      <tr>            
        <td>
          <el-form :inline="true" v-model="listQuery">
            <el-row :span="24">
              <el-form-item  prop="drugID">
                <!-- <el-input  placeholder="请输入ID" v-model="listQuery.drugID" clearable/> -->
                </el-form-item>
                  <el-autocomplete
                  v-model="listQuery.drugNames"
                  :fetch-suggestions="querySearch"
                  clearable
                  class="inline-input w-50"
                  placeholder="请输入类别"
                  @select="handleSelect"
                  />
                  <el-button type="primary"  style=" margin-top: 8px;margin-left:8px" icon="el-icon-search" @click="drugsList()">搜索</el-button>
                  <el-button type="primary" style=" margin-top: 8px;"  icon="el-icon-plus"   v-permission="'61'"  @click="add(0) ">新增</el-button>
              </el-row>
          </el-form>
        </td>
      </tr>
  </table>
    <div align="center">
     <el-table :data="drugs" border style="width: 1000px" fit >
        <el-table-column prop="drugID" label="ID"></el-table-column>
        <el-table-column prop="drugNames" label="药品分类"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" v-permission="'64'"   @click="add(scope.row.drugID)" icon="el-icon-edit" circle></el-button>
            <el-button type="danger"  v-permission="'62'"   @click="dele(scope.row.drugID)" icon="el-icon-delete" circle></el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  <div class="block">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="listQuery.Current"
      :page-sizes="[5, 10, 20, 50]"
      :page-size="listQuery.size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="listQuery.total">
     </el-pagination>
  </div>
  <add-or-update v-if="addOrUpdateVisible" ref="AddOrUpdate" @refreshReturnData="drugsList"/>
    </div>
  </template>
  <script>
  import {list,del,zd} from '../../../api/药品管理/drugs'
  import AddOrUpdate from './drugsAdd.vue' 
    export default{
        name:"Drugs_",
        components:{
        AddOrUpdate
          },
    data(){
        return{
             //querySearch:[],     客户名称自动弹窗
             //querySearch2:[],    客户访问事由地址自动弹窗
            listQuery:{
                drugID:'',  //ID
                drugNames:'', 
                size: 5 ,      
                //每页多少条数据
                Current:1,    //默认第一页
                total:0,     //总页数
            },
            drugs: [],//列表
            addOrUpdateVisible:false,//新增修改弹窗
          };
        },
        created() {
          this.drugsList(); 
        },
    methods:{
    handleSizeChange(val) {
     console.log(`每页 ${val} 条`);
      this.listQuery.size = val
      this.drugsList(); 
    },
    handleCurrentChange(val) {
     console.log(`当前页: ${val}`);
      this.listQuery.Current = val 
      this.drugsList(); 
    },
  //删除
  dele(id) { 
  console.log(id);
      this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        del(id).then(res => {
          if(res.code==200){                                                                                                                                   
            this.$message({
          type: 'success',
          message: '删除成功!'
        });
        this.drugsList(); 
          } 
        })
        .catch(err => {
          this.$message.error('你没有删除数据的权限,请与系统管理员联系');
      });
        })
      .catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    },
  // 条件.分页.查询列表
  drugsList() {
  console.log(this.listQuery)
   list(this.listQuery).then(res => {
      this.drugs = res.page.records;  
      this.listQuery.total = res.page.total;  
    })
    .catch(err => {
      this.$message.error('你没有查询学校表数据的权限,请与系统管理员联系');
    });
  },
  add(id){
  this.addOrUpdateVisible=true;
  if(id===0){
  //$nextTick异步处理，调用对话框的初始化函数
  this.$nextTick(() => {
  this.$refs.AddOrUpdate.init(0);
    })  
  }else {
  this.$nextTick(() => {
  this.$refs.AddOrUpdate.init(id);
    }) 
   }
  },
  querySearch(queryString, cb) {
    this.listQuery.drugNames = queryString;
    zd(this.listQuery).then(res => {
    // 使用 Set 来过滤不重复的 item.drugNames 值
    const uniqueNames = new Set();
    this.suggestions2 = res.list.reduce((uniqueList, item) => {
      if (!uniqueNames.has(item.drugNames)) {
        uniqueNames.add(item.drugNames);
        uniqueList.push({
          value: item.drugNames,
          link: item.link
        });
      }
      return uniqueList;
    }, []);
    cb(this.suggestions2);
  })
  .catch(error => {
    console.error('Error fetching restaurant list:', error);
  });
},
  handleSelect(item) {
    console.log(item);
  },
  }
    }
  </script>