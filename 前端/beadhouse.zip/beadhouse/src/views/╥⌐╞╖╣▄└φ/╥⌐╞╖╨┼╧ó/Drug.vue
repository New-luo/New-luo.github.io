<template>
  <div  v-permission="'73'">
    <table align="center" width="900px">
      <tr>
        <td>
          <el-form :inline="true" v-model="listQuery">
            <el-row :span="24">
              <el-form-item prop="drugID">
                <el-input
                  placeholder="请输入药品id"
                  v-model="listQuery.drugID"
                  clearable
                />
              </el-form-item>


  <el-form-item prop="drugF">
  <el-select v-model="listQuery.drugF" placeholder="请选择药品分类" clearable>
    <el-option v-for="c in f" :key="c.drugID" :label="c.drugNames" :value="c.drugID.toString()"/>
  </el-select>
</el-form-item>

<el-form-item prop="supplier">
  <el-select v-model="listQuery.g" placeholder="请选择供应商" clearable>
    <el-option v-for="c in p" :key="c.supplierId" :label="c.supplierName" :value="c.supplierId.toString()"/>
  </el-select>
</el-form-item>
              <el-button
                type="primary"
                style="margin-top: 8px; margin-left: 8px"
                icon="el-icon-search"
                @click="refreshSchoolList()"
                >搜索</el-button
              >
              <el-button
                type="primary"
                style="margin-top: 8px"
                icon="el-icon-plus"
                @click="add(0)"
                plain
                v-permission="'70'"
                >新增</el-button
              >
            </el-row>
          </el-form>
        </td>
      </tr>
    </table>
    <el-table :data="Drug" border style="width: 100%" fit>
      <el-table-column prop="drugID" label="客户ID"></el-table-column>
      <el-table-column prop="drugName" label="药品名称"></el-table-column>
      <el-table-column prop="drugPic" label="药品图片">
        <template slot-scope="scope">
          <div v-if="!scope.row.drugPic">待上传</div>
          <img
            v-else
            :src="baseApi + scope.row.drugPic"
            alt="已上传"
            width="100"
            height="100"
          />
        </template>
      </el-table-column>
      <el-table-column prop="p" label="药品分类"></el-table-column>
      <el-table-column prop="style" label="药品规格"></el-table-column>
      <el-table-column prop="g" label="供应商名称"></el-table-column>
      <el-table-column prop="drugP" label="批准文号"></el-table-column>
      <el-table-column prop="drugM" label="药品备注"></el-table-column>
      <el-table-column prop="price" label="价格(元)"></el-table-column>
      <el-table-column prop="ctime" label="创建时间"></el-table-column>
      <el-table-column prop="gtime" label="更新时间"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="primary"
            @click="add(scope.row.drugID)"
            icon="el-icon-edit"
            circle
            size="mini"
            v-permission="'74'"
          ></el-button>
          <el-button
            type="danger"
            @click="dele(scope.row.drugID)"
            icon="el-icon-delete"
            circle
            size="mini"
            v-permission="'72'"
          ></el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="listQuery.Current"
        :page-sizes="[5, 10, 20, 50]"
        :page-size="listQuery.size"
        layout="total, sizes, prev, pager, next, jumper"
        :total="listQuery.total"
      >
        <!-- //总页数 -->
      </el-pagination>
    </div>
    <add-or-update
      v-if="addOrUpdateVisible"
      ref="AddOrUpdate"
      @refreshReturnData="refreshSchoolList"
    />
  </div>
</template>
  
  <script>
import AddOrUpdate from "./DrugAdd.vue";
import { list, del, zd } from "../../../api/药品管理/Drug";
import {fp} from '../../../api/采购清单/Order'
export default {
  name: "Drug_",
  components: {
    AddOrUpdate,
  },
  data() {
    return {
      baseApi: process.env.VUE_APP_BASE_API, //后台接口地址
      suggestions: [], //客户名称自动弹窗
      suggestions2: [], //客户访问事由地址自动弹窗
      listQuery: {
        //添加查询条件
        drugID: "", //药品id
        drugName: "", //药品名称
        drugF: "", //药品分类
        g: "", //药品分类
        size: 5, //每页多少条数据
        Current: 1, //默认第一页
        total: 0, //总页数
      },
      Drug: [], //列表
      f: [],
        p: [],
      addOrUpdateVisible: false, //新增修改弹窗
    };
  },
  methods: {
    querySearch(queryString, cb) {
      this.listQuery.drugName = queryString;
      zd(this.listQuery)
        .then((res) => {
          // 使用 Set 来过滤不重复的 item.DrugName 值
          const uniqueNames = new Set();
          this.suggestions2 = res.list.reduce((uniqueList, item) => {
            if (!uniqueNames.has(item.drugName)) {
              uniqueNames.add(item.drugName);
              uniqueList.push({
                value: item.drugName,
                link: item.link,
              });
            }
            return uniqueList;
          }, []);
          cb(this.suggestions2);
        })
        .catch((error) => {
          console.error("Error fetching restaurant list:", error);
        });
    },
    handleSelect(item) {
      console.log(item);
    },

    querySearch2(queryString, cb) {
      this.listQuery.drugF = queryString;
      zd(this.listQuery)
        .then((res) => {
          // 使用 Set 来过滤不重复的 item.drugF 值
          const uniqueNames = new Set();
          this.suggestions2 = res.list.reduce((uniqueList, item) => {
            if (!uniqueNames.has(item.drugF)) {
              uniqueNames.add(item.drugF);
              uniqueList.push({
                value: item.drugF,
                link: item.link,
              });
            }
            return uniqueList;
          }, []);
          cb(this.suggestions2);
        })
        .catch((error) => {
          console.error("Error fetching restaurant list:", error);
        });
    },

    handleSizeChange(val) {
      // console.log(`每页 ${val} 条`);
      this.listQuery.size = val;
      this.refreshSchoolList();
    },
    handleCurrentChange(val) {
      //   console.log(`当前页: ${val}`);
      this.listQuery.Current = val;
      this.refreshSchoolList();
    },

    //删除
    dele(id) {
      console.log(id);
      this.$confirm("此操作将永久删除该记录, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          del(id)
            .then((res) => {
              if (res.code == 200) {
                this.$message({
                  type: "success",
                  message: "删除成功!",
                });
                this.refreshSchoolList();
              }
            })
            .catch((error) => {
              this.$message.error("你没有删除数据的权限,请与系统管理员联系");
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },

    //条件.分页.查询列表
    refreshSchoolList() {
      if(this.listQuery.drugName !=''||this.listQuery.drugF !='' || this.listQuery.drugID !=''){
  this.listQuery.Current=1;
}
      console.log(this.listQuery);
      list(this.listQuery)
        .then((res) => {
          this.Drug = res.page.records;
          this.listQuery.total = res.page.total;
        })
        .catch((error) => {
          this.$message.error("你没有查询学校表数据的权限,请与系统管理员联系");
        });
    },

    add(id) {
      this.addOrUpdateVisible = true;
      if (id === 0) {
        //$nextTick异步处理，调用对话框的初始化函数
        this.$nextTick(() => {
          this.$refs.AddOrUpdate.init(0);
        });
      } else {
        this.$nextTick(() => {
          this.$refs.AddOrUpdate.init(id);
        });
      }
    },
  },
  created() {
    this.refreshSchoolList();
    fp()
        .then((res) => {
      this.p = res.g;
      this.f = res.f;
      console.log(this.f);
      console.log(this.p);
        })
        .catch((error) => {
        });
  },
};
</script>
  
  