<template>
<el-dialog
  :title="dataForm.manualRecordId > 0 ? '修改' : '新增'"
  :visible.sync="centerDialogVisible"
  width="60%"
  center>
  <el-form :model="dataForm" ref="dataForm" :rules="dataRule" inline label-width="100px" style="width:100%;">
    <el-row>
      <!-- 左侧内容 -->
      <el-col :span="12">
        <el-form-item prop="visitor" label="客户姓名：">
          <el-input v-model="dataForm.visitor"/>
        </el-form-item>
        <el-form-item prop="mobile" label="联系电话：">
          <el-input v-model="dataForm.mobile"/>
        </el-form-item>
        <el-form-item prop="visitReason" label="访问事由：">
          <el-input v-model="dataForm.visitReason"/>
        </el-form-item>
      </el-col>
      <!-- 右侧内容 -->
      <el-col :span="12">
        
         <!-- <el-form-item prop="visitTime" label="访问时间：">
        <el-date-picker v-model="dataForm.visitTime" type="datetime" format="yyyy-MM-dd HH:mm:ss"
        value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择日期时间"></el-date-picker>
        </el-form-item> -->
      
        <el-form-item prop="userName" label="接待人员：">
          <el-input v-model="dataForm.userName"/>
        </el-form-item>

        <el-form-item prop="remark" label="访问结果：">
          <el-input v-model="dataForm.remark"/>
        </el-form-item>
      </el-col>
    </el-row>
  </el-form>
  <span slot="footer" class="dialog-footer">
      <el-button @click="centerDialogVisible = false">取 消</el-button>
      <el-button type="primary"  @click="upload()">确 定</el-button>
    </span>
</el-dialog>
</template>
<script>
import {list,add,getid} from '../../../api/接待管理/Reception'
export default {
  data() {
    return {
      dataForm:{
                manualRecordId:0,
                visitor:'',
                mobile: '',
                visitReason: '',
                //visitTime:'',
                userName:'',
                remark:'',
      },
      centerDialogVisible:false,
      dataRule:{
            visitor: [
                { required: true, message: '客户姓名不能为空', trigger: 'blur' }
            ],
            visitReason: [
                { required: true, message: '访问事由不能为空', trigger: 'blur' }
            ],
            mobile: [
                { required: true, message: '联系电话不能为空', trigger: 'blur' },
                { min: 8, max:20,message: '联系电话必须在8~11位之间', trigger: 'blur' },    
            ],
            // visitTime: [
            //     { required: true, message: '访问时间不能为空', trigger: 'blur' },
                  
            // ],
            userName: [
                { required: true, message: '接待人员不能为空', trigger: 'blur' },
                 
            ],
            remark: [
                { required: true, message: '访问结果不能为空', trigger: 'blur' },
          
            ],
        },
    };
    
  },
  created() {

},
  methods: {
       init(id){
  this.centerDialogVisible = true
  getid(id).then(res => {
    if(id>0){
    let { manualRecordId, visitor, mobile, visitReason, visitTime,userName,remark } = res.data[0];
    this.dataForm = {
      manualRecordId,visitor,mobile,visitReason,visitTime,userName,remark
    };
    }else{
      this.dataForm.manualRecordId = 0;
      this.dataForm.visitor ='';
      this.dataForm.mobile ='';
      this.dataForm.visitReason ='';
     // this.dataForm.visitTime ='';
      this.dataForm.userName ='';
      this.dataForm.remark ='';
    }
}).catch(error => {
  this.centerDialogVisible = false;
  this.$message.error('你没有修改数据的权限,请与系统管理员联系');
});     
},
handleDateTimeChange() {
        this.dataForm.visitTime = new Date(this.dataForm.visitTime);
},


      upload() {
       let formData = new FormData();
      formData.append('manualRecordId', this.dataForm.manualRecordId);
      formData.append('visitor', this.dataForm.visitor);
      formData.append('mobile', this.dataForm.mobile);
      formData.append('visitReason', this.dataForm.visitReason);
     // formData.append('visitTime', this.dataForm.visitTime);
      formData.append('userName', this.dataForm.userName);
      formData.append('remark', this.dataForm.remark);
    this.$refs['dataForm'].validate((valid) => {
      if (valid) {
    add(formData).then(res => { 
        this.centerDialogVisible = false
        this.$message({
          message: res.msg,
          type: 'success'
        });
        this.$emit('refreshReturnData')
      }).catch(error => {
        this.$message.error('你没有新增数据的权限,请与系统管理员联系');
      }); 
      }
    })
    }
  }
};
</script>




