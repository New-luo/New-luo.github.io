<template>
    <div style="display: flex;">
        <div id="main" style="width: 600px;height:400px;"></div>
        <div id="main1" style="width: 600px;height:400px;"></div>
        <div id="myChart" style="width: 500px;height: 300px;"></div>
    </div>
</template>
<script>
import * as echarts from 'echarts';
export default {
    name: 'Chart',
    data() {
        return {
            echartsOption: {    // echarts选项，所有绘图数据和样式都在这里设置
                legend: {   //图表上方的图例
                    data: ['罗福良','薛煜']
                },
                tooltip: {   //鼠标放到图上的数据展示样式
                    trigger: 'axis'
                },
                series: [{
                    name: '公司市值占比',
                    type: 'pie',
                    barWidth: '60%',
                    data: [   // 扇形图数据格式： {value, name}
                        { value: 0.35, name: '罗福良' },      // value不一定是比例，echarts会自动转换
                        { value: 0.2, name: '薛煜' },
                    ],
                }],
            },
            myTestChart: {},
        }
    },
    mounted() {
        this.initChart()
        this.initChart1()
        let myChart = echarts.init(document.getElementById('myChart'), 'light') // 初始化echarts, theme为light
        myChart.setOption(this.echartsOption)   // echarts设置选项
        
    },

    methods: {
        initChart() {
            const chart = echarts.init(document.getElementById('main'))
            const option = {
                title: {
                    text: '组员'
                },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data: ['销量1', '销量2'] // 修改图例名称
                },
                xAxis: {
                    type: 'category',
                    data: ['罗福良', '薛煜', '段金龙', '谢小明']
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name: '销量1',
                        type: 'line',
                        data: [5, 20, 36, 10, 10, 20]
                    },
                    {
                        name: '销量2',
                        type: 'line',
                        data: [10, 15, 25, 20, 5, 30]
                    }
                ]
            }
            chart.setOption(option)
        },
        initChart1() {
            const chart = echarts.init(document.getElementById('main1'))

            const option = {
                title: {
                    text: '组员'    
                },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data: ['销量1', '销量2'] // 修改图例名称
                },
                xAxis: {
                    type: 'category',
                    data: ['崔宇', '廖奕颖','赖博文']
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name: '销量1',
                        type: 'line',
                        stack: 'Total',
                        areaStyle: {},
                        emphasis: {
                            focus: 'series'
                        },
                        data: [5, 20, 36, 10, 10, 20]
                    },
                    {
                        name: '销量2',
                        type: 'line',
                        stack: 'Total',
                        areaStyle: {},
                        emphasis: {
                            focus: 'series'
                        },
                        data: [10, 15, 25, 20, 5, 30]
                    }
                ]
            }
            chart.setOption(option)
        },
    }
}
</script>
<style>
#myChart {
    width: 100%;
    height: 500px;
    margin: 0 auto;
    margin-top: 5%;
}
</style>