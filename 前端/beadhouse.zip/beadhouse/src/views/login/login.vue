<template>
        <div id="login123">
      <transition appear name="opacitytrans">
        <div class="container" id="container">
          <div class="form-container sign-in-container">
            <form action="#">
              <h1>养老院管理系统</h1>
              <span style=" font-size: 12px;color: beige;">Version 1.0.0</span>
              <input type="text" placeholder="用户名" v-model="userName" />
              <input type="password" placeholder="密码" v-model="passWord" />
            
              <div class="button" :loading="loading" @click="login()">{{ buttonText }}</div>
            </form>
          </div>
          <div class="overlay-container">
            <div class="overlay">
              <div class="overlay-panel overlay-right">
                <template v-if="pic">
      <el-image 
      style="width: 140px; height: 140px;"
        :src="pic" 
      ></el-image>
    </template>
                <p>
                  「{{IntheTime}}，{{Greetings}}」
                </p>
              
              </div>
            </div>
          </div>
        </div>
      </transition>
    </div>
  </template>
  <script>
  import axios from 'axios'; // 导入axios库
  import {list2} from "../../api/user";
  export default {
    data() {
      return {
        pic:'',
        autoONotify: '不记住密码',
        loading: false,
        buttonText: '登录',
        userName: '',
        passWord: '',
        role: '1',
        token: '',
        remember:false,
        roles: [],
        flag: false,
        baseApi:process.env.VUE_APP_BASE_API,//后台接口地址
        IntheTime: '',
        Slogan: [
                "今天的心情如何？",
                "祝你有一个开心的一天！",
                "为美好的世界献上祝福！",
                "花开富贵",
                "让我们一起迎接快乐的明天,我们就是为此才有翅膀!",
                "无论怎样的瞬间  都会有新的开始在歌唱",
                "长夜伴浪破晓梦，梦晓破浪伴夜长。",
            ],  
                listQuery: {
                token : '', 
      },
      c :'',
      };
    },
    created() {
      const now = new Date();
            const year = now.getFullYear();
            const month = ('0' + (now.getMonth() + 1)).slice(-2);
            const day = ('0' + now.getDate()).slice(-2);
            const hour = ('0' + now.getHours()).slice(-2);
            const minutes = ('0' + now.getMinutes()).slice(-2);
            const seconds = ('0' + now.getSeconds()).slice(-2);
            const formattedDate = `${year}-${month}-${day} ${hour}:${minutes}:${seconds}`;
        

            // 判断时间段
            if (hour >= 0 && hour < 6) {
                this.IntheTime = '早点休息吧。';
            } else if (hour >= 6 && hour < 10) {
                this.IntheTime = '早上好';
            }else if(hour >=10 && hour <12){
                this.IntheTime = '上午好';
            }else if (hour >= 12 && hour < 18) {
                this.IntheTime = '下午好';
            } else {
                this.IntheTime = '晚上好';
            }
            const randomIndex = Math.floor(Math.random() * this.Slogan.length);
            this.Greetings = this.Slogan[randomIndex];
        // 从本地存储中获取账号
          this.userName = this.$Cookie.get('userName');
          this.passWord = this.$Cookie.get('passWord');
          if(this.$Cookie.get("flag") == "true"){
            this.remember = true;
          }else{
            this.$Cookie.remove("flag");
            this.remember = false;
          }
          this.refreshSchoolList(); 
   },
    methods: {
      querySearch(queryString, cb) {
      const data = new FormData();
      data.append('slname', queryString);
      axios.post(this.baseApi + '/upload/zd/', data)
        .then(response => {
          this.suggestions = response.data.list.map((item) => ({
            value: item.slname,
            link: item.link
          }));
          cb(this.suggestions);
        })
        .catch(error => {
          console.error('Error fetching restaurant list:', error);
        });
    },
    handleSelect(item) {
     
    },
  refreshSchoolList() {
    axios.post( this.baseApi + '/roleController/login/')  
      .then(response => {
        this.roles = response.data.list;
        this.role = this.roles[0].id; // 默认选择第一个角色
      })
      .catch(error => {
    alert("系统维护中...")
      });
  },
      login() {
        if (!this.userName) {
          this.$message('请输入员工昵称');
          return;
        }
        if (!this.passWord) {
          this.$message('请输入密码');
          return;
        }
        let baseApi = process.env.VUE_APP_BASE_API;
        let url = baseApi + '/11011/login';
        if(this.autoONotify == "不记住密码"){
                this.autoONotify = 2;
            }else{
                this.autoONotify = 1;
        }
              axios({
                  url: url,
                  method: 'post',
                  params: {
                    'userName': this.userName,
                    'passWord': this.passWord,
                    'role': this.role,
                    'remember': this.remember
                  },
              }).then(res => {
              
                    if(res.data.code === 200){
                      if (this.remember) {
                        this.flag = true;
                        //保存token,cookie有效期为1天
                        let selectedRole = null;
                        for (let i = 0; i < this.roles.length; i++) {
                          if (this.roles[i].id === parseInt(res.data.role)) { 
                            selectedRole = this.roles[i];
                            break;
                          }
                        }
                      
                     
                        this.pic = this.baseApi+res.data.pic
                        let perms = res.data.list.map(num => num.toString());
                        window.sessionStorage.setItem('perms', JSON.stringify(perms));
                        this.$Cookie.set("flag",true, {expires: 1});
                        this.$Cookie.set("token",res.data.role,{expires:1});
                        this.$Cookie.set("role",selectedRole.role,{expires:1});
                        this.$Cookie.set('userName',this.userName,{expires:1});
                        this.$Cookie.set('passWord',this.passWord,{expires:1});
                        this.$Cookie.set('pic',this.pic,{expires:1});

                        this.loading = true; // 设置按钮为加载状态
                        this.buttonText = '登录中...'; // 设置按钮文本为"登录中..."
                        setTimeout(() => {
                        this.$router.push({name:'1'});
                        this.$notify({
                        title: '登录成功',
                        message: '欢迎回来！',
                        type: 'success'
                    });
                        }, 100);
                  }else{
                    let selectedRole = null;
                    for (let i = 0; i < this.roles.length; i++) {
                      if (this.roles[i].id === parseInt(res.data.role)) { 
                        selectedRole = this.roles[i];
                        break;
                      }
                    }
                        let perms = res.data.list.map(num => num.toString());
                        window.sessionStorage.setItem('perms', JSON.stringify(perms));
                        this.$Cookie.set("role",selectedRole.role,{expires:1});
                        this.$Cookie.set("token",res.data.role,{expires:1});
                        this.$Cookie.set("time",res.data.time,{expires:1});
                        this.$Cookie.set('userName',this.userName,{expires:1});
                         
                        this.pic = this.baseApi+res.data.pic
                        this.$Cookie.set('pic',this.pic,{expires:1});
                        this.loading = true; // 设置按钮为加载状态
                        this.buttonText = '登录中...'; // 设置按钮文本为"登录中..."
                        setTimeout(() => {
                        // this.loading = false;
                        // this.buttonText = '登录';
                        this.$router.push({name:'1'});
                        this.$notify({
                        title: '登录成功',
                        message: '欢迎回来！',
                        type: 'success'
                    });
                        }, 3000);
                  }
                }
                   else { // 登录失败
                    this.$store.commit('setLoggedIn', false);
                    if(res.data.code!=200){
                    this.$notify({
                        title: '登录失败',
                        message: '用户名或密码错误！',
                        type: 'error'
                    });
                  }
                }
              }).catch(err => {
              
              
              
              })
      }
      
    }
    
  };
  </script>
  <style scoped>
  body {
  margin: 0px;
  padding: 0px;
  
}
  #login123 {
    margin-top:-60px;
    margin-left:-60px;
    margin-right:-60px;
    font-family: "Montserrat", sans-serif;
    background: #f6f5f7;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100vh;
    /* margin: -20px 0 50px; */
    /* background-image: url("https://www.17sucai.com/preview/1749733/2019-06-22/%E7%99%BB%E5%BD%95/img/img1.png"); */
    background-image: url('./image/preview.jpg');
    background-size: cover;
  }
  .logo {
    width: 160px;
    height: auto;
  }
  
  /* 滚动条样式 */
::-webkit-scrollbar {
    background-color: #fff0;
    width: 6px;
}
::-webkit-scrollbar-thumb {
    background-color: #ffffff3d;
    border-radius: 10px;
}
::-webkit-scrollbar-thumb:hover {
    background-color: #ffffff50;
}
  h1 {
    font-weight: bold;
    margin: 0;
    color: beige;
  }
  
  p {
    font-size: 14px;
    font-weight: bold;
    line-height: 20px;
    letter-spacing: 0.5px;
    margin: 20px 0 30px;
  }
  
  /* span {
    font-size: 12px;
    color: beige;
  }
  */

  
  .container {
    border-radius: 10px;
    box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
    position: absolute;
    overflow: hidden;
    width: 768px;
    max-width: 100%;
    min-height: 480px;
    opacity: 0.8;
  }
  
  .form-container form {
    background: rgba(45, 52, 54, 1);
    display: flex;
    flex-direction: column;
    padding: 0 50px;
    height: 100%;
    justify-content: center;
    align-items: center;
    text-align: center;
  }
  
  .social-container {
    margin: 20px 0;
  }
  
  .social-container a {
    border: 1px solid #ddd;
    border-radius: 50%;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    margin: 0 5px;
    height: 40px;
    width: 40px;
  }
  
  .form-container input {
    background: #eee;
    border: none;
    padding: 12px 15px;
    margin: 8px 0;
    width: 100%;
  }
  .button {
    cursor: pointer;
    border-radius: 20px;
    border: 1px solid #1BBFB4;
    background: #1BBFB4;
    color: #fff;
    font-size: 12px;
    font-weight: bold;
    padding: 12px 45px;
    margin-top: 20px;
    letter-spacing: 1px;
    text-transform: uppercase;
    transition: transform 80ms ease-in;
  }
  
  input[type="text"] {
    width: 240px;
    text-align: center;
    background: transparent;
    border: none;
    border-bottom: 1px solid #fff;
    font-family: "PLay", sans-serif;
    font-size: 16px;
    font-weight: 200px;
    padding: 10px 0;
    transition: border 0.5s;
    outline: none;
    color: #fff;
    font-weight: bold;
  }
  
  input[type="password"] {
    width: 240px;
    text-align: center;
    background: transparent;
    border: none;
    border-bottom: 1px solid #fff;
    font-family: "PLay", sans-serif;
    font-size: 16px;
    font-weight: bold;
    padding: 10px 0;
    transition: border 0.5s;
    outline: none;
    color: #fff;
  }
  
  /* input[type="email"] {
    width: 240px;
    text-align: center;
    background: transparent;
    border: none;
    border-bottom: 1px solid #fff;
    font-family: "PLay", sans-serif;
    font-size: 16px;
    font-weight: 200px;
    padding: 10px 0;
    transition: border 0.5s;
    outline: none;
    color: #fff;
    font-weight: bold;
  } */
  
  .button:active {
    transform: scale(0.95);
  }
  
  .button:focus {
    outline: none;
  }
  
  .button.ghost {
    background: transparent;
  
    /* border-color: #fa8817;
    background-color: #fa8817; */
     border-color: #1BBFB4;
    background-color: #1BBFB4;
    margin: 0;
  }
  
  .form-container {
    position: absolute;
    top: 0;
    height: 100%;
    transition: all 0.6s ease-in-out;
  }
  
  .sign-in-container {
    left: 0;
    width: 50%;
    z-index: 2;
  }
  
  .sign-up-container {
    left: 0;
    width: 50%;
    z-index: 1;
    opacity: 0;
  }
  
  .overlay-container {
    position: absolute;
    top: 0;
    left: 50%;
    width: 50%;
    height: 100%;
    overflow: hidden;
    transition: transform 0.6s ease-in-out;
    z-index: 100;
  }
  
  .overlay {
    background: transparent;
    background: linear-gradient(to right, #ff4b2b, #ff416c) no repeat 0 0 / cover;
    color: #fff;
    position: absolute;
    left: -100%;
    height: 100%;
    width: 200%;
    transform: translateX(0);
    transition: transform 0.6s ease-in-out;
  }
  
  .overlay-panel {
    position: absolute;
    top: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 0 40px;
    height: 100%;
    width: 50%;
    text-align: center;
    transform: translateX(0);
    transition: transform 0.6s ease-in-out;
  }
  .overlay-right {
    right: 0;
    transform: translateX(0);
  }
  
  </style>
  