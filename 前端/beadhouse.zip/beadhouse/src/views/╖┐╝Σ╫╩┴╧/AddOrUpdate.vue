<template>
    <el-dialog
        :title="dataForm.picId>0?'修改':'新增'"
        :visible.sync="dialogVisible"
        width="35%"
        height="400"
        :close-on-click-modal="false"
        :before-close="handleClose">
        <el-form :model="dataForm" ref="dataForm" :rules="dataRule" inline label-width="100px" style="width:95%" @keyup.enter.native="saveOrUpdate()">
            <el-row>
                <el-col :span="24">
                    <el-form-item prop="houseId" label="房间号">
                        <el-input v-model="dataForm.houseId" style="width:215px"/>
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item prop="picName" label="房间介绍">
                        <el-input v-model="dataForm.picName" style="width:215px"/>
                    </el-form-item>
                </el-col>
                <el-col style="padding-left: 120px;" :span="24">
                        <el-form-item prop="url" :label="img ? '更新房间图片:' : '选择房间图片:'">
                            <div style="text-align: center;">
                            <input type="file" @change="onFileChange" multiple><br>
                            <div style="display: flex; justify-content: center;">
                                <div v-if="img">
                                    <img :src="baseApi + img" style="height:100px">
                                </div>
                                <div v-if="previewImage">
                                    <img :src="previewImage" alt="preview" style="width:100px">
                                </div>
                            </div>
                            </div>
                        </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item prop="seq" label="排序">
                        <el-input v-model="dataForm.seq" style="width:215px"/>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button @click="dialogVisible = false">取消</el-button>
            <el-button type="primary" @click="saveOrUpdate()">保存</el-button>
        </span>
    </el-dialog>

</template>
<script>

import {getId,add} from '../../api/housepic'

export default ({
    name:'HousepicAdd_',
    data(){
        return{
            dataForm:{
                picId:0,
                houseId:'',
                picName:'',
                url:'',
                seq:''
            },
            baseApi:process.env.VUE_APP_BASE_API,
            update:false,
            dialogVisible:false,
            selectedFiles: [],
            img:'',
            isFileSelected:false,
            previewImage: '',
            dataRule:{
                houseId: [
                    { required: true, message: '房间号不能为空', trigger: 'blur' }
                ],
                picName: [
                    { required: true, message: '房间介绍不能为空', trigger: 'blur' }
                ],
                seq: [
                    { required: true, message: '排序不能为空', trigger: 'blur' }
                ]
            }
        }
    },
    methods:{
        init(id){
            this.dialogVisible = true
            if(id>0){
                getId(id).then(res=>{
                    if(id>0){
                        this.previewImage ='';
                        document.querySelector('input[type="file"]').value = '';
                        this.dataForm.picId = res.data.picId
                        this.dataForm.houseId = res.data.houseId
                        this.dataForm.picName = res.data.picName
                        this.dataForm.seq = res.data.seq
                        this.selectedFiles = res.data.url
                        this.img = res.data.url;
                        this.isFileSelected= true
                    }
                }).catch(err=>{
                    this.$message('出错了：' + err)
                })
            }
            if(id==0){
                            this.dataForm.picId = 0,
                                this.dataForm.houseId = '',
                                this.dataForm.picName = '',
                                this.dataForm.seq = '',
                                this.selectedFiles = '';
                                this.isFileSelected= false;
                                this.img = '';
                                this.previewImage ='';
                                document.querySelector('input[type="file"]').value = '';
                            }
        },

        onFileChange(event) { 
            this.isFileSelected= true
            const files = event.target.files;
            if (files && files.length) {
                const reader = new FileReader();
                reader.onload = (e) => {
                this.previewImage = e.target.result;
                console.log(this.previewImage)
                };
                reader.readAsDataURL(files[0]);
                this.update = true;
                this.selectedFiles = files;
                console.log(baseApi + img)
            }
        },

        handleClose(){
            this.$confirm('关闭确认','提示信息').then(()=>{
                this.dialogVisible = false
            }).catch(() => {
                this.$message({
                    type: "info",
                    message: "已取消关闭",
                });
            });
        },

        saveOrUpdate(){
            let data = new FormData();
            data.append("picId",this.dataForm.picId);
            data.append("houseId",this.dataForm.houseId);
            data.append("picName",this.dataForm.picName);
            data.append("seq",this.dataForm.seq);
            
            if (!this.update || this.selectedFiles==undefined) {
     
            } else{
                for (let i = 0; i < this.selectedFiles.length; i++) {
                    data.append('url', this.selectedFiles[i]);
                    console.log(this.selectedFiles[i])
                };
            }   
               
            this.$refs['dataForm'].validate((valid) => {
                if (valid) {
                    add(data).then(res=>{
                        this.dialogVisible=false
                        this.$message({
                            message: res.msg,
                            type: 'success'
                        });
                        this.$emit('refreshReturnData')
                    }).catch(err=>{
                        this.$message('新增失败:' + err)
                    })
                }
            });
        },
    }  
})
</script>
<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 80px;
    height: 40px;
    line-height: 40px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>