<template>
    <div class="app-container"  v-permission="'31'">
        <el-form :inline="true" v-model="listQuery">
            <el-row>
                <el-col :span="6">
                    <el-form-item label="房间号:" prop="houseId">
                        <el-input v-model="listQuery.houseId"  placeholder="请输入房间号" @change="initData()"/>
                    </el-form-item>
                    <el-button type="primary" icon="el-icon-search" @click="initData">搜索</el-button>
                </el-col>
                <el-col :span="17" align="right">
                    <el-button type="primary" icon="el-icon-plus"  v-permission="'28'"  plain @click="add(0)">新增</el-button>
                </el-col>
            </el-row>
        </el-form>
        <el-table border :data="housepicList" height="450px" size="mini">
            <!-- <el-table-column type="selection"/>   -->
            <el-table-column label="房间ID" prop="picId"/>
            <el-table-column label="房间号" prop="houseId"/>
            <el-table-column label="房间介绍" prop="picName"/>
            <el-table-column label="图片展示" prop="url">
                <template slot-scope="scope">
                    <!-- <el-image :src="scope.row.url" style="height:60px" :preview-src-list="[scope.row.url]"/> -->
                    <div v-if="!scope.row.url">待上传</div>
                    <img
                        v-else
                        :src="baseApi + scope.row.url"
                        alt="已上传"
                        width="100"
                        height="100"
                    />
                </template>
            </el-table-column>
            <el-table-column label="排序" prop="seq"/>
            <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button type="primary"      v-permission="'29'"  icon="el-icon-edit" @click="add(scope.row.picId)"></el-button>
                    <el-button type="danger"       v-permission="'30'"  icon="el-icon-delete" @click="dele(scope.row.picId)"></el-button>
                </template>
            </el-table-column>  
        </el-table>
        <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="pager.current"
            :page-sizes="[5,10,15,20]"
            :page-size="listQuery.size"
            layout="total, sizes, prev, pager, next, jumper"
            :total="pager.total">
        </el-pagination>
        <add-or-update v-if="addOrUpdateVisible" ref="AddOrUpdate" @refreshReturnData="initData"/>

    </div>
</template>
<script>
import {list,del} from '../../api/housepic'

import AddOrUpdate from './AddOrUpdate.vue'
export default ({
    name:'H_',
    components:{
        AddOrUpdate
    },
    data(){
        return {
            baseApi: process.env.VUE_APP_BASE_API, 
            housepicList:[],
            ids:[],
            addOrUpdateVisible:false,
            pager:{
                total:0,
                current:1,
            },
            listQuery:{
                houseId:'',
                size:5,
                curPage:1
            }
        }
    },
    created(){
        this.initData()
    },
    methods: {
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`);
            //设置每页显示的记录数
            this.listQuery.size = val
            this.initData()
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`);
            //设置当前页
            this.pager.current = val
            this.initData()
        },
        add(id){
            this.addOrUpdateVisible=true;
            if(id===0){
                this.$nextTick(() => {
                    this.$refs.AddOrUpdate.init(0);
                })
            }else{
                this.$nextTick(() => {
                    this.$refs.AddOrUpdate.init(id);
                })
            }
        },
        dele(picId) {
            this.$confirm("是否删除", "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            }).then(() => {
                del(picId).then(res => {
                    this.$message({
                        type: "success",
                        message: "删除成功!",
                    });
                    this.initData();
                })
            }).catch(() => {
                this.$message({
                    type: "info",
                    message: "已取消删除",
                });
                this.initData();
            });
        },
        initData(){
            this.listQuery.curPage = this.pager.current;
            list(this.listQuery).then(res=>{
                this.pager = res.pager;
                this.housepicList = res.pager.records
                this.pager.total = res.pager.total
            }).catch(err=>{
                this.$message(err)
            })

        }
    }
        
})
</script>