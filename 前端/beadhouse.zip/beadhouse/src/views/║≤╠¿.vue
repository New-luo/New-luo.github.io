<template>
    <div style="margin-top: -70px; 
    margin-left:-20px" id="app">
 <!-- <el-avatar :size="80" :src="circleUrl" style="margin-top: 40px;"></el-avatar>
     -->
  <el-container>
  <el-aside width="200px">
 <el-row class="tac" style="margin-top: 10px;">
  <el-col :span="12">
    <el-menu
      default-active="2"
      :unique-opened="true"
      class="el-menu-vertical-demo"
      :collapse="isCollapse" 
      @open="handleOpen"
      @close="handleClose"
      background-color="#001529"
      text-color="white"
      active-text-color="#1c88ee"
      style="height:700px;
      text-align: center;"
      >
     <!-- <el-menu-item>
      <img src="../img/b83b5ece7fb653c2eadbb02f640d74d3.jpg" style="width: 50px; height: 50px;"/>
     <span>养老院后台管理系统</span>
      </el-menu-item> -->


      <el-menu-item index="4">
        <i class="el-icon-s-home"></i>
        <span slot="title" @click="addTab('首页')">首页</span>
      </el-menu-item>


      <el-submenu index="6">
        <template slot="title">
          <i class="el-icon-collection"></i>
          <span>接待管理</span>
        </template>
        <el-menu-item-group>
          <template slot="title"></template>
          <el-menu-item index="6-1" class="span"  @click="addTab('接待登记管理')">接待登记管理</el-menu-item>
          <el-menu-item index="6-2" class="span"  @click="addTab('老人资料管理')">老人资料管理</el-menu-item>
        </el-menu-item-group>
      </el-submenu>



      

      
      <el-submenu index="2">
        <template slot="title">
          <i class="el-icon-collection"></i>
          <span>床位管理</span>
        </template>
        <el-menu-item-group>
          <template slot="title"></template>
          <el-menu-item index="2-1" class="span"  @click="addTab('楼房资料管理')">楼房资料管理</el-menu-item>
          <el-menu-item index="2-2" class="span"  @click="addTab('房间资料')"> 房间资料</el-menu-item>
        </el-menu-item-group>
      </el-submenu>

      <el-submenu index="10">
        <template slot="title">
          <i class="el-icon-collection"></i>
          <span>出库管理</span>
        </template>
        <el-menu-item-group>
          <template slot="title"></template>
          <el-menu-item index="10-1" class="span"  @click="addTab('药品出库管理')">药品出库管理</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      
      <el-submenu index="3">
        <template slot="title">
          <i class="el-icon-collection"></i>
          <span>系统管理</span>
        </template>
        <el-menu-item-group>
          <template slot="title"></template>
          <el-menu-item index="3-1" class="span"  @click="addTab('用户管理')">用户管理</el-menu-item>
          <el-menu-item index="3-2" class="span"  @click="addTab('角色管理')">角色管理</el-menu-item>
        </el-menu-item-group>
      </el-submenu> 

      <el-submenu index="4">
        <template slot="title">
          <i class="el-icon-collection"></i>
          <span>货物管理</span>
        </template>
        <el-menu-item-group>
          <template slot="title"></template>
          <el-menu-item index="4-1" class="span"  @click="addTab('货物供应商')">货物供应商</el-menu-item>
          <el-menu-item index="4-2" class="span"  @click="addTab('货物分类管理')">货物分类管理</el-menu-item>
          <el-menu-item index="4-3" class="span"  @click="addTab('货物信息管理')">货物信息管理</el-menu-item>
          <el-menu-item index="4-4" class="span"  @click="addTab('货物采购管理')">货物采购管理</el-menu-item>
          <el-menu-item index="4-5" class="span"  @click="addTab('货物订单管理')">货物订单管理</el-menu-item>
        </el-menu-item-group>
      </el-submenu>


      <el-submenu index="5">
        <template slot="title">
          <i class="el-icon-collection"></i>
          <span>药品管理</span>
        </template>
        <el-menu-item-group>
          <template slot="title"></template>
          <el-menu-item index="5-1" class="span"  @click="addTab('药品供应商')">药品供应商</el-menu-item>
          <el-menu-item index="5-2" class="span"  @click="addTab('药品分类')">药品分类</el-menu-item>
          <el-menu-item index="5-3" class="span"  @click="addTab('药品信息管理')">药品信息管理</el-menu-item>
          <el-menu-item index="5-4" class="span"  @click="addTab('药品采购管理')">药品采购管理</el-menu-item>
          <el-menu-item index="5-5" class="span"  @click="addTab('药品订单管理')">药品订单管理</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      <el-submenu index="7">
        <template slot="title">
          <i class="el-icon-collection"></i>
          <span>老人管理</span>
        </template>
        <el-menu-item-group>
          <template slot="title"></template>
          <el-menu-item index="7-1" class="span"  @click="addTab('病情登记')">病情登记</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
<!-- 

      <el-submenu index="1">
        <template slot="title">
          <i class="el-icon-collection"></i>
          <span>接待管理</span>
        </template>
        <el-menu-item-group>
          <template slot="title"></template>
          <el-menu-item index="6-1" class="span"  @click="addTab('接待登记管理')">接待登记管理</el-menu-item>
        </el-menu-item-group>
      </el-submenu> -->


      <el-submenu index="5">
        <template slot="title">
          <i class="el-icon-collection"></i>
          <span>药品管理</span>
        </template>
        <el-menu-item-group>
          <template slot="title"></template>
          <el-menu-item index="5-1" class="span"  @click="addTab('药品信息管理')">药品信息管理</el-menu-item>
          <el-menu-item index="5-2" class="span"  @click="addTab('药品采购管理')">药品采购管理</el-menu-item>
          <el-menu-item index="5-3" class="span"  @click="addTab('药品订单管理')">药品订单管理</el-menu-item>
        </el-menu-item-group>
      </el-submenu>



      <el-submenu index="1">
        <template slot="title">
          <i class="el-icon-s-custom"></i>
          <span style=" font-size: 20px;">用户管理</span>
        </template>
        <el-menu-item-group>
          <template slot="title"></template>
          <el-menu-item index="1-1"  class="span"><router-link to="/login" style="display: block;   text-decoration: none; width: 100%; height: 100%;">登录</router-link></el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      <el-submenu index="5">
        <template slot="title">
          <i class="el-icon-office-building"></i>
          <span>楼房资料</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="5-1" class="span" @click="houseTab"></el-menu-item>
        </el-menu-item-group>
      </el-submenu>
    </el-menu>
  </el-col>
</el-row>
</el-aside>



  <el-container>
  <el-header :style="{ marginLeft: isCollapse ? '-155px' : '-20px' }"
  >
  <el-row>
  <el-col :span="1">
    <div class="grid-content bg-purple-light">
    <span class="menu-collapse-btn" @click="handleCollapse">
       <i class="el-icon-s-unfold" v-if="isCollapse"></i>
        <i class="el-icon-s-fold" v-else></i>
  </span>
  </div></el-col>
  <el-col :span="9"><div class="grid-content bg-purple" style="margin-top:20px"> 
     <el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item v-for="(item, index) in breadcrumbs" :key="index">
    {{ item }}
  </el-breadcrumb-item>
</el-breadcrumb>
</div></el-col>
  <el-col :span="6"><div class="grid-content bg-purple-light">

    <span style="text-align: left;">
     赣州宏图科技有限公司后台管理系统</span>
  </div></el-col>

  <el-col :span="8"><div class="grid-content bg-purple">

    <el-dropdown>
  <span class="el-dropdown-link">
    {{welcomeMessage}}<i class="el-icon-arrow-down el-icon--right"></i>
  </span>
  <el-dropdown-menu slot="dropdown">
    <el-dropdown-item>{{role}}</el-dropdown-item>
    <el-dropdown-item><a @click="add()">修改密码</a></el-dropdown-item>
    <el-dropdown-item divided><a @click="delToken">退出系统</a></el-dropdown-item>
  </el-dropdown-menu>
</el-dropdown>
  </div></el-col>
</el-row>

</el-header>
      <el-main class="main" :style="{ marginLeft: isCollapse ? '-155px' : '-20px' }"> 
      
      <el-tabs v-model="editableTabsValue" type="card" closable @tab-remove="removeTab" @tab-click="handleTabClick"  style="margin-top: -20px;">
      <el-tab-pane
        v-for="(item) in editableTabs"
        :key="item.name"
        :label="item.title"
        :name="item.name"
      >
        <component :is="item.componentName" :data="item.data" v-if="item.componentName"></component>
      </el-tab-pane>
    </el-tabs>


    <router-view></router-view>

    </el-main>

      <el-footer><span>Copyright© 2021- 赣州宏图网络科技有限公司 ALL RIGHTS RESERVED</span></el-footer>
  
  </el-container>

</el-container>

<el-dialog
      title="修改个人密码"
      :visible.sync="centerDialogVisible"
      width="30%"
      center>
      <el-form :model="dataForm" ref="dataForm" :rules="dataRule" inline label-width="100px" style="width:100%;">
        <el-row>
          <el-col :span="24">
            <el-form-item prop="passWord" label="旧密码">
              <el-input v-model="dataForm.passWord"/>
            </el-form-item>
    
            <el-form-item prop="newpassWord" label="新密码">
              <el-input v-model="dataForm.newpassWord"/>
            </el-form-item>
    
            <el-form-item prop="cfgpwdpassWord" label="确认密码">
              <el-input v-model="dataForm.cfgpwdpassWord"/>
            </el-form-item>
          </el-col>
        </el-row>
    
      </el-form>
      <span slot="footer" class="dialog-footer">
          <el-button @click="centerDialogVisible = false">取 消</el-button>
          <el-button type="primary"  @click="upload()">确 定</el-button>
        </span>
    </el-dialog>
    
    </div>
</template>
<script>

import Tab1Component from "../views/床位管理/bedmanage.vue";
import Tab2Component from "../views/接待管理/接待登记/Reception.vue";
import Tab3Component from "../views/床位管理/bedmanage.vue";
import Tab4Component from "../views/采购清单/index.vue";
import Tab5Component from "../views/药品管理/药品信息/Drug.vue";
import Tab6Component from "../views/采购清单/药品列表/index.vue";
import Tab7Component from "../views/房间资料/index.vue";
import Tab8Component from "../views/采购清单/药品入库/index.vue";
import Tab9Component from "../views/床位管理/house.vue";
import Tab10Component from "../views/病情登记/index.vue";
import Tab11Component from "../views/病情登记/index.vue";
import Tab12Component from "../views/用户管理/index.vue";
import Tab120Component from "../views/采购清单/index.vue";
import Tab121Component from "../views/采购清单/货物列表/index.vue";
import Tab122Component from "../views/采购清单/货物入库/index.vue";
import Tab123Component from "../views/采购清单/药品出库/index.vue";

//import {getpassword} from '../../api/user'
export default {
  name:'C_',
  components:{
  },
  data() {
    return {
      breadcrumbs: ['首页'], 
      isCollapse: false,
      activeMenuIndex: '',
      dataForm:{
                   passWord:'',
                   newpassWord:'',
                   cfgpwdpassWord:'',
          },
          dataRule:{
            passWord: [
                { required: true, message: '旧密码不能为空', trigger: 'blur' }
            ],
            newpassWord: [
                { required: true, message: '新密码不能为空', trigger: 'blur' }
            ],
            cfgpwdpassWord: [
                { required: true, message: '确认密码不能为空', trigger: 'blur' },  
            ],
        },

      welcomeMessage:this.$Cookie.get('userName'),
      role:this.$Cookie.get('role'),
      // handleOpen: '',
      // handleClose: '',
      centerDialogVisible: false,
      circleUrl:'http://localhost:8080/SpringMvc1/upload/20231126/287bc994-d596-48e0-945a-bffe43d2bb61.jpeg',
      username:'',
      editableTabsValue: "1",
      editableTabs: [
        {
          title: "首页",
          name: "1",
          componentName: "Tab1Component",
          data: {}, // 组件需要的数据,
          active: true 
        },
      ],
      tabIndex: 2,
    };
  },
  components: {
    Tab1Component,
    Tab2Component,
    Tab3Component,
    Tab4Component,
    Tab5Component,
    Tab6Component,
    Tab7Component,
    Tab8Component,
    Tab9Component,
    Tab10Component,
    Tab11Component,
    Tab12Component,
    Tab120Component,
    Tab121Component,
    Tab122Component,
    Tab123Component
  },
  created() {
      if (this.$Cookie.get('token') === undefined || this.$Cookie.get('token') === '') {
        this.$router.push('/login');
      }
      const username = localStorage.getItem('username');
      if (username) {
        this.$store.commit('setUserName', username);
      }
    },
  methods: {
    handleCollapse() {
      this.isCollapse = !this.isCollapse;
    },

    add(){
    this.centerDialogVisible = true
},

upload() {
  if(this.dataForm.newpassWord!=this.dataForm.cfgpwdpassWord){
        this.$message.error('新密码与确认密码不一致');
        return
  }
       let formData = new FormData();
      formData.append('password', this.dataForm.passWord);
      formData.append('newpassword', this.dataForm.newpassWord);
    this.$refs['dataForm'].validate((valid) => {
      if (valid) {
        getpassword(formData).then(res => { 
        if(res.codes==201){
          this.centerDialogVisible = true
        }else{
        this.centerDialogVisible = false
        this.$router.push('/login');
        this.$Cookie.remove('passWord');
        }
        this.$message({
          message: res.msg,
          type: 'success'
        });
      }).catch(error => {
        this.$message.error('你没有修改个人密码的权限,请与系统管理员联系');
      }); 
      }
    })
    },

    handleCommand(){

    },

    handleOpen(key, keyPath) {
        console.log(key, keyPath);
        this.activeMenuIndex = key;
        
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
        if (this.activeMenuIndex === key) {
         this.activeMenuIndex = '';
        }
      },
      delToken() {
     this.$confirm('此操作将退出该系统, 是否继续?', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    localStorage.removeItem('username');
      this.$Cookie.remove("token")
            this.$Cookie.remove('userName');
            this.$Cookie.remove('passWord');
    this.$notify({
      title: '退出成功',
      message: '欢迎再次回来！',
      type: 'success'
    });
    this.$router.push('/login');
  }).catch(() => {
    this.$message({
            type: 'info',
            message: '已取消此操作'
          });          
  });
},
handleTabClick(tab) {
  const currentTab = this.editableTabs.find(item => item.name === tab.name);
  this.breadcrumbs = currentTab.breadcrumbs;
},
addTab(type) {
  let existingTab = this.editableTabs.find(tab => tab.title === type);
  if (existingTab) { // 如果同名标签页已存在，则将其设置为当前选中的标签页
    this.editableTabsValue = existingTab.name;
    this.breadcrumbs = existingTab.breadcrumbs; // 更新面包屑导航
  } else { // 如果同名标签页不存在，则添加新的标签页
    let newTabName = ++this.tabIndex + "";
    let componentName = ""; // 需要添加的组件名称
    let breadcrumbs = ['首页']; // 默认面包屑导航

    // 根据按钮名选择对应组件和面包屑导航
    if (type === '床位管理') {
      componentName = "Tab1Component";
      breadcrumbs.push('数据管理', '床位管理');
    }
    if (type === '楼房资料管理') {
      componentName = "Tab9Component";
      breadcrumbs.push('床位管理', '楼房资料管理');
    }
    if (type === '首页') {
      componentName = "Tab1Component";
      breadcrumbs.push('首页');
    }
    if (type === '接待登记管理') {
      componentName = "Tab2Component";
      breadcrumbs.push('接待管理', '接待登记管理');
    }
    if (type === '物品管理') {
      componentName = "Tab4Component";
      breadcrumbs.push('采购清单', '物品管理');
    }

    if (type === '药品信息管理') {
      componentName = "Tab5Component";
      breadcrumbs.push('药品管理', '药品信息管理');
    }

    
    if (type === '药品采购管理') {
      componentName = "Tab6Component";
      breadcrumbs.push('药品管理', '药品采购管理');
    }
    if (type === '房间资料') {
      componentName = "Tab7Component";
      breadcrumbs.push('数据管理', '房间资料');
    }
    if (type === '药品订单管理') {
      componentName = "Tab8Component";
      breadcrumbs.push('药品管理', '药品订单管理');
    }

    if (type === '药品出库管理') {
      componentName = "Tab123Component";
      breadcrumbs.push('药品管理', '药品出库管理');
    }


    if (type === '病情登记') {
      componentName = "Tab10Component";
      breadcrumbs.push('老人管理', '入住登记信息');
    }

    if (type === '老人资料管理') {
      componentName = "Tab11Component";
      breadcrumbs.push('接待管理', '老人资料管理');
    }
    if (type === '用户管理') {
      componentName = "Tab12Component";
      breadcrumbs.push('系统管理', '用户管理');
    }
    // if (type === '角色管理') {
    //   componentName = "Tab13Component";
    //   breadcrumbs.push('系统管理', '角色管理');
    // }




    if (type === '货物信息管理') {
      componentName = "Tab120Component";
      breadcrumbs.push('货物管理', '货物信息管理');
    }
    if (type === '货物采购管理') {
      componentName = "Tab121Component";
      breadcrumbs.push('货物管理', '货物采购管理');
    }
    if (type === '货物订单管理') {
      componentName = "Tab122Component";
      breadcrumbs.push('货物管理', '货物订单管理');
    }

    this.editableTabs.push({
      title: type,
      name: newTabName,
      componentName: componentName,
      data: {}, // 组件需要的数据
      breadcrumbs: breadcrumbs // 存储面包屑导航信息
    });
    this.editableTabsValue = newTabName;
    this.breadcrumbs = breadcrumbs; // 更新面包屑导航
  }
},






    removeTab(targetName) {
      let tabs = this.editableTabs;
      let activeName = this.editableTabsValue;
      if (activeName === targetName) {
        tabs.forEach((tab, index) => {
          if (tab.name === targetName) {
            let nextTab = tabs[index + 1] || tabs[index - 1];
            if (nextTab) {
              activeName = nextTab.name;
            }
          }
        });
      }
      this.editableTabsValue = activeName;
      this.editableTabs = tabs.filter((tab) => tab.name !== targetName);
      this.breadcrumbs = this.editableTabs.find(tab => tab.name === activeName).breadcrumbs;
    },
  },
};
</script>
<style scoped>
.main{
  
 color: #333;
 height:0;
 flex-grow:1;
  text-align: center;
  height: calc(100vh - 100px);

}
.menu-collapse-btn {
  cursor: pointer;
  font-size: 20px;
  margin-top: 10px;
  text-align: center;
}

.menu-collapse-btn i {
  transition: transform 0.3s;
}

.menu-collapse-btn i.el-icon-s-unfold {
  transform: rotate(180deg);
}

.menu-collapse-btn i.el-icon-s-fold {
  transform: rotate(0);
}
.el-header .router-link-exact-active {
  text-decoration: none;
}
.el-header {
  display: block;   text-decoration: none; width: 100%; height: 100%;
}
span{
  font-size: 20px;
text-align:center;
    cursor: pointer;
  
}
.span{
  font-size: 20px;
}
.el-header, .el-footer {
  background-color: white;
  color: #1a1919;
  text-align: center;
  line-height: 60px;

}

.el-aside {
  background-color: white;
  color: #333;
  font-size: 1px;
  text-align: center;
  line-height: 200px;
}

/* .el-main {
  background-color: #E9EEF3;
  color: #333;
  text-align: center;
  line-height: 160px;
} */

body > .el-container {
  margin-bottom: 40px;
}
body{
  overflow: hidden; 
}
.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
</style>


<style>
  .el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 200px;
    min-height: 400px;
  }
</style>
