<template>
  <div  v-permission="'77'">
    <table align="center" width="900px">
      <tr>
        <td>
          <el-form :inline="true" v-model="listQuery">
            <el-row :span="24">
              <el-autocomplete
                v-model="listQuery.drugName"
                :fetch-suggestions="querySearch"
                clearable
                class="inline-input w-50"
                placeholder="请输入药品名称"
                @select="handleSelect"
              />
  
              <el-form-item prop="drugF">
  <el-select v-model="listQuery.drugF" placeholder="请选择药品分类" clearable>
    <el-option v-for="c in f" :key="c.drugID" :label="c.drugNames" :value="c.drugID.toString()"/>
  </el-select>
</el-form-item>

<el-form-item prop="supplier">
  <el-select v-model="listQuery.g" placeholder="请选择供应商" clearable>
    <el-option v-for="c in p" :key="c.supplierId" :label="c.supplierName" :value="c.supplierId.toString()"/>
  </el-select>
</el-form-item>
              <el-button
                type="primary"
                style="margin-top: 8px; margin-left: 8px"
                icon="el-icon-search"
                @click="refreshSchoolList()"
                >搜索</el-button
              >
              <el-button
                type="primary"
                style="margin-top: 8px"
                icon="el-icon-plus"
                @click="add"
                plain
                v-permission="'77'"
                >采购</el-button
              >
            </el-row>
          </el-form>
        </td>
      </tr>
    </table>
 

    
    <el-table :data="Drug" border style="width:100%" fit>
      <el-table-column prop="drugID" label="药品ID"></el-table-column>
      <el-table-column prop="drugName" label="药品名称"></el-table-column>
      <el-table-column prop="drugPic" label="药品图" :width="80">
        <template slot-scope="scope">
          <div v-if="!scope.row.drugPic">待上传</div>
          <img
            v-else
            :src="baseApi + scope.row.drugPic"
            alt="已上传"
            width="50"
            height="50"
          />
        </template>
      </el-table-column>
      <el-table-column prop="price" label="药品进价(元)"></el-table-column>
      <el-table-column prop="style" label="药品单位"></el-table-column>  
      <el-table-column prop="p" label="药品分类"></el-table-column>  
      <el-table-column prop="g" label="药品供应商"></el-table-column>
      <el-table-column prop="drugP" label="药品批准文号"></el-table-column>
      <el-table-column prop="drugM" label="药品备注"></el-table-column>
      <el-table-column prop="drug.drugM" label="小计">
        <template
         slot-scope="scope">
         <div v-if="selectedValues[scope.row.drugID] !== undefined && selectedValues[scope.row.drugID] !== null && selectedValues[scope.row.drugID] !== 0">
￥{{ selectedValues[scope.row.drugID] * scope.row.price }}元
</div>
        
        </template>

      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-input-number
          controls-position="right"
                v-model="selectedValues[scope.row.drugID]"
                :min="0"
                :max="20"
                :style="{ width: '100px' }"
                size="mini"
                @change="handleValueChange(scope.row.drugID)"
              />
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="listQuery.Current"
        :page-sizes="[10, 20, 50]"
        :page-size="listQuery.size"
        layout="total, sizes, prev, pager, next, jumper"
        :total="listQuery.total"
      >
        <!-- //总页数 -->
      </el-pagination>
    </div>
    <add-or-update
    v-if="addOrUpdateVisible"
    ref="AddOrUpdate"
    @refreshReturnData="refreshSchoolList"
    @z="z"
  />
  </div>
</template>
    
    <script>
import { add } from "../../../api/采购清单/Ord";
import { list, del, zd } from "../../../api/药品管理/Drug";
import {fp} from '../../../api/采购清单/Order';
import AddOrUpdate from "./indexAdd.vue";
export default {
  name: "Drug_",
  components: {
  AddOrUpdate,
},
  data() {
    return {
      baseApi: process.env.VUE_APP_BASE_API, //后台接口地址
      suggestions: [], //客户名称自动弹窗
      suggestions2: [], //客户访问事由地址自动弹窗
      f: [],
        p: [],
      listQuery: {
        //添加查询条件
        drugID: "", //药品id
        drugName: "", //药品名称
        drugF: "", //药品分类
        size: 10, //每页多少条数据
        Current: 1, //默认第一页
        total: 0, //总页数
      },
      selectedValues: {},
      orderList: [], // 保存订单数据
      Drug: [], //列表
      addOrUpdateVisible: false, //新增修改弹窗
    };
  },
  methods: {
    
    handleValueChange(drugID) {
      // 当选择器的值发生变化时，可以在这里处理逻辑
      const selectedValue = this.selectedValues[drugID];
      console.log(`Drug ${drugID}: ${selectedValue}`);
      if (selectedValue > 0) {
        const orderItem = {
          drugID: drugID,
          quantity: selectedValue,
        };
        this.orderList.push(orderItem);
      }
    },
    querySearch(queryString, cb) {
      this.listQuery.drugName = queryString;
      zd(this.listQuery)
        .then((res) => {
          // 使用 Set 来过滤不重复的 item.DrugName 值
          const uniqueNames = new Set();
          this.suggestions2 = res.list.reduce((uniqueList, item) => {
            if (!uniqueNames.has(item.drugName)) {
              uniqueNames.add(item.drugName);
              uniqueList.push({
                value: item.drugName,
                link: item.link,
              });
            }
            return uniqueList;
          }, []);
          cb(this.suggestions2);
        })
        .catch((error) => {
          console.error("Error fetching restaurant list:", error);
        });
    },
    handleSelect(item) {
      console.log(item);
    },
    querySearch2(queryString, cb) {
      this.listQuery.drugF = queryString;
      zd(this.listQuery)
        .then((res) => {
          // 使用 Set 来过滤不重复的 item.drugF 值
          const uniqueNames = new Set();
          this.suggestions2 = res.list.reduce((uniqueList, item) => {
            if (!uniqueNames.has(item.drugF)) {
              uniqueNames.add(item.drugF);
              uniqueList.push({
                value: item.drugF,
                link: item.link,
              });
            }
            return uniqueList;
          }, []);
          cb(this.suggestions2);
        })
        .catch((error) => {
          console.error("Error fetching restaurant list:", error);
        });
    },

    handleSizeChange(val) {
      // console.log(`每页 ${val} 条`);
      this.listQuery.size = val;
      this.refreshSchoolList();
    },
    handleCurrentChange(val) {
      //   console.log(`当前页: ${val}`);
      this.listQuery.Current = val;
      this.refreshSchoolList();
    },

    z(){
      this.selectedValues = {};
    },

    //条件.分页.查询列表
    refreshSchoolList() {
      console.log(this.listQuery);
if(this.listQuery.drugName !=''||this.listQuery.drugF !='' || this.listQuery.drugID !=''){
  this.listQuery.Current=1;
}
      list(this.listQuery)
        .then((res) => {
          this.Drug = res.page.records;
          console.log(this.Drug);
          this.listQuery.total = res.page.total;
        })
        .catch((error) => {
          this.$message.error("你没有查询药品表数据的权限,请与系统管理员联系");
        });
    },
    add() {
      const hasSelectedValues = Object.values(this.selectedValues).some(value => value !== undefined && value > 0);
  if (!hasSelectedValues) {
    this.$message.error("请先选择药品数量");
    return;
  }      
       let formData = new FormData();
       const selectedItems = []; // 定义空数组
for (const key in this.selectedValues) {
  if (this.selectedValues.hasOwnProperty(key)) { // 确保只遍历对象自身的属性
    const value = this.selectedValues[key];
    if (value !== undefined) { // 使用严格相等运算符检查是否为undefined

      selectedItems.push({ drug: `${key}`, quantity: `${value}` });

    }
  }
}
   
          
const requestData = { Ord: selectedItems }; // 构造请求体数据
// formData.append("Ord", jsonSelectedItems);
console.log(requestData);
    this.addOrUpdateVisible = true;
    if (hasSelectedValues) {
      this.$nextTick(() => {
        this.$refs.AddOrUpdate.init(requestData);
      });
    }

          // add(requestData)
          //   .then((res) => {
          //     // this.centerDialogVisible = false;
          //     this.selectedValues = {};
          //     this.$message({
          //       message: res.msg,
          //       type: "success",
          //     });
          //     this.$emit("refreshReturnData");
          //   })
          //   .catch((error) => {
          //     this.$message.error("你没有新增数据的权限,请与系统管理员联系");
          //   });
      },
  },
  created() {
    this.refreshSchoolList();
    fp()
        .then((res) => {
      this.p = res.g;
      this.f = res.f;
      console.log(this.f);
      console.log(this.p);
        })
        .catch((error) => {
        });
  },
};
</script>
    
    <style>
.box-card {
  box-sizing: border-box;
  background-color: #ffffff;
  border: 1px solid #ccc;
}

</style>