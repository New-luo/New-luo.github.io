<template>
    <el-dialog  
      :visible.sync="centerDialogVisible"
      width="75%"
      center
    >
    <h1>当前订单信息:</h1>
      <el-table :data="tableData" border>
        <el-table-column prop="DrugID" label="药品id"></el-table-column> 
        <el-table-column prop="DrugName" label="药品名称"></el-table-column>
        <el-table-column prop="DrugF" label="药品分类"></el-table-column>
        <el-table-column prop="DrugPic" label="药品图">
            <template slot-scope="scope">
          <div v-if="!scope.row.DrugPic">待上传</div>
          <img
            v-else
            :src="baseApi + scope.row.DrugPic"
            width="50"
            height="50"
          />
        </template>
        </el-table-column>
        <el-table-column prop="Price" label="单价"></el-table-column>
        <el-table-column prop="Prodcount" label="数量"></el-table-column> 
        <el-table-column prop="style" label="单位"></el-table-column> 
        <el-table-column prop="DrugP" label="批准文号"></el-table-column> 
        <el-table-column prop="DrugM" label="药品描述"></el-table-column> 
        <el-table-column prop="supplier" label="供应商"></el-table-column> 
        <el-table-column prop="X" label="小计"></el-table-column> 
      </el-table>
    </el-form>
      <span slot="footer" class="dialog-footer" style="display: flex; justify-content: flex-end;">
    <el-button @click="centerDialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="table()">提交 </el-button>
</span>




    </el-dialog>
  </template>
  
  <script>
  import { DetailsList,add,update} from "../../../api/采购清单/Order";
  import { add1 } from "../../../api/采购清单/Ord";
  
  export default {
    data() {
      return {
        dataForm: {
        prodid: 0,
        prodname: "",
        unitname: "",
        pic: "",
        drugM:"",
        c:"",
        style: "",
        price: "",
        supplierid: "",
      },
        baseApi: process.env.VUE_APP_BASE_API, // 后台接口地址
        centerDialogVisible: false,
        tableData: [],

        dataRule:{
            personId:[
                { required: true, message: '领用人不能为空', trigger: 'blur' }
            ],
        },
      };
    },
    methods: {
      table(){
         add1(this.c)
            .then((res) => {
              // this.centerDialogVisible = false;
              this.selectedValues = {};
              this.centerDialogVisible =false;
              this.$message({
                message: res.msg,
                type: "success",
              });
              this.$emit("refreshReturnData");
              this.$emit("z");
        
            })
            .catch((error) => {
              this.$message.error("你没有新增数据的权限,请与系统管理员联系");
            });
      },
      init(requestData) {
        this.centerDialogVisible = true;
        console.log("====================");
        console.log(requestData);
        this.c = requestData;
        console.log("====================");
        add(requestData)
          .then((res) => {
            console.log(res.page);
            this.tableData = res.page;
            console.log(this.tableData);
          })
          .catch((error) => {
            this.$message.error("你没有新增数据的权限,请与系统管理员联系");
          });
      },
    },
  };



  </script>
  <style>
</style>
  