<template>
    <el-dialog  
      :visible.sync="centerDialogVisible"
      width="80%"
      center
    >
    <el-form
      :model="dataForm"
      ref="dataForm"
      :rules="dataRule"
      inline
      label-width="100px"
      style="width: 100%"
    >
      <el-row>
        <!-- 左侧内容 -->
        <el-col :span="12">
          <router-link to="/12">
    <el-form-item prop="personId" label="领用人:">
      <el-input v-model="dataForm.personId" :disabled="true" />
    </el-form-item>
  </router-link>
  </el-col>
        <!-- 右侧内容 -->
        <el-col :span="12">
          <el-form-item prop="drugM" type="textarea" label="货物描述:">
            <el-input v-model="dataForm.drugM"/>
          </el-form-item>
        </el-col>
      </el-row>
      <el-table :data="tableData" border>
        <el-table-column prop="DrugID" label="货物id"></el-table-column> 
        <el-table-column prop="DrugName" label="货物名称"></el-table-column>
        <el-table-column prop="DrugF" label="货物分类"></el-table-column>
        <el-table-column prop="DrugPic" label="货物图">
            <template slot-scope="scope">
          <div v-if="!scope.row.DrugPic">待上传</div>
          <img
            v-else
            :src="baseApi + scope.row.DrugPic"
            width="50"
            height="50"
          />
        </template>
        </el-table-column>
        <el-table-column prop="Price" label="单价"></el-table-column>
        <el-table-column prop="Prodcount" label="数量"></el-table-column> 
        <el-table-column prop="style" label="单位"></el-table-column> 
        <el-table-column prop="DrugM" label="货物描述"></el-table-column> 
        <el-table-column prop="supplier" label="供应商"></el-table-column> 
        <el-table-column prop="X" label="小计(元)"></el-table-column> 
      </el-table>
    </el-form>
      <span slot="footer" class="dialog-footer" style="display: flex; justify-content: flex-end;">
    <el-button @click="centerDialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="table()">出库</el-button>
</span>




    </el-dialog>
  </template>
  
  <script>
  import { DetailsList,adds,updates} from "../../../api/采购清单/Order";
  
  export default {
    data() {
      return {
        dataForm: {
        prodid: 0,
        prodname: "",
        unitname: "",
        pic: "",
        drugM:"",
        style: "",
        price: "",
        supplierid: "",
        personId:this.$route.query.name,
      },
        baseApi: process.env.VUE_APP_BASE_API, // 后台接口地址
        centerDialogVisible: false,
        tableData: [],

        dataRule:{
            personId:[
                { required: true, message: '领用人不能为空请前往老人资料', trigger: 'blur' }
            ],
        },
      };
    },
    methods: {
      table(){
        this.$refs['dataForm'].validate((valid) => {
      if (valid) {
        let requestData = {
        list: this.tableData,
        personId: this.dataForm.personId,
        drugM: this.dataForm.drugM
      };
        updates(requestData)
          .then((res) => {
            this.$message({
          message: res.msg,
          type: 'success'
        });
            this.centerDialogVisible =false;
            this.$emit('refreshReturnData')
            this.$emit('z')

            this.dataForm.personId ='';
          this.dataForm.drugM="";

          })
          .catch((error) => {
            this.$message.error("你没有新增数据的权限,请与系统管理员联系");
          });

      }
    })
 },
      init(requestData) {
        this.centerDialogVisible = true;
        adds(requestData)
          .then((res) => {
            console.log(res.page);
            this.tableData = res.page;

            console.log(this.tableData);
          })
          .catch((error) => {
            this.$message.error("你没有新增数据的权限,请与系统管理员联系");
          });
      },
    },
  };
  </script>
  