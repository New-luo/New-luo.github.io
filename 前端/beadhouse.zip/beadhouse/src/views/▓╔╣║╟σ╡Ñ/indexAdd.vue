<template>
  <el-dialog
    :title="dataForm.prodid > 0 ? '修改' : '新增'"
    :visible.sync="centerDialogVisible"
    width="60%"
    center
  >
    <el-form
      :model="dataForm"
      ref="dataForm"
      :rules="dataRule"
      inline
      label-width="100px"
      style="width: 100%"
    >
      <el-row>
        <!-- 左侧内容 -->
        <el-col :span="12">
          <el-form-item prop="prodname" label="物品名称:">
            <el-input v-model="dataForm.prodname" />
          </el-form-item>

          <el-form-item prop="unitname" label="物品单位">
            <el-input v-model="dataForm.unitname" />
          </el-form-item>

          <el-form-item prop="style" label="物品分类">
  <el-select v-model="dataForm.style" placeholder="请选择物品分类" clearable>
    <el-option v-for="c in f" :key="c.productId" :label="c.productName" :value="c.productId.toString()"/>
  </el-select>
</el-form-item>
          <el-form-item prop="price" label="价格:">
            <el-input v-model="dataForm.price" />
          </el-form-item>

          <el-form-item prop="supplierid" label="供应商">
  <el-select v-model="dataForm.supplierid" placeholder="请选择供应商" clearable>
    <el-option v-for="c in p" :key="c.supplierId" :label="c.supplierName" :value="c.supplierId.toString()"/>
  </el-select>
</el-form-item>
        </el-col>

        <!-- 右侧内容 -->
        <el-col :span="12">
          <el-form-item :label="img ? '更新物品Log:' : '选择物品Log:'">
            <div style="text-align: center">
              <input type="file" @change="onFileChange" multiple /><br />
              <div style="display: flex; justify-content: center">
                <div v-if="img">
                  <img :src="baseApi + img" style="width: 100px" />
                </div>
                <div v-if="previewImage">
                  <img :src="previewImage" alt="preview" style="width: 100px" />
                </div>
              </div>
            </div>
          </el-form-item>
          <el-form-item prop="drugM" label="货物描述:">
            <el-input v-model="dataForm.drugM"/>
          </el-form-item>

        </el-col>
      </el-row>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="centerDialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="upload()">确 定</el-button>
    </span>
  </el-dialog>
</template>
    <script>
import { add, getid ,fp} from "../../api/采购清单/goods";
export default {
  data() {
    return {
      dataForm: {
        prodid: 0,
        prodname: "",
        unitname: "",
        pic: "",
        drugM:"",
        style: "",
        price: "",
        supplierid: "",
      },
f:"",
p:"",
      baseApi: process.env.VUE_APP_BASE_API, //后台接口地址
      update: false,
      selectedFiles: [],
      img: "", //上传显示图片
      previewImage: "", //修改前图片
      isFileSelected: false,
      centerDialogVisible: false,

      dataRule: {
        prodname: [
          { required: true, message: "物品名称不能为空", trigger: "blur" },
        ],
        style: [
          { required: true, message: "物品分类不能为空", trigger: "blur" },
        ],
        unitname: [
          { required: true, message: "物品单位不能为空", trigger: "blur" },
        ],
        drugM: [
          { required: true, message: "物品描述不能为空", trigger: "blur" },
        ],
        price: [
          { required: true, message: "物品价格不能为空", trigger: "blur" },
        ],
        supplierid: [
          { required: true, message: "物品供应商不能为空", trigger: "blur" },
        ],
      },
    };
  },
  created() {},
  methods: {
    refreshSchoolList() {
      fp()
        .then((res) => {
      this.p = res.g;
      this.f = res.f;
      console.log(this.f);
      console.log(this.p);
        })
        .catch((error) => {
        });
    },
    init(id) {
      this.centerDialogVisible = true;
      getid(id)
        .then((res) => {
          console.log(id);
          if (id > 0) {
            this.previewImage = "";
            document.querySelector('input[type="file"]').value = "";
            let {
              prodid,
              prodname,
              unitname,
              brand,
              style,
              drugM,
              price,
              supplierid
            } = res.data[0];
            this.dataForm = {
              prodid,
              prodname,
              unitname,
              drugM,
              style,
              price,
              supplierid
            };
            this.selectedFiles =  brand;
            this.img = brand;
            this.isFileSelected = true;
          } else {
            this.dataForm.prodid = 0;
            this.dataForm.prodname = "";
            this.dataForm.drugM = "";
            this.dataForm.unitname = "";
            this.dataForm.style = "";
            this.dataForm.price = "";
            this.dataForm.supplierid = "";
            this.selectedFiles = "";
            this.img = "";
            this.previewImage = "";
            this.isFileSelected = false;
            document.querySelector('input[type="file"]').value = "";
          }
        })
        .catch((error) => {
          this.centerDialogVisible = false;
          this.$message.error("你没有修改数据的权限,请与系统管理员联系");
        });
    },

    onFileChange(event) {
      this.isFileSelected = true;
      const files = event.target.files;
      if (files && files.length) {
        const reader = new FileReader();
        reader.onload = (e) => {
          this.previewImage = e.target.result; // 将图片的数据URL赋值给previewImage
        };
        reader.readAsDataURL(files[0]); // 读取文件并将其转换为数据URL
        this.update = true; // 标记为已更新
        this.selectedFiles = files; // 将选择的文件保存到selectedFiles中
        console.log(this.selectedFiles);
      }
    },
    upload() {
      let formData = new FormData();
      formData.append("prodid", this.dataForm.prodid);
      formData.append("prodname", this.dataForm.prodname);
      formData.append("unitname", this.dataForm.unitname);
      formData.append("style", this.dataForm.style);
      formData.append("price", this.dataForm.price);
      formData.append("drugM", this.dataForm.drugM);
      formData.append("supplierid", this.dataForm.supplierid);
      console.log(this.selectedFiles)

            if (!this.update || this.selectedFiles==undefined) {
     
      }else{
        for (let i = 0; i < this.selectedFiles.length; i++) {
          formData.append("pic", this.selectedFiles[i]);
          console.log(this.selectedFiles[i]);
        } 
  }
      this.$refs["dataForm"].validate((valid) => {
        if (valid) {
          add(formData)
            .then((res) => {
              this.centerDialogVisible = false;
              this.$message({
                message: res.msg,
                type: "success",
              });
              this.$emit("refreshReturnData");
            })
            .catch((error) => {
              this.$message.error("你没有新增数据的权限,请与系统管理员联系");
            });
        }
      });
    },
  },
  created() {
    this.refreshSchoolList();
  },
};
</script>