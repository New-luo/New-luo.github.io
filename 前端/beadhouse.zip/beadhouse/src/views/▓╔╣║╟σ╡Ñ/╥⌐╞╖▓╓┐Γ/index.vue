<template>
  <div  v-permission="'91'">
    <table align="center" width="900px">
      <tr>
        <td>
          <el-form :inline="true" v-model="listQuery">
            <el-row :span="24">
              <el-form-item prop="orderno">
                <el-input
                  placeholder="请输入药品名称"
                  v-model="listQuery.name"
                  clearable
                />
              </el-form-item>
              <el-form-item prop="ord">
  <el-select v-model="listQuery.ord" placeholder="请选择药品分类" clearable>
    <el-option v-for="c in f" :key="c.drugID" :label="c.drugNames" :value="c.drugID.toString()"/>
  </el-select>
</el-form-item>

<el-form-item prop="supplier">
  <el-select v-model="listQuery.orderno" placeholder="请选择供应商" clearable>
    <el-option v-for="c in p" :key="c.supplierId" :label="c.supplierName" :value="c.supplierId.toString()"/>
  </el-select>
</el-form-item>
              <el-button
                type="primary"
                style="margin-top: 8px; margin-left: 8px"
                icon="el-icon-search"
                @click="refreshSchoolList()"
                >搜索</el-button
              >
              <!-- <el-button
                type="primary"
                style="margin-top: 8px"
                icon="el-icon-plus"
                @click="add"
                plain
                >领用</el-button
              > -->
            </el-row>
          </el-form>
        </td>
      </tr>
    </table>
    
    <div>
      <el-table :data="Drug" border style="width: 100%" fit>
      <el-table-column prop="drug.drugID" label="药品ID"></el-table-column>
      <el-table-column prop="drug.drugName" label="药品名称"></el-table-column>
      <el-table-column prop="drug.drugPic" label="药品图" :width="80">
        <template slot-scope="scope">
          <div v-if="!scope.row.drug.drugPic">待上传</div>
          <img
            v-else
            :src="baseApi + scope.row.drug.drugPic"
            alt="已上传"
            width="50"
            height="50"
          />
        </template>
      </el-table-column>
      <el-table-column prop="drug.price" label="药品进价(元)"></el-table-column>
      <el-table-column prop="drug.prodcount" label="药品库存">
        <template slot-scope="scope">
          <span :style="{
        color: scope.row.drug.prodcount < 50 ? 'red' : 'black',
        'font-weight': scope.row.drug.prodcount < 50 ? 'bold' : 'normal'
      }">{{ scope.row.drug.prodcount }}</span>
        </template>
      </el-table-column>  
      <el-table-column prop="drug.style" label="药品单位"></el-table-column>  
      <el-table-column prop="drug.drugF" label="药品分类"></el-table-column>  
      <el-table-column prop="drug.supplier" label="药品供应商"></el-table-column>
      <el-table-column prop="drug.drugP" label="药品批准文号"></el-table-column>
      <el-table-column prop="purchase" label="入库日期"></el-table-column>
      <el-table-column prop="expiration" label="过期日期"></el-table-column>
      <el-table-column prop="createdAt" label="登记日期"></el-table-column>
      <el-table-column prop="updatedAt" label="最近更新日期"></el-table-column>
      <el-table-column prop="drug.drugM" label="药品备注"></el-table-column>

    </el-table>
    </div>
    <div class="block">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="listQuery.Current"
        :page-sizes="[10, 20, 50]"
        :page-size="listQuery.size"
        layout="total, sizes, prev, pager, next, jumper"
        :total="listQuery.total"
      >
      </el-pagination>
    </div>
  
  </div>
</template>
    <script>

import { DetailsList,add} from "../../../api/采购清单/Order";
import {fp} from '../../../api/采购清单/Order'

export default {
  name: "Drug_",
  data() {
    return {
      baseApi: process.env.VUE_APP_BASE_API, //后台接口地址
      suggestions: [], //客户名称自动弹窗
      suggestions2: [], //客户访问事由地址自动弹窗
      listQuery: {
        //添加查询条件
        orderno: "", //药品id
        name: "", //药品名称
        ord: "", //药品分类
        size: 10, //每页多少条数据
        Current: 1, //默认第一页
        total: 0, //总页数
      },
      f: [],
        p: [],
      selectedValues: {},
      orderList: [], // 保存订单数据
      Drug: [], //列表
      addOrUpdateVisible: false, //出库弹窗
    };
  },
  methods: {
    handleValueChange(drugID,maxQuantity) {
      // 当选择器的值发生变化时，可以在这里处理逻辑
      const selectedValue = this.selectedValues[drugID] || 0;
      console.log(`Drug ${drugID}: ${selectedValue}`);
   if (selectedValue === maxQuantity) {
    this.$message.error("已达到最大库存数量");
   }

  if (selectedValue > maxQuantity) {
    this.selectedValues[drugID] = maxQuantity;
  }
      if (selectedValue > 0) {
        const drugInfo = this.Drug.find(drug => drug.drug.drugID === drugID);
        if (drugInfo) {
        const orderItem = {
          drugID: drugID,
          quantity: selectedValue,
          drugName: drugInfo.drug.drugName,
          price: drugInfo.drug.price,

        };
        this.orderList.push(orderItem);
        // console.log(this.orderList);
      }
    }
    },
    handleSizeChange(val) {
      // console.log(`每页 ${val} 条`);
      this.listQuery.size = val;
      this.refreshSchoolList();
    },
    handleCurrentChange(val) {
      //   console.log(`当前页: ${val}`);
      this.listQuery.Current = val;
      this.refreshSchoolList();
    },

    //条件.分页.查询列表
    refreshSchoolList() {
      console.log(this.listQuery);
if(this.listQuery.name !=''||this.listQuery.ord !='' || this.listQuery.orderno !=''){
  this.listQuery.Current=1;
}

DetailsList(this.listQuery)
        .then((res) => {
    console.log(res);
          this.Drug = res.list;
          console.log(this.Drug);
          this.listQuery.total = res.page.total;
        })
        .catch((error) => {
          this.$message.error("你没有查询药品表数据的权限,请与系统管理员联系");
        });
    },
    add() {
      
      const hasSelectedValues = Object.values(this.selectedValues).some(value => value !== undefined && value > 0);
  if (!hasSelectedValues) {
    this.$message.error("请先选择药品数量");
    return;
  }      
       let formData = new FormData();
       const selectedItems = []; // 定义空数组         
for (const key in this.selectedValues) {
  if (this.selectedValues.hasOwnProperty(key)) { // 确保只遍历对象自身的属性
    const value = this.selectedValues[key];
    if (value !== undefined) { // 使用严格相等运算符检查是否为undefined
      selectedItems.push({ drug: `${key}`, quantity: `${value}` });
    }
  }
}
selectedItems.forEach(item => {
  console.log(item);
console.log(`药品id：${item.drug}，数量：${item.quantity}`);
});

const requestData = { Ord: selectedItems }; // 构造请求体数据
console.log(requestData);
  
    this.addOrUpdateVisible = true;
    if (hasSelectedValues) {
      this.$nextTick(() => {
        this.$refs.AddOrUpdate.init(requestData);
      });
    }
  
      },
  },

  created() {
    this.refreshSchoolList();
    fp()
        .then((res) => {
      this.p = res.g;
      this.f = res.f;
      console.log(this.f);
      console.log(this.p);
        })
        .catch((error) => {
        });
  },
  
};
</script>
    
    <style>
.box-card {
  box-sizing: border-box;
  background-color: #ffffff;
  border: 1px solid #ccc;
}
</style>