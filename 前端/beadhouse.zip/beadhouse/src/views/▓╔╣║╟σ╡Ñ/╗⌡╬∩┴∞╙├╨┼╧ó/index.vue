<template>
  <div v-permission="'112'">
    <el-row :gutter="20">
<el-col :span="10"><div class="grid-content bg-purple"><h2 style="color:red">请及时处理待入库的请求和申请！！！</h2></div></el-col>
<el-col :span="14"><div class="grid-content bg-purple">
  <el-form :inline="true" v-model="listQuery">
            <el-form-item prop="orderno">
              <el-input
                placeholder="请输入领用单号"
                v-model="listQuery.orderno"
                clearable
              />
            </el-form-item>
            <el-form-item prop="style">
              <el-input
                placeholder="请输入领用人"
                v-model="listQuery.style"
                clearable
              />
            </el-form-item>
            <el-button
              type="primary"
              icon="el-icon-search"
              @click="getOrderList()"
              >搜索</el-button
            >
    </el-form>  
</div></el-col>
</el-row>
    <el-table :data="orderList" border  :span-method="spanMethod">
      <el-table-column prop="orderno" :min-width="10" :height="100"  label="订单号"></el-table-column>
     
      <el-table-column prop="totalprice" :min-width="10" :height="100" label="总价">
          <template slot-scope="scope">
    <h3 v-if="scope.row.orderno in orderTotals">{{ orderTotals[scope.row.orderno] }}元</h3>

  </template>
  </el-table-column> 
  <el-table-column label="订单详情">
  <template slot-scope="scope">
  <el-table :data="scope.row.drugs" border  v-if="showDetails === scope.row.orderno">
    <el-table-column prop="prodname" :min-width="10" :height="100" label="物品名称"/>
    <el-table-column prop="brand" :min-width="10" :height="100" label="物品图片">
      <template slot-scope="scope">
        <div v-if="!scope.row.brand">待上传</div>
        <img
          v-else
          :src="baseApi + scope.row.brand"
          width="100"
          height="100"
        />
      </template>
    </el-table-column>
    <el-table-column prop="prodcount" :min-width="10" :height="100" label="物品数量"/>
    <el-table-column prop="unitname" :min-width="10" :height="100" label="物品单位"/>
    <el-table-column prop="price" :min-width="10" :height="100" label="物品单价"/>
    <el-table-column prop="style" :min-width="10" :height="100" label="物品分类"/>
    <el-table-column prop="supplierid" :min-width="10" :height="100" label="供应商名称"/>
  </el-table>
  <h3>领用人: {{ scope.row.personId}}
   物品种类: {{ scope.row.drugs.length }}种 领用日期: {{ scope.row.orderDate}}</h3>
</template> 
</el-table-column>



<el-table-column prop="totalprice" :min-width="15" :height="500" label="操作">
<template slot-scope="scope">
<div style="display: flex; justify-content: space-between;">
<el-button type="primary" v-if="scope.row.sytle==='0'" size="mini" round @click="openWarehouseDialogs(scope.row.orderno)">入库</el-button>
<el-button type="primary" size="mini"  round @click="toggleDetails(scope.row.orderno)"> {{ showDetails === scope.row.orderno?'隐藏' : '显示' }}详情</el-button>

<el-button type="danger"  size="mini" icon="el-icon-delete"
          circle @click="openWarehouseDialog(scope.row.orderno)"></el-button>
</div>
</template>     
</el-table-column>
</el-table>
    <div class="block">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="listQuery.Current"
      :page-sizes="[10,15, 20, 30, 50]"
      :page-size="listQuery.size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="listQuery.total"
    >
      <!-- //总页数 -->
    </el-pagination>
  </div>

  </div>
</template>

<script>
import {list2,del2,getid} from "../../../api/采购清单/Orders";

export default {
data() {
  return {
    activeName: 'first', // 当前选中的选项卡名称
    showDetails: null, 
    id: '', // 对应的ID值
    listQuery: {
      //添加查询条件
      orderno: "", //订单id
      style: "", //订单状态
      size: 10, //每页多少条数据
      Current: 1, //默认第一页
      total: 0, //总页数
    },
    orderTotals: {},
    orderData: [],
    orderList: [], // 存放订单数据的数组
    baseApi: process.env.VUE_APP_BASE_API, // 
    options: [{
        value: '0',
        label: '待入库'
      }, {
        value: '1',
        label: '已完成'
      }],
  };
},
created() {
  // 在此处获取订单数据，并将其赋值给orderList
  this.getOrderList();
},
methods: {
  toggleDetails(id) {
    if (this.showDetails === id) {
      // 如果当前行已经显示详情，则隐藏
      this.showDetails = null;
    } else {
      // 否则，显示指定ID的详情
      this.showDetails = id;
    }
  },
  openWarehouseDialogs(orderno) {
  console.log("入库订单ID：" + orderno);
  getid(orderno).then(res => {
    this.$message({
                type: "success",
                message: "入库成功!",
              });
    this.getOrderList();
  })
  .catch((error) => {
            this.$message.error("你没有查询数据的权限,请与系统管理员联系");
          });
},

  openWarehouseDialog(orderno) {
  console.log("删除订单ID：" + orderno);
  this.$confirm("此操作将永久删除该记录, 是否继续?", "提示", {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    })
      .then(() => {
        del2(orderno)
          .then((res) => {
            if (res.code == 200) {
              this.$message({
                type: "success",
                message: "删除成功!",
              });
              this.getOrderList();
            }
          })
          .catch((error) => {
            this.$message.error("你没有删除数据的权限,请与系统管理员联系");
          });
      })
      .catch(() => {
        this.$message({
          type: "info",
          message: "已取消删除",
        });
      });
},

handleClick(tab) {
    this.activeName = tab.name; // 更新选中的选项卡名称
    // 根据选项卡名称设置对应的ID值
    switch (tab.name) {
      case 'first':
        this.id = '';
        break;
      case 'second':
        this.id = '1';
        break;
      case 'third':
        this.id = '0';
        break;
      default:
        break;
    }
    console.log(this.id);
this.listQuery.style = this.id;
this.listQuery.Current = 1, //默认第一页

this.getOrderList() 
  },

  handleSizeChange(val) {
    // console.log(`每页 ${val} 条`);
    this.listQuery.size = val;
    this.getOrderList();
  },
  handleCurrentChange(val) {
    //   console.log(`当前页: ${val}`);
    this.listQuery.Current = val;
    this.getOrderList();
  },
getOrderList() {

  if(this.listQuery.orderno > 0){
    this.listQuery.Current = 1 //默认第一页
  }
  
console.log(this.listQuery.orderno)
  list2(this.listQuery)
    .then((res) => {
      console.log(res);
      this.listQuery.total = res.page.total;
      const orderData = res.list;  // 后台返回的数据在res中
      console.log(orderData);
      // 将相同订单号的物品合并到一起
      const mergedOrderList = [];
      for (const order of orderData) {
        const existingOrder = mergedOrderList.find(
          (item) => item.orderno === order.orderno
        );
        if (existingOrder) {
          existingOrder.drugs.push(order.product);
        } else {
          mergedOrderList.push({
            ...order,
            drugs: [order.product],
          });
        }
      }

      this.orderList = mergedOrderList;
      console.log(this.orderList)
      // 计算订单总价
      this.orderList.forEach((order) => {
let totalprice = 0;
order.drugs.forEach((drug) => {
console.log(`Drug price: ${drug.price}`);
console.log(`Drug quantity: ${drug.prodcount}`);
totalprice += drug.price * drug.prodcount;
});
order.totalprice = totalprice;
this.orderTotals[order.orderno] = totalprice;
console.log(`Order ${order.orderno} totalprice: ${totalprice}`);
});

      const totalPriceSum = this.orderList.reduce(
        (sum, order) => sum + order.totalprice,
        0
      );
      console.log(totalPriceSum);
    })
    .catch((error) => {
      this.$message.error("获取订单数据失败，请稍后重试");
    });
},
spanMethod({ row, column, rowIndex, columnIndex }) {
  if (columnIndex === 0) {
    let rowspan = 1;
    for (let i = rowIndex + 1; i < this.orderList.length; i++) {
      if (this.orderList[i].orderno === row.orderno) {
        rowspan++;
      } else {
        break;
      }
    }
    return { rowspan, colspan: 1 };
  }
},
},
};
</script>
<style>

</style>