<template>
  <div style="margin-top: -60px">
    <div class="page-container">
      <div class="chat-window">
        <div class="chat-content">
          <div class="chat-message" v-for="message in messageList" :key="message.id">
            <!-- <div class="timestamp">{{ message.timestamp }}</div> -->
            <div class="avatar" v-if="!message.isUser">
              <img src="./123.png" />
            </div>
            <div class="chat-message-content" :class="{ 'is-user': message.isUser }">
              <span>{{ message.timestamp}}</span></br>
              <span>{{ message.content }}</span>
              <div></div>
              <div></div>
              <div></div>
            </div>
            <div v-if="message.isUser" class="avatar">
              <img src="./1234.png" />
            </div>
          </div>
        </div>
        <div class="chat-end"></div>
      </div>
    </div>
    <div class="chat-input">
      <input v-model="currentMessage" @keyup.enter="sendMessage" type="text" placeholder="请输入您的问题..." />
      <button @click="sendMessage">发送</button>
      <button @click="clearMessageList" style="background-color: red" class="el-icon-delete">清空</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      currentMessage: '',
      messageList: [], // 聊天记录
      isTyping: false,
    };
  },
  created() {
    // 在组件创建时从本地存储加载聊天记录
    const storedMessages = localStorage.getItem('messageList');
    if (storedMessages) {
      this.messageList = JSON.parse(storedMessages);
    }
    this.$nextTick(() => {
      this.scrollToBottom();
    });
  },
  methods: {
    scrollToBottom() {
      const chatContent = document.querySelector('.chat-content');
      chatContent.scrollTop = chatContent.scrollHeight;
    },
    async sendMessage() {
      if (!this.currentMessage) {
        return;
      }

      const question = this.currentMessage;
      this.currentMessage = '';
      const message = {
        id: new Date().getTime(),
        content: question,
        isUser: true,
        isTyping: false,
        timestamp: this.getCurrentTimestamp(),
      };
      this.messageList.push(message);

      try {
        const url = 'https://luckycola.com.cn/ai/openwxyy';
        const data = {
          ques: question,
          appKey: '65324c559cfbe9915ead769b',
          uid: 'GFUFJU1697795157477R4iSgAXjYg',
          isLongChat: 1,
        };
        const response = await axios.post(url, data);
        const answer = response.data.data.result;
        console.log(answer);
        this.isTyping = true;
        const typingMessage = {
          id: new Date().getTime() + 1,
          content: '',
          isUser: false,
          isTyping: true,
          timestamp: this.getCurrentTimestamp(),
        };
        this.messageList.push(typingMessage);
        setTimeout(() => {
          typingMessage.isTyping = false;
          typingMessage.content = answer;
          this.isTyping = false;
          // 将 AI 的回答也保存到本地存储
          localStorage.setItem('messageList', JSON.stringify(this.messageList));
          this.scrollToBottom(); 
        }, 1500);
      } catch (error) {
        console.error(error);
      }

      // 每次发送消息后将聊天记录保存到本地存储
      localStorage.setItem('messageList', JSON.stringify(this.messageList));
    },
    getCurrentTimestamp() {
      const now = new Date();
      const year = now.getFullYear();
      const month = (now.getMonth() + 1).toString().padStart(2, '0');
      const day = now.getDate().toString().padStart(2, '0');
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      const seconds = now.getSeconds().toString().padStart(2, '0');
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    },
    clearMessageList() {
      this.messageList = [];
      localStorage.removeItem('messageList');
    },
  },
};
</script>
<style scoped>
.chat-window {
  flex: 1;
  max-width: 100%;
  margin: 0 auto;
  background-color: #ffffff;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
  border-radius: 5px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.chat-content {
  height: 89vh;
  flex: 1;
  overflow-y: auto; /* 如果聊天内容过多，添加滚动条 */
  scroll-behavior: smooth;
}

.page-container {
  display: flex;
  flex-direction: row;
  height: 89vh;
}

.chat-message {
  display: flex;
  margin-bottom: 20px;
  max-width: 100%;
}

.avatar {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  margin-right: 10px;
}

.avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
}

.chat-message-content {
  padding: 10px 15px;
  border-radius: 5px;
  line-height: 1.5;
  font-size: 14px;
  background-color: #f5f5f5;
  color: #333333;
 
}

.chat-message-content.is-user {
  margin-left: auto;

  background-color: #e6f7ff;
  color: #333333;
}

.chat-message-content.is-user::before {
  content: '';
  display: inline-block;
  position: absolute;
  left: -10px;
  top: 10px;
  width: 0;
  height: 0;
  border-top: 10px solid transparent;
  border-bottom: 10px solid transparent;
  border-right: 10px solid #e6f7ff;
}

.chat-message-content.is-user::after {
  content: '';
  display: inline-block;
  position: absolute;
  left: -8px;
  top: 10px;
  width: 0;
  height: 0;
  border-top: 10px solid transparent;
  border-bottom: 10px solid transparent;
  border-right: 10px solid #f5f5f5;
}

.chat-message-content.is-typing {
  padding-right: 50px;
}

.chat-typing {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
}

.chat-typing div {
  width: 6px;
  height: 6px;
  border-radius: 100%;
  background-color: #999999;
  margin: 0 3px;
  animation: chat-typing 1.2s infinite ease-in-out;
  animation-fill-mode: both;
}

.timestamp {
  font-size: 12px;
  color: #999999;
  margin-top: 5px;
}

.chat-input {
  display: flex;
  border-top: 1px solid #e5e5e5;
  align-items: center;
  padding: 10px;
  position: fixed;
  bottom: 0;
  width: 100%;
  background-color: #ffffff;
}

.chat-input input {
  flex: 1;
  border: none;
  outline: none;
  font-size: 14px;
  padding: 8px;
  border-radius: 5px;
  margin-right: 10px;
}

.chat-input button {
  outline: none;
  border: none;
  background-color: #409eff;
  color: #ffffff;
  font-size: 14px;
  padding: 8px 15px;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.chat-input button:hover {
  background-color: #66a8ff;
}
</style>
