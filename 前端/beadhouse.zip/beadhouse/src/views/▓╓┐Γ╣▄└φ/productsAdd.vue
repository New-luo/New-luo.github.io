<template>
    <el-dialog :title="dataForm.productId > 0 ? '修改' : '新增'" :visible.sync="centerDialogVisible" width="60%" center>
        <el-form :model="dataForm" ref="dataForm" :rules="dataRule" inline label-width="300px" style="width:100%;">
            <el-row>
                <el-col :span="24">
                    <el-form-item prop="productName" label="类别:">
                        <el-input v-model="dataForm.productName" clearable />
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button @click="centerDialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="upload()">确 定</el-button>
        </span>
    </el-dialog>
</template>
<script>
import { list, add, getid } from '../../api/products'
export default {
    data() {
        return {
            dataForm: {
                productId: 0,
                productName: '',

            },
            centerDialogVisible: false,
            dataRule: {
                productName: [
                    { required: true, message: '类别不能为空', trigger: 'blur' }
                ],
            },
        };

    },
    created() {

    },
    methods: {
        init(id) {
            this.centerDialogVisible = true
            getid(id).then(res => {
                if (id > 0) {
                    let { productId, productName } = res.data[0];
                    this.dataForm = {
                        productId, productName
                    };
                } else {
                    this.dataForm.productId = 0;
                    this.dataForm.productName = '';
                }
            }).catch(err => {
                this.centerDialogVisible = false;
                this.$message.error('你没有修改数据的权限,请与系统管理员联系');
            });
        },
        handleDateTimeChange() {
            this.dataForm.visitTime = new Date(this.dataForm.visitTime);
        },


        upload() {
            let formData = new FormData();
            formData.append('productId', this.dataForm.productId);
            formData.append('productName', this.dataForm.productName);
            this.$refs['dataForm'].validate((valid) => {
                if (valid) {
                    add(formData).then(res => {
                        this.centerDialogVisible = false
                        this.$message({
                            message: res.msg,
                            type: 'success'
                        });
                        this.$emit('refreshReturnData')
                    }).catch(err => {
                        this.$message.error('你没有新增数据的权限,请与系统管理员联系');
                    });
                }
            })
        },
        
    }
};
</script>