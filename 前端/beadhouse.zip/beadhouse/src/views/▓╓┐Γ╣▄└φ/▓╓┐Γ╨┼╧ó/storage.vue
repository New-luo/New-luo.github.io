<template>
    <div>
      <div>
        <h2>仓库信息</h2>
      </div>
    <table align="center" width="900px">
        <tr>            
          <td>
            <el-form :inline="true" v-model="listQuery">
              <el-row :span="24">
                <el-form-item  prop="storageId">
                      <el-input  placeholder="请输入客户ID" v-model="listQuery.storageId" clearable/>
                  </el-form-item>
                  <el-autocomplete
    v-model="listQuery.storageName"
    :fetch-suggestions="querySearch"
    clearable
    class="inline-input w-50"
    placeholder="请输入类别"
    @select="handleSelect"
  />
                  <el-button type="primary"  style=" margin-top: 8px;margin-left:8px" icon="el-icon-search" @click="storageList()">搜索</el-button>
                  <el-button type="primary" style=" margin-top: 8px;"  icon="el-icon-plus"   @click="add(0) ">新增</el-button>
              </el-row>
          </el-form>
          </td>
        </tr>
    </table>
    <div align="center">
     <el-table :data="storage" border style="width: 1000px" fit >
        <el-table-column prop="storageId" label="ID"></el-table-column>
        <el-table-column prop="storageName" label="仓库名称"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" @click="add(scope.row.storageId)" icon="el-icon-edit" circle></el-button>
            <el-button type="danger" @click="dele(scope.row.storageId)" icon="el-icon-delete" circle></el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  <div class="block">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="listQuery.Current"
      :page-sizes="[5, 10, 20, 50]"
      :page-size="listQuery.size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="listQuery.total">
     </el-pagination>
  </div>
  <add-or-update v-if="addOrUpdateVisible" ref="AddOrUpdate" @refreshReturnData="storageList"/>
    </div>
  </template>
  <script>
  import {list,del,zd} from '../../../api/仓库信息/storage'
  import AddOrUpdate from './storageAdd.vue' 
  
    export default{
        name:"Storage_",
        components:{
        AddOrUpdate
    },
    data(){
        return{
            // querySearch:[],     //客户名称自动弹窗
            // querySearch2:[],    //客户访问事由地址自动弹窗
            listQuery:{
                storageId:'',  //ID
                storageName:'', 
                size: 5 ,      //每页多少条数据
                Current:1,    //默认第一页
                total:0,     //总页数
            },
            storage: [],//列表
            addOrUpdateVisible:false,//新增修改弹窗
          };
        },
        created() {
          this.storageList(); 
        },
    methods:{
    handleSizeChange(val) {
     console.log(`每页 ${val} 条`);
      this.listQuery.size = val
      this.storageList(); 
    },
    handleCurrentChange(val) {
     console.log(`当前页: ${val}`);
      this.listQuery.Current = val 
      this.storageList(); 
    },
  
  
  
  //删除
  dele(id) {
  console.log(id);
      this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        del(id).then(res => {
          var params = this.listQuery
          var curPageSize = this.storage.length
          params.Current = curPageSize == 1 ? params.Current - 1 : params.Current
          if(res.code==200){
            this.$message({
          type: 'success',
          message: '删除成功!'
        });
        this.storageList(); 
          } 
        })
        .catch(err => {
          this.$message.error('你没有删除数据的权限,请与系统管理员联系');
    });
      })
      .catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    },
  
  // 条件.分页.查询列表
  storageList() {
  console.log(this.listQuery)
   list(this.listQuery).then(res => {
      this.storage = res.page.records;  
      this.listQuery.total = res.page.total;  
    })
    .catch(err => {
      this.$message.error('你没有查询学校表数据的权限,请与系统管理员联系');
    });
  },
  
  add(id){
  this.addOrUpdateVisible=true;
  if(id===0){
  //$nextTick异步处理，调用对话框的初始化函数
  this.$nextTick(() => {
  this.$refs.AddOrUpdate.init(0);
    })  
  }else {
  this.$nextTick(() => {
  this.$refs.AddOrUpdate.init(id);
    }) 
   }
  },



  querySearch(queryString, cb) {
this.listQuery.storageName = queryString;
zd(this.listQuery).then(res => {
    // 使用 Set 来过滤不重复的 item.storageName 值
    const uniqueNames = new Set();
    this.suggestions2 = res.list.reduce((uniqueList, item) => {
      if (!uniqueNames.has(item.storageName)) {
        uniqueNames.add(item.storageName);
        uniqueList.push({
          value: item.storageName,
          link: item.link
        });
      }
      return uniqueList;
    }, []);
    cb(this.suggestions2);
  })
  .catch(error => {
    console.error('Error fetching restaurant list:', error);
  });
},
  handleSelect(item) {
    console.log(item);
  },
  }
    }
  </script>