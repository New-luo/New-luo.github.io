<template>
    <el-dialog :title="dataForm.storageId > 0 ? '修改' : '新增'" :visible.sync="centerDialogVisible" width="60%" center>
        <el-form :model="dataForm" ref="dataForm" :rules="dataRule" inline label-width="300px" style="width:100%;">
            <el-row>
                <el-col :span="24">
                    <el-form-item prop="storageName" label="仓库名称:">
                        <el-input v-model="dataForm.storageName" clearable />
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button @click="centerDialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="upload()">确 定</el-button>
        </span>
    </el-dialog>
</template>
<script>
import {list,add,getid} from '../../../api/仓库信息/storage'

export default {
    data() {
        return {
            dataForm: {
                storageId: 0,
                storageName: '',

            },
            centerDialogVisible: false,
            dataRule: {
                storageName: [
                    { required: true, message: '仓库名称不能为空', trigger: 'blur' }
                ],
            },
        };

    },
    created() {

    },
    methods: {
        init(id) {
            this.centerDialogVisible = true
            getid(id).then(res => {
                if (id > 0) {
                    let { storageId, storageName } = res.data[0];
                    this.dataForm = {
                        storageId, storageName
                    };
                } else {
                    this.dataForm.storageId = 0;
                    this.dataForm.storageName = '';
                }
            }).catch(err => {
                this.centerDialogVisible = false;
                this.$message.error('你没有修改数据的权限,请与系统管理员联系');
            });
        },
        handleDateTimeChange() {
            this.dataForm.visitTime = new Date(this.dataForm.visitTime);
        },


        upload() {
            let formData = new FormData();
            formData.append('storageId', this.dataForm.storageId);
            formData.append('storageName', this.dataForm.storageName);
            this.$refs['dataForm'].validate((valid) => {
                if (valid) {
                    add(formData).then(res => {
                        this.centerDialogVisible = false
                        this.$message({
                            message: res.msg,
                            type: 'success'
                        });
                        this.$emit('refreshReturnData')
                    }).catch(err => {
                        this.$message.error('你没有新增数据的权限,请与系统管理员联系');
                    });
                }
            })
        },
        
    }
};
</script>