<template>
    <div>
      <div>
        <h2>住宿安排</h2>
      </div>
    <table align="center" width="900px">
        <tr>            
          <td>
            <el-form :inline="true" v-model="listQuery">
              <el-row :span="24">
                <el-form-item  prop="stayId">
                      <el-input  placeholder="请输入客户ID" v-model="listQuery.stayId" clearable/>
                  </el-form-item>
                  <el-button type="primary"  style=" margin-top: 8px;margin-left:8px" icon="el-icon-search" @click="StayinfoList()">搜索</el-button>
                  <el-button type="primary" style=" margin-top: 8px;"  icon="el-icon-plus"   @click="add(0) ">新增</el-button>
              </el-row>
          </el-form>
          </td>
        </tr>
    </table>
     <el-table :data="stayinfo" border style="width: 100%" fit>
        <el-table-column prop="stayId" label="ID"></el-table-column>
        <el-table-column prop="bedId" label="床位ID"></el-table-column>
        <el-table-column prop="personId" label="人员ID"></el-table-column>
        <el-table-column prop="orderTime" label="预订时间"></el-table-column>
        <el-table-column prop="startTime" label="入住时间"></el-table-column>
        <el-table-column prop="leaveTime" label="离开时间"></el-table-column>
        <el-table-column prop="price" label="单价"></el-table-column>
        <el-table-column prop="stayType" label="类别">

        </el-table-column>
        <el-table-column prop="remark" label="备注"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" @click="add(scope.row.stayId)" icon="el-icon-edit" circle></el-button>
            <el-button type="danger" @click="dele(scope.row.stayId)" icon="el-icon-delete" circle></el-button>
          </template>
        </el-table-column>
      </el-table>
  <div class="block">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="listQuery.Current"
      :page-sizes="[5, 10, 20, 50]"
      :page-size="listQuery.size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="listQuery.total">
     </el-pagination>
  </div>
  <add-or-update v-if="addOrUpdateVisible" ref="AddOrUpdate" @refreshReturnData="StayinfoList"/>
    </div>
  </template>
<script>
import { readonly } from 'vue';
import {list,del,zd} from '../../api/stayinfo'
import AddOrUpdate from './stayinfoAdd.vue' 

    export default{
        name:"Stayinfo_",
        components:{
        AddOrUpdate
        // 'add-or-update': AddOrUpdate
    },
    data(){
        return{
            // querySearch:[],     //客户名称自动弹窗
            // querySearch2:[],    //客户访问事由地址自动弹窗
            listQuery:{
                stayId:'',      //ID
                bedId:'',       //床位ID
                personId:'',    //人员ID
                size: 5 ,      //每页多少条数据
                Current:1,    //默认第一页
                total:0,     //总页数
            },
            stayinfo: [],//列表
            addOrUpdateVisible:false,//新增修改弹窗
          };
        },
        created() {
          this.StayinfoList(); 
        },
    methods:{
    handleSizeChange(val) {
     console.log(`每页 ${val} 条`);
      this.listQuery.size = val
      this.StayinfoList(); 
    },
    handleCurrentChange(val) {
     console.log(`当前页: ${val}`);
      this.listQuery.Current = val 
      this.StayinfoList(); 
    },


  
//删除
  dele(id) {
  console.log(id);
      this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        del(id).then(res => {
          var params = this.listQuery
          var curPageSize = this.stayinfo.length
          params.Current = curPageSize == 1 ? params.Current - 1 : params.Current
          if(res.code==200){
            this.$message({
          type: 'success',
          message: '删除成功!'
        });
        this.StayinfoList(); 
          } 
        })
        .catch(err => {
          this.$message.err('你没有删除数据的权限,请与系统管理员联系');
    });
      })
      .catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    },

// 条件.分页.查询列表
StayinfoList() {
  console.log(this.listQuery)
   list(this.listQuery).then(res => {
      console.log(res);
      var date = new Date()
      
      res.page.records.forEach(item => {
        if(item.stayType === 1){
          item.stayType = '入住'
          }else{
            item.stayType = '换房'
          }
      })
      console.log(res.page.records);
      // for(let i = 0; i<res.timeData.size; i++){
      //     console.log(res.timeData.OrderTime[i]);
      //     console.log("this");
      // }
      this.stayinfo = res.page.records;
      this.listQuery.total = res.page.total;  
    })
    .catch(err => {
      this.$message.err('你没有查询学校表数据的权限,请与系统管理员联系');
    });
},
  add(id){
  this.addOrUpdateVisible=true;
  if(id===0){
  //$nextTick异步处理，调用对话框的初始化函数
  this.$nextTick(() => {
  this.$refs.AddOrUpdate.init(0);
    })  
  }else {
  this.$nextTick(() => {
  this.$refs.AddOrUpdate.init(id);
    }) 
   }
},
  }
    }
</script>