<template>
  <el-dialog :title="dataForm.stayId > 0 ? '修改' : '新增'" :visible.sync="centerDialogVisible" width="60%" center>
    <el-form :model="dataForm" ref="dataForm" :rules="dataRule" inline label-width="100px" style="width:100%;">
      <el-row>
        <!-- 左侧内容 -->
        <el-col :span="12">

          <el-form-item prop="bedId" label="床位ID:">
            <el-input v-model="dataForm.bedId" />
          </el-form-item>

          <el-form-item prop="personId" label="人员ID:">
            <el-input v-model="dataForm.personId" />
          </el-form-item>

          <el-form-item prop="orderTime" label="预订时间:">
            <el-date-picker v-model="dataForm.orderTime" type="datetime" format="yyyy-MM-dd HH:mm:ss"
              value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择日期时间"></el-date-picker>
          </el-form-item>

          <el-form-item prop="startTime" label="入住时间:">
            <el-date-picker v-model="dataForm.startTime" type="datetime" format="yyyy-MM-dd HH:mm:ss"
              value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择日期">
            </el-date-picker>
          </el-form-item>
        </el-col>
        <!-- 右侧内容 -->
        <el-col :span="12">

          <el-form-item prop="leaveTime" label="离开时间：">
            <el-date-picker v-model="dataForm.leaveTime" type="datetime"  format="yyyy-MM-dd HH:mm:ss"
              value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择日期">
            </el-date-picker>
          </el-form-item>

          <el-form-item prop="price" label="单价：">
            <el-input v-model="dataForm.price" />
          </el-form-item>

          <el-form-item prop="stayType" label="类别：">
            <el-select v-model="stayTypeitem" clearable>
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          
          <el-form-item prop="remark" label="备注：">
            <el-input v-model="dataForm.remark" />
          </el-form-item>

        </el-col>
      </el-row>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="centerDialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="upload()">确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { list, add, getid } from '../../api/stayinfo'
export default {
  name: 'StAdd_',
  data() {
    // 
    return {
      stayTypeitem: '',
      options: [
        {
          value: 1,
          label: '入住'
        },
        {
          value: 2,
          label: '换房'
        }
      ],
      dataForm: {
        stayId: 0,
        bedId: '',
        personId: '',
        orderTime: '',
        startTime: '',
        leaveTime: '',
        price: '',
        stayType: '',
        remark: '',

      },
      centerDialogVisible: false,
      dataRule: {
        personId: [
          { required: true, message: '床位ID不能为空', trigger: 'blur' }
        ],
        personId: [
          { required: true, message: '人员ID不能为空', trigger: 'blur' }
        ],
        price: [
          { required: true, message: '单价不能为空', trigger: 'blur' },

        ],
        remark: [
          { required: true, message: '备注不能为空', trigger: 'blur' },

        ],
      },
    }
  },
  created() {

  },
  methods: {
    init(id) {
      this.centerDialogVisible = true
      console.log(id)
      getid(id).then(res => {
        // alert("this")
        if (id > 0) {
          let { stayId, bedId, personId, orderTime, startTime, leaveTime, price, stayType, remark } = res.data[0];
          console.log("类别是：" + stayType);
          if (stayType == '1') {
            console.log("入住");
            this.stayTypeitem = '入住';
          } else if(stayType == '2') {
            this.stayTypeitem = '换房';
          }
          this.dataForm = {
            stayId, bedId, personId, orderTime, startTime, leaveTime, price, stayType, remark
          };
        } else {
          this.dataForm.stayId = 0;
          this.dataForm.bedId = '';
          this.dataForm.personId = '';
          this.dataForm.orderTime = '';
          this.dataForm.startTime = '';
          this.dataForm.leaveTime = '';
          this.dataForm.price = '';
          this.dataForm.stayType = '';
          this.dataForm.remark = '';
          this.stayTypeitem = 1;
        }
      }).catch(err => {
        console.log(err)
        this.centerDialogVisible = false;
        this.$message.error('你没有修改数据的权限,请与系统管理员联系');
      });
    },
    handleDateTimeChange() {
      this.dataForm.visitTime = new Date(this.dataForm.visitTime);
    },


    upload() {
      if(this.stayTypeitem == '入住'){
          this.stayTypeitem = '1';
      }else if(this.stayTypeitem == '换房'){
          this.stayTypeitem = '2';
      }
      console.log(this.stayTypeitem);
      let formData = new FormData();
      formData.append('stayId', this.dataForm.stayId);
      formData.append('bedId', this.dataForm.bedId);
      formData.append('personId', this.dataForm.personId);
      formData.append('orderTime', this.dataForm.orderTime);
      formData.append('startTime', this.dataForm.startTime);
      formData.append('leaveTime', this.dataForm.leaveTime);
      formData.append('price', this.dataForm.price);
      formData.append('stayType', this.stayTypeitem);
      formData.append('remark', this.dataForm.remark);
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          add(formData).then(res => {
            this.centerDialogVisible = false
            this.$message({
              message: res.msg,
              type: 'success'
            });
            this.$emit('refreshReturnData')
          }).catch(err => {
            this.$message.error('你没有新增数据的权限,请与系统管理员联系');
          });
        }
      })
    }
  }
}
</script>