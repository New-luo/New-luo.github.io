<template>
    <div class="main"  v-permission="'7'">
        <h2>床位管理</h2>
        <div class="content">
            <!-- 操作 -->
            <div class="operate">
                <div class="operate-data">
                    <el-button type="primary" style="  width: 80px; height: 30px;" v-permission = "'4'" @click="toAdd()">新增</el-button>
                    <el-button type="primary" style="  width: 80px; height: 30px;" v-permission = "'5'" @click="operateToUpd()">修改</el-button>
                    <el-button type="primary" style="  width: 80px; height: 30px;"  v-permission = "'6'" @click="deleteBatch()">批量删除</el-button>
                </div>
                <div class="operate-select">
                    <el-input placeholder="请输入内容" v-model="selectText" clearable style="width: 200px;"></el-input>
                    <el-button type="primary" class="search" @click="search()">搜索</el-button>
                </div>
            </div>
            <!-- /操作 -->
            <!-- 列表查询 -->
            <div>
                <el-table :data="bedList" border style="width: 100%" @selection-change="selectionData">
                    <el-table-column type="selection" width="50"></el-table-column>
                    <el-table-column prop="bedID" label="床位id" width="180"></el-table-column>
                    <el-table-column prop="bedNO" label="床位号" width="180"></el-table-column>
                    <el-table-column prop="state" label="床位状态" width="180">
                        <template slot-scope="scope">
                            <div class="cell" v-if="scope.row.state === '0'">
                            Loading Error
                            </div>
                            <div class="cell" v-if="scope.row.state === '1'">
                            空闲
                            </div>
                            <div class="cell" v-else-if="scope.row.state === '2'">
                            使用中
                            </div>
                            <div class="cell" v-else-if="scope.row.state === '3'">
                            预定
                            </div>
                            <div class="cell" v-else-if="scope.row.state === '4'">
                            维修中
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="remark" label="描述" width="180"></el-table-column>
                    <el-table-column prop="operate" label="操作" width="130">
                        <template slot-scope="scope">
 <el-button type="primary" icon="el-icon-edit"  v-permission = "'5'" @click="toUpdate(scope.row.bedID)" circle></el-button>
 <el-button type="danger" icon="el-icon-delete"  v-permission = "'6'" @click="del(scope.row.bedID)" circle></el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
            <!-- /列表查询 -->
        </div>
        <!-- 分页 -->
        <template>
            <div class="block">
                <!-- <span class="demonstration">完整功能</span> -->
                <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pager.current"
                :page-sizes="[5, 10, 15, 20]"
                :page-size="pager.size"
                layout="total, sizes, prev, pager, next, jumper"
                :total="pager.total">
                </el-pagination>
            </div>
        </template>
        <!-- 新增 -->
        <div class="AddorUpdate" v-if="isDisplayed">
            <div class="title">
                <h2>新增</h2>
           </div>
           <div class="Addorup-item"> 
                <div class="Addorup-item-text">
                    <p>床位号:</p>
                </div>
                <div class="Addorup-item-input">
                    <input type="text" v-model="AddBedNO">。
                </div>
           </div>
           <div class="Addorup-item"> 
                <div class="Addorup-item-text">
                    <p>床位状态:</p>
                </div>
                <div class="Addorup-item-input">
                    <el-select v-model="AddState" filterable placeholder="请选择">
                        <el-option
                        v-for="item in Addoptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
           </div>
           <div class="Addorup-item"> 
                <div class="Addorup-item-text">
                    <p>描述:</p>
                </div>
                <div class="Addorup-item-input">
                    <input type="text" v-model="AddRemark">。
                </div>
           </div>
           <div class="Addorup-item"> 
                <input type="button" value="取消" class="cancel" @click="isDisplayed=false">
                <input type="button" value="确认" class="confirm" @click="Add()">
           </div>
        </div>
        <!-- /新增 -->
        <!-- 修改 -->
        <div class="AddorUpdate" v-if="UpdateElement">
            <div class="title">
                <h2>修改</h2>
           </div>
           <div class="Addorup-item"> 
                <div class="Addorup-item-text">
                    <p>床位id:</p>
                </div>
                <div class="Addorup-item-input">
                    <el-input v-model="UpdbedID" style="width: 200px;" :disabled="true"></el-input>
                </div>
           </div>
           <div class="Addorup-item"> 
                <div class="Addorup-item-text">
                    <p>床位号:</p>
                </div>
                <div class="Addorup-item-input">
                    <input type="text" v-model="UpdBedNO">。
                </div>
           </div>
           <div class="Addorup-item"> 
                <div class="Addorup-item-text">
                    <p>床位状态:</p>
                </div>
                <div class="Addorup-item-input">
                    <!-- <el-select v-model="UpdState">
                        <el-option value="1">空闲</el-option>
                        <el-option value="2">使用中</el-option>
                        <el-option value="3">预定</el-option>
                        <el-option value="4">维修中</el-option>
                    </el-select> -->
                    <el-select v-model="UpdState" filterable placeholder="">
                        <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                        </el-option>
                    </el-select>
                </div>
           </div>
           <div class="Addorup-item"> 
                <div class="Addorup-item-text">
                    <p>描述:</p>
                </div>
                <div class="Addorup-item-input">
                    <input type="text" v-model="UpdRemark">。
                </div>
           </div>
           <div class="Addorup-item"> 
                <input type="button" value="取消" class="cancel" @click="UpdateElement=false">
                <input type="button" value="确认" class="confirm" @click="Update()">
           </div>
        </div>
        <!-- /修改 -->
    </div>

</template>
<script>
import axios from "axios";
import {selectPage} from '../../api/bedManage'

export default {
  name: "Bedmanage_",
  data() {
    return {
            // 获取id
            ids: [],
            getID: null,

            // 列表查询 列表数据
            bedList: [],

            // 隐藏hmtl元素，点击后才将其显示。
            isDisplayed: false,
            UpdateElement: false,
            hideButtonDisplayed: false,

            // 新增参数
            AddBedNO:'',
            AddState:'空闲',
            AddRemark:'',
            Addoptions: [{
                    value: '1',
                    label: '空闲'
                }, {
                    value: '3',
                    label: '预定'
                },],
            // 修改参数
            UpdbedID: "",
            UpdBedNO: "",
            UpdRemark: "",
            options: [{
                    value: '1',
                    label: '空闲'
                }, {
                    value: '2',
                    label: '使用中'
                }, {
                    value: '3',
                    label: '预定'
                }, {
                    value: '4',
                    label: '维修中'
                },],
            UpdState: '',

            // 根据id查询得到的数据
            selectBYidData: [],
            // 分页参数
            pager: {
                current: 1,
                total: 0,
                size: 5,
            },
            // 查询参数
            selectText: ''
        }
   },
   methods:{
        // init(pager){
        //     selectPage(pager).then(res =>{
        //         console.log(res)
        //         this.bedList = res.bedList;
        //         this.pager.total = res.count;
        //     }).catch(error =>{
        //         console.log(error);
        //         this.$message(error);
        //     })
        // },
        init(){
            // let url = "http://localhost:8088/systeam/open-bed/select-bed"
            let url = "http://localhost:8088/systeam/open-bed/selectPage-bed"
            let curPage = this.pager.current;
            axios({
                url: url,
                method: 'post',
                params:{
                    "curPage": curPage,
                    "pageSize": this.pager.size
                }
            }).then(res=>{
                // console.log(res.data.bedList);
                console.log(res.data.bedList);
                // for(let i = 0; i<res.data.bedList.length; i++){
                //     this.bedList = res.data.bedList[i];
                // }
                this.bedList = res.data.bedList;
                this.pager.total = res.data.count;
            }).catch(err=>{
                this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
            })
        },
        toAdd(){
            this.isDisplayed = true;
        },
        Add(){
            // 表单验证
            if(this.AddBedNO == "" || this.AddBedNO == null){
                this.$message({
                    showClose: true,
                    message: '床位号不能为空哦！',
                    type: 'error'
                });
                return;
            }else if(this.AddState == "" || this.AddState == null){
                this.$message({
                    showClose: true,
                    message: '你还没有选择床位状态哦！',
                    type: 'error'
                });
                return;
            }else if(this.AddRemark == "" || this.AddRemark == null){
                this.$message({
                    showClose: true,
                    message: '请添加你的描述吧！',
                    type: 'error'
                });
                return;
            }
            if(this.AddBedNO.length == 2 || this.AddBedNO.length < 2){
                this.$message({
                    showClose: true,
                    message: '床位号不能是2个字符哦！请输入三个数字！',
                    type: 'error'
                });
                return;
            }
            if(this.AddBedNO.length === 4 || this.AddBedNO.length > 4){
                this.$message({
                    showClose: true,
                    message: '床位号不能是4个字符哦！请输入三个数字！',
                    type: 'error'
                });
                return;
            }
            console.log(typeof(this.AddBedNO));
            if (typeof parseInt(this.AddBedNO) === 'number' && Number.isInteger(parseInt(this.AddBedNO))) {
               console.log("true");
            } else {
                this.$message({
                    showClose: true,
                    message: '床位号必须是数字类型的数据哦！',
                    type: 'error'
                });
                this.AddBedNO = "";
                return;
            }
            // alert("this");
            let url = "http://localhost:8088/systeam/open-bed/Add-bed";
            if(this.AddState == "空闲"){
                this.AddState = "1";
            }
            if(this.AddState == "预定"){
                this.AddState = "3";
            }
            console.log(this.AddState);
            axios({
                url: url,
                method: 'post',
                params:{
                    "bedNO": this.AddBedNO,
                    "state": this.AddState,
                    "remark": this.AddRemark
                }
            }).then(res=>{
                if(res.data.code == 201){
                    this.$message({
                        showClose: true,
                        message: '这个床位号可能已经存在一个了，请换一个床位号吧！',
                        type: 'error'
                    });
                    return;
                }else{
                    this.$message({
                        showClose: true,
                        message: '新增成功',
                        type: 'success'
                    });
                    this.isDisplayed = false
                    this.init();
                }
            }).catch(err=>{
                // this.centerDialogVisible = false;
                this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
            })
        },
        operateToUpd(){
            let bedIdArray = "";
            for(let i = 0; i<this.ids.length; i++){
                // bedIdArray.push(this.ids[i].bedID);
                bedIdArray += this.ids[i].bedID + ",";
            }
            console.log(bedIdArray);
            if(bedIdArray == null || bedIdArray == 0){
                this.$message({
                    showClose: true,
                    message: '请勾选要修改的数据！',
                    type: 'error'
                });
                return;
            }
            if(bedIdArray.length > 4){
                this.$message({
                    showClose: true,
                    message: '只能勾选一条数据哦！',
                    type: 'error'
                });
                return;
            }
            let url = "http://localhost:8088/systeam/open-bed/getID";
            
            if(bedIdArray == "1"){
                this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
                return;
            }
            this.UpdateElement = true;
            // if(this.ids[0].bedID != 0 || this.ids[0].bedID != null){
            //     id = this.ids[0].bedID;
            // }
            console.log("要修改的id是:"+bedIdArray);
            axios({
                url: url,
                method: 'post',
                params:{
                    'cmd': 'toUpdate',
                    "id": bedIdArray.substring(0, bedIdArray.length -1),
                }
            }).then(res=>{
                this.$message({
                    showClose: true,
                    message: 'code: 200',
                    type: 'success'
                });
                console.log(res.data.bedList[0].bedNO);
                this.UpdbedID = res.data.bedList[0].bedID;
                this.UpdBedNO = res.data.bedList[0].bedNO;
                this.UpdRemark = res.data.bedList[0].remark;
                this.UpdState = res.data.bedList[0].state;
                // 处理床位状态的数据
                // console.log(res.data.bedList[0].state);
                console.log(typeof Number.isInteger(this.UpdState));
                // if(res.data.bedList[0].state == 1){
                //     this.UpdState = "空闲";
                // }else if(res.data.bedList[0].state == 2){
                //     this.UpdState = "使用中";
                // }else if(res.data.bedList[0].state == 3){
                //     this.UpdState = "预定";
                // }else if(res.data.bedList[0].state == 4){
                //     this.UpdState = "维修中";
                // }

            }).catch(err=>{
                this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
            })
        },
        toUpdate(bedID){
            // alert("this");
            this.getID = bedID;

            let url = "http://localhost:8088/systeam/open-bed/getID";
            
            let id = 0;
            if(this.getID != 0){
                id = this.getID;
            }
            if(id == 1){
                this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
                return;
            }
            this.UpdateElement = true;
            // if(this.ids[0].bedID != 0 || this.ids[0].bedID != null){
            //     id = this.ids[0].bedID;
            // }
            console.log("要修改的id是:"+id);
            axios({
                url: url,
                method: 'post',
                params:{
                    'cmd': 'toUpdate',
                    "id": id,
                }
            }).then(res=>{
                this.$message({
                    showClose: true,
                    message: 'code: 200',
                    type: 'success'
                });
                this.UpdbedID = res.data.bedList[0].bedID;
                this.UpdBedNO = res.data.bedList[0].bedNO;
                this.UpdRemark = res.data.bedList[0].remark;
                // let BedState = res.data.bedList[0].state;
                this.UpdState = res.data.bedList[0].state;
                // 处理床位状态的数据
                // console.log(res.data.bedList[0].state);
                console.log(typeof Number.isInteger(this.UpdState));
                console.log(this.UpdState);
            }).catch(err=>{
                this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
            })
        },
        Update(){
            let url = "http://localhost:8088/systeam/open-bed/Upd-bed";
            console.log(this.UpdbedID);
            console.log(this.UpdState);
            // alert(state)
            axios({
                url: url,
                method: 'post',
                params:{
                    "bedID": this.UpdbedID,
                    "bedNO": this.UpdBedNO,
                    "state": this.UpdState,
                    "remark": this.UpdRemark
                }
            }).then(res=>{
                if(res.data.code == 201){
                    this.$message({
                        showClose: true,
                        message: '这个床位号可能已经存在一个了，请换一个床位号吧!',
                        type: 'error'
                    });
                    return;
                }else{
                    this.$message({
                        showClose: true,
                        message: '修改成功',
                        type: 'success'
                    });
                    this.UpdateElement = false;
                    this.init();
                }
            }).catch(err=>{
                this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
            })
        },
        del(bedID){
            this.getID = bedID;

            let url = "http://localhost:8088/systeam/open-bed/getID";
            
            let id = 0;
            if(this.getID != 0){
                id = this.getID;
            }
            if(id == 1){
                this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
                return;
            }
            // if(this.ids[0].bedID != 0 || this.ids[0].bedID != null){
            //     id = this.ids[0].bedID;
            // }
            console.log("要删除的id是:"+id);
            var flag = this.$confirm('删除后数据不可修复, 是否继续?', '警告', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'error'
            }).then(() => {
                axios({
                    url: url,
                    method: 'post',
                    params:{
                        'cmd': 'delete',
                        "id": id,
                    }
                }).then(res=>{
                    this.$message({
                        showClose: true,
                        message: '删除成功',
                        type: 'success'
                    });
                    this.init();
                }).catch(err=>{
                    this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
                })
            }).catch(() => {
                this.$message({
                    showClose: true,
                    type: 'info',
                    message: '已取消删除'
                });          
            });
        },
        search(){
            let url = "http://localhost:8088/systeam/open-bed/selectCondition-bed";
            let curPage = this.pager.current;
            axios({
                url: url,
                method: 'post',
                params:{
                    "curPage": curPage,
                    "pageSize": this.pager.size,
                    'like': this.selectText
                }
            }).then(res =>{
                this.$message({
                    showClose: true,
                    message: 'code: 200',
                    type: 'success'
                });
                this.bedList = res.data.like;
                this.pager.count = res.data.count;
            }).catch(error =>{
                this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
            })
        },
        deleteBatch(){
            let bedIdArray = "";
            for(let i = 0; i<this.ids.length; i++){
                // bedIdArray.push(this.ids[i].bedID);
                bedIdArray += this.ids[i].bedID + ",";
            }
            console.log(bedIdArray);
            if(bedIdArray == null || bedIdArray == 0){
                this.$message({
                    showClose: true,
                    message: '请勾选要删除的数据！',
                    type: 'error'
                });
                return;
            }
            this.$confirm('删除后数据不可修复, 是否继续?', '警告', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'error'
            }).then(() => {
                let url = "http://localhost:8088/systeam/open-bed/deleteBatch-bed";
                axios({
                    url: url,
                    method: 'post',
                    params:{
                        "id": bedIdArray,
                        "cmd": "deleteBatch"
                    }
                }).then(res=>{
                    this.$message({
                        showClose: true,
                        message: '删除成功',
                        type: 'success'
                    });
                    this.init();
                }).catch(err=>{
                    this.$message({
                    showClose: true,
                    message: '对不起，你没有权限！',
                    type: 'error'
                });
                })
                }).catch(() => {
                    this.$message({
                        showClose: true,
                        type: 'info',
                        message: '已取消删除'
                    });          
                });

        },
        selectionData(val){
            this.ids = val;
            console.log(this.ids[0].bedID);
        },

        handleSizeChange(val) {
            this.pager.size = val;
            console.log(`每页 ${val} 条`);
            // this.init(this.pager);
            this.init();
        },
        handleCurrentChange(val) {
            this.pager.current = val;
            console.log(`当前页: ${val}`);
            // this.init(this.pager);
            this.init();
        }                                                                                  
   },
   created(){
        // this.init(this.pager);
        this.init();
   }
}
</script>
<style scoped>
* {
  margin: 0%;
  padding: 0%;
}
a {
  text-decoration: none;
  font-size: 14px;
  color: rgb(70, 179, 179);
  margin: 5px;
}
span {
  text-decoration: none;
  font-size: 14px;
  color: rgb(70, 179, 179);
  margin: 5px;
  cursor: pointer;
}
/* button {
  width: 80px;
  height: 30px;
} */
.main {
  /* display: flex;
        flex-direction: column; */
    }
    .content{
        width: 872px;
        height: auto;
        display: flex;
        justify-content: center;
        align-content: center;
        flex-direction: column;
        margin: auto;
    }
    .operate{
        display: flex;
        align-items: center;
        flex-direction: row;
    }
    .operate-data{
        display: flex;
        align-items: center;
        justify-content: flex-start;
    }
    .operate-select{
        /* margin-right: 0px; */
        display: flex;
        justify-content: flex-end;
        margin-left: 330px;
        margin-bottom: 5px;
    }
    .search{
        width: 80px;
        height: 40px;
    }
    .AddorUpdate{
        width: 400px;
      height: 400px;
      margin: auto;
      display: flex;
      /* border: 1px black solid; */
      background: #ffffff;
      flex-direction: column;
      align-items: center;
      /* background-image: url("./image/OIP-C.jpg"); */
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;
      box-shadow: #999 1px 2px 1px 2px;
      position: absolute;
      margin: auto;
      top: 0;bottom: 0;right: 0;left: 0;
      z-index: 1;
      /* display: none; */
    }
    .title{
        display: flex;
        justify-content: flex-start;
        align-items: center;
        width: 100%;
        height: 40px;
        /* background: red; */
    }
    .title>h2{
        margin-left: 20px;
        text-align: center;
        border-bottom: 2px #999 solid;
    }
    .Addorup-item{
        width: 100%;
        height: 60px;
        display: flex;
        text-align: center;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        margin: auto;
        /* background: #5b9ed5; */
        /* border: 1px black solid; */
    }
    .Addorup-item-text{
        display: flex;
        /* justify-content: center; */
        align-items: center;
        text-align: center;
        flex: 0.7;
    }
    .Addorup-item-input{
        display: flex;
        /* justify-content: center; */
        align-items: center;
        text-align: center;
        flex: 3;
    }
    .Addorup-item-inputID{
        display: flex;
        /* justify-content: center; */
        align-items: center;
        text-align: center;
        flex: 3;
    }
    .Addorup-item-inputID>input{
        width: 200px;
        height: 23px;
        border: none;
        outline: none;
        border: 1px black solid;
        color: black;
        /* text-align: center; */
        font-size: 16px;
        border: none;
        border-bottom: 2px rgb(31, 29, 29) solid;
    }
    .Addorup-item-text>p{
        text-align: center;
        font-size: 14px;
        color: black;
        /* background: #222; */
        display: flex;
        justify-content: center;
        align-items: center;
        margin-left: 10px;
        /* line-height: 100px; */
    }
    .Addorup-item-input>input{
        width: 200px;
        height: 23px;
        border: none;
        outline: none;
        border: 1px black solid;
        color: black;
        /* text-align: center; */
        font-size: 16px;
        border: none;
        border-bottom: 2px rgb(31, 29, 29) solid;
        /* box-shadow: 1px 0px 0px 0px; */
    }
    .Addorup-item-input>select{
        width: 200px;
        height: 35px;
        border: none;
        outline: none;
        border: 1px #999 solid;
        color: black;
        font-size: 14px;
        border-radius: 5px;
    }
    .Addorup-item-input>input:hover{
        box-shadow: 1px 1px 3px 0px;
    }
    .Addorup-item-input>input:focus{
        width: 230px;
        height: 30px;
        /* border-top: 1px red solid; */
        /* border-left: 2px rgb(255, 0, 0) solid; */
        border-bottom: 2px rgb(255, 0, 0) solid;
        border-right: 1px rgb(255, 0, 0) solid;
            font-size: 16px;
            transition: all 1s ease;
            color: #999;
    }
    .confirm{
        width: 80px;
        height: 30px;
        border: none;
        outline: none;
        background: #83b3df;
        cursor: pointer;
        margin: 8px;
        border-radius: 30px;
    }
    .confirm:hover{
        background: #62a1dc;
    }
    .cancel{
        width: 80px;
        height: 30px;
        border: none;
        outline: none;
        background: #dde5e7;
        cursor: pointer;
        margin: 8px;
        border-radius: 30px;
    }
    .cancel:hover{
        background: #999;
    }
</style>