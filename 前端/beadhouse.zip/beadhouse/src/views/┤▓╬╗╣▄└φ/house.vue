<template>
    <div  v-permission="'17'">
        <!-- <el-button @click="test">test</el-button> -->
        <el-row :gutter="0" type="flex" class="header-bar">
            <el-col :span="18" :offset="0">
                <el-row type="flex">
                    <el-col :span="1.5">
                        <el-button @click="editInit(null)" type="primary" class="add">添加<i class="el-icon-plus el-icon--right"></i></el-button>
                    </el-col>
                </el-row>
            </el-col>
            <el-col :span="6">
                <el-input placeholder="请输入内容" v-model="params.search" class="search">
                    <el-button slot="append" icon="el-icon-search" @click="search"></el-button>
                </el-input>
            </el-col>
        </el-row>
        <el-table :data="houseData" style="width: 100%">
            <el-table-column prop="houseId" label="房屋ID"/>
            <el-table-column prop="communityName" label="养老院"/>
            <el-table-column prop="termName" label="楼栋"/>
            <el-table-column prop="houseName" label="房号"/>
            <el-table-column prop="contact" label="宿管"/>
            <el-table-column prop="tel" label="宿管电话"/>
            <el-table-column prop="bedCount" label="床位号"/>
            <el-table-column prop="remark" label="备注"/>
            <el-table-column prop="paidType" label="收费类型"/>
            <el-table-column prop="paidMoney" label="收费金额"/>
            <el-table-column label="操作" width="210%" fixed="right">
            <template slot-scope="scope">
                <el-button @click="editInit(scope.row)" type="primary" v-permission="'15'" icon="el-icon-edit">更改</el-button>
                <el-button @click="del(scope.row.houseId)" v-permission="'16'" type="primary" icon="el-icon-delete">删除</el-button>
            </template>
            </el-table-column>
        </el-table>
        <div class="block" style="margin-top: 1%;">
            <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page.sync="params.curPage"
            :page-sizes="pageSizes"
            :page-size.sync="params.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
            </el-pagination>
        </div>
        <!-- 编辑窗 -->
        <el-dialog title="编辑" :visible.sync="dialogFormVisible">
            <el-form :model="form">
                <el-form-item label="养老院：" class="form-row">
                    <el-input v-model="form.communityName" autocomplete="off" clearable></el-input>
                </el-form-item>
                <el-form-item label="楼栋：" class="form-row">
                    <el-input v-model="form.termName" autocomplete="off" clearable></el-input>
                </el-form-item>
                <el-form-item label="房号：" class="form-row">
                    <el-input v-model="form.houseName" clearable></el-input>
                </el-form-item>
                <el-form-item label="宿管：" class="form-row">
                    <el-input v-model="form.contact" clearable></el-input>
                </el-form-item>
                <el-form-item label="宿管电话：" class="form-row">
                    <el-input v-model="form.tel" clearable></el-input>
                </el-form-item>
                <el-form-item label="床位号：" class="form-row">
                    <el-input v-model="form.bedCount" clearable></el-input>
                </el-form-item>
                <el-form-item label="备注：" class="form-row">
                    <el-input v-model="form.remark" clearable></el-input>
                </el-form-item>
                <el-form-item label="收费类型：" class="form-row">
                    <el-input v-model="form.paidType" clearable></el-input>
                </el-form-item>
                <el-form-item label="收费金额：" class="form-row">
                    <el-input v-model="form.paidMoney" clearable></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="update" :loading="loading" v-if="actType">保 存</el-button>
                <el-button type="primary" @click="add" :loading="loading" v-else>确 认</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
    import '@/resourcces/css/house.css'
    import {list,update,insert,del} from '../../api/house'
    export default{
        name: 'House_',
        data(){
            return{
                houseData:[],
                total: 0,
                pageSizes: [10,20,30,40],
                params: {
                    "pageSize": 10,
                    "curPage": 1,
                    "search": ''
                },
                dialogFormVisible: false,
                form: {},
                actType: false,
                loading: false
            }
        },
        created(){
            this.init(this.params)
        },
        methods: {
            init(params){
                list(params).then(res=>{
                    console.log(res)
                    this.houseData = res.list
                    this.total = res.total
                    console.log(this.houseData)
                }).catch(err=>{
                    this.$message({
                        showClose: true,
                        message: err,
                        type: 'error'
                    })
                })
            },
            formInit(){
                this.form = {
                    communityName:'',
                    termName:'',
                    houseName: '',
                    contact: '',
                    tel: '',
                    bedCount: '',
                    remark: '',
                    paidType: '',
                    paidMoney: ''
                }
            },
            editInit(val){
                if(val){
                    this.form = val
                }else{
                    this.formInit()
                }
                this.actType = true
                this.dialogFormVisible = true
                console.log(this.form)
            },
            add(){
                console.log(this.form)
                insert(this.form).then(res => {
                    console.log(res)
                    if(res.addChanged){
                        this.loading = false
                        this.dialogFormVisible = false
                        this.init(this.params)
                        this.$message({
                            showClose: true,
                            message: '添加成功！',
                            type: 'success'
                        })
                    }
                }).catch(err => {
                    this.loading = false
                    this.dialogFormVisible = false
                    this.$message({
                        showClose: true,
                        message: err,
                        type: 'error'
                    })
                })
            },
            del(id){
                this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    del(id).then(res => {
                        var params = this.params
                        var curPageSize = this.houseData.length
                        params.curPage = curPageSize == 1 ? params.curPage - 1 : params.curPage
                        this.init(params)
                        this.$message({
                            type: 'success',
                            message: '删除成功!',
                            showClose: true
                        })
                    }).catch(err => {
                        this.$message({
                            showClose: true,
                            message: err,
                            type: 'error'
                        })
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除',
                        showClose: true
                    });          
                });
            },
            update(){
                this.loading = true
                update(this.form).then(res => {
                    this.loading = false
                    this.dialogFormVisible = false
                    this.init(this.params)
                    this.$message({
                        showClose: true,
                        message: '更改成功！',
                        type: 'success'
                    })
                    if(res.changed){
                    }
                }).catch(err => {
                    this.loading = false
                    this.dialogFormVisible = false
                    this.$message({
                        showClose: true,
                        message: err,
                        type: 'error'
                    })
                    console.log(err)
                })
            },
            search(){
                this.params.curPage = 1
                this.init(this.params)
            },
            handleSizeChange(val) {
                this.init(this.params)
            },
            handleCurrentChange(val) {
                this.init(this.params)
            },
            test(e){
                console.log("test:",e)
            }
        }
    }
    
</script>