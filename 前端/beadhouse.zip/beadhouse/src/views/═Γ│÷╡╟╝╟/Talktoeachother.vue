<template>
    <div class="content">
        <div class="login">
            <div class="login-title">
                <h2>Login_</h2>
            </div>
            <div class="login-item">
                <div class="login-item-input">
                    <input type="text" v-model="sysuser.username" placeholder="请输入账户名">
                </div>
            </div>
            <div class="login-item">
                <div class="login-item-input">
                    <input type="text" v-model="sysuser.password" placeholder="请输入密码">
                </div>
            </div>
            <div class="login-item">
                <div class="login-item-text">
                    <!-- 记住密码: -->
                </div>
                <div class="login-item-input">
                    <el-radio-group v-model="autoONotify">
                        <el-radio label="记住密码"></el-radio>
                        <el-radio label="不记住密码"></el-radio>
                    </el-radio-group>
                </div>
            </div>
            <div class="login-item">
                <div class="login-item-text">
                    <el-button>取消</el-button>
                </div>
                <div class="login-item-input">
                    <el-button type="primary" @click="login()">确认</el-button>
                </div>
            </div>
            <div>
                <span style="cursor: pointer; font-size: 14px; margin-left: 350px;">忘记密码</span>
            </div>
        </div>
    </div>
</template>
<script>
import {logins} from '../../api/外出登记/login'
import cookie from 'js-cookie'
export default {
    name: 'Talktoeachother_',
    data(){
        return{
            sysuser:{
                username: '',
                password: '',
            },
            autoONotify: '不记住密码',
        }
    },
    methods:{
        init(){
            this.sysuser.username = cookie.get("username");
            this.sysuser.password = cookie.get("password");
            this.autoONotify = cookie.get("auto");  
        },
        login(){
            if(this.autoONotify == "不记住密码"){
                this.autoONotify = 2;
            }else{
                this.autoONotify = 1;
            }
            const dadas = {
                "username": this.sysuser.username,
                "password": this.sysuser.password,
                "autoONotify": this.autoONotify
            }
            logins(dadas).then(res =>{
                console.log(res);
                if(res.code == 201){
                    this.$message({
                        showClose: true,
                        message: '登录失败，请检查你的用户名和密码是否正确！',
                        type: 'error'
                    })
                }else{
                    if(res.code == 1){
                        this.$message({
                            showClose: true,
                            message: '登录成功！',
                            type: 'success'
                        })
                        cookie.set("username",res.username.value,{expires: 1});
                        cookie.set("password",res.password.value,{expires: 1});
                        cookie.set("auto","记住密码",{expires: 1});

                        cookie.set("flag",true,{expires: 1});
                        console.log(cookie.get("flag"));
                        this.autoONotify = cookie.get("auto");


                        this.$store.commit("setUserName",cookie.get("username"));
                        this.$store.commit("setPassWord",cookie.get("password"));
                        console.log("setUserName:" + this.$store.state.userName);
                        console.log("password:" + this.$store.state.password);
                        console.log("flag:" + this.$store.state.flag);


                        this.$router.push('OutRecord');
                    }
                    if(res.code == 2){
                        cookie.set("flag",false,{expires: 1});
                        cookie.set("notfly","不记住密码",{expires: 1});
                        this.autoONotify = cookie.get("notfly");

                        this.$message({
                            showClose: true,
                            message: '登录成功！',
                            type: 'success'
                        })

                        this.$router.push('OutRecord');
                    }
                }
            }).catch(error =>{
                this.$message({
                    showClose: true,
                    message: 'Error'+error,
                    type: 'error'
                })
            })
        }
    },
    created(){
        const h = this.$createElement;

        this.$notify({
          title: '请登录',
          message: h('p', { style: 'color: teal'}, '要进行操作，请先登录您的养老院账户')
        });
        if(cookie.get("flag") == "true"){
            this.init();
        }
        if(cookie.get("flag") == "false"){
            cookie.remove("username");
            cookie.remove("password");
            this.autoONotify = cookie.get("notfly");
        }
      },
}
</script>
<style scoped>
    body, html {
            height: 100%;
            margin: 0;
            padding: 0;
    }
    a{
        text-decoration: none;
        font-size: 14px;
        color: black;
    }
    .content{
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background-color: #f2f2f2;
        /* background-image: url('./image/preview.jpg'); */
        background-size: cover;
        background-repeat: no-repeat;
        /* background-size: contain; */
        background-position: center;
        display: flex;
        justify-content: center;
    }
    .login{
        width: 460px;
        height: 430px;
        background: #ffffff;
        display: flex;
        justify-content: flex-end;
        margin: auto;
        /* margin-right: 20px; */
        /* margin-left: 20px; */
        /* margin-top: 210px; */
        box-shadow: 0 0 5px #3b3b3b;
        flex-direction: column;
    }
    .login-title{
        display: flex;
        /* flex: 1; */
        height: 82px;
        justify-content: flex-start;
        align-items: center;
        /* background: linear-gradient(to bottom, #000000, #ffffff); */
        /* background: rebeccapurple; */
        justify-content: center;
        margin-bottom: 20px;
        border-bottom: 3px solid #0098dc;
        margin-right: 300px;
        /* background-image: url('./image/header_bg.11d0e46058f2e734a322.png'); */
    }
    .login-item{
        display: flex;
        flex: 1;
        /* align-items: center; */
        /* background: red; */
        /* border: 1px black solid; */
        margin: 10px;
    }
    .login-item-text{
        display: flex;
        flex: 0.5;
        justify-content: flex-end;
        /* background: #f2f2f2;lk */
        align-items: center;
        font-size: 14px;
        color: black;
    }
    .login-item-input{
        display: flex;
        width: 100%;
        height: 50px;
        justify-content: center;
        /* justify-content: flex-start; */
        align-items: center;
        /* background: #40d8d3; */
        /* margin-top: 20px; */
    }
    .login-item-input>input{
        width: 100%;
        height: 48px;
        border: none;
        outline: none;
        border: 1px #ccc solid;
        /* border-radius: 5px; */
        font-size: 14px;
        color: #000000;
        padding-left: 10px;
        margin: 5px;
        transition: 0.5s all;
        border-radius: 35px;
        /* color: #ccc; */
    }
    .login-item-input>input:hover{
       /* border-color: #4ab3e0;
       box-shadow: 0 0 5px #4ab3e0; */
    }
    .login-item-input>input:focus{
      /* border-color: #007bff; */
      /* box-shadow: 0 0 5px #007bff; */
      border: 1px #000000 solid;
    }
    .login-item-input>input:not(:placeholder-shown){
      top: -10px;
      font-size: 16px;
      color: rgb(0, 0, 0);
    }
    .login-item-text>button{
        width: 80px;
        height: 30px;
        text-align: center;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 30px;
        margin-left: 0%;
    }
    .login-item-input>button{
        margin-top: 20px;
        width: 200px;
        height: 40px;
        border-radius: 0%;
    }
</style>