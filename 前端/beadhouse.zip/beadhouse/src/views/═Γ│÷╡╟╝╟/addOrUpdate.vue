<template>
    <el-dialog :title="getId==0?'外出登记':'修改'" :visible.sync="formVisible" width="auto; display: flex; justify-content: center;">
      <el-form ref="OutRecordData" v-model="OutRecordData">
        <!-- <div class="coutent"> -->
            <h2 class="helloName">{{IntheTime}}</h2>
            <div class="item-section">
                <div class="tiem-section-text">
                    <span>外出人姓名:</span>
                </div>
                <div class="tiem-section-input">
                    <input type="text" v-model="OutRecordData.personName" placeholder="请填写要外出的人的名字">
                </div>
            </div>
            <div class="item-section">
                <div class="tiem-section-text">
                    <span>登记人:</span>
                </div>
                <div class="tiem-section-input">
                    <input type="text" v-model="OutRecordData.userName" placeholder="请填写登记人的姓名">
                </div>
            </div>
            <div class="item-section" style="display: flex; flex: 0.3">
                <div class="tiem-section-text">
                    <span>状态:</span>
                </div>
                <div class="tiem-section-input">
                    <el-radio label="外出" v-model="OutRecordData.state"></el-radio>
                </div>
            </div>
            <div class="item-section">
                <div class="tiem-section-text">
                    <span>时间:</span>
                </div>
                <div class="tiem-section-input">
                    <el-date-picker v-model="OutRecordData.inTime" type="datetime" placeholder="外出时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 200px;">
                    </el-date-picker>
                    <span>登记时间:</span>
                    <el-date-picker v-model="OutRecordData.signTime" type="datetime" :disabled="true" placeholder="登记时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 200px;">
                    </el-date-picker>
                </div>
            </div>
            <div class="item-section">
                <div class="tiem-section-text">
                    <span>陪同人员:</span>
                </div>
                <div class="tiem-section-input">
                    <input type="text" v-model="OutRecordData.visitor" placeholder="请输入陪同人员的姓名，可不填写">
                </div>
            </div>
            <div class="item-section">
                <div class="tiem-section-text">
                    <span>联系电话:</span>
                </div>
                <div class="tiem-section-input">
                    <input type="text" v-model="OutRecordData.mobile" placeholder="请输入你的联系电话">
                </div>
            </div>
            <div class="item-section">
                <div class="tiem-section-text">
                    <span>外出原因:</span>
                </div>
                <div class="tiem-section-input">
                    <el-input type="textarea" placeholder="请填写你的外出原因" v-model="OutRecordData.remark"></el-input>
                </div>
            </div>
            <div class="item-section">
                <div class="tiem-section-text">
                    <!-- <p class="cancel">取消</p> -->
                </div>
                <div class="tiem-section-input">
                    <el-button type="primary" style="width: 200px; height: 40px;" @click="AddOrUpdate">确认</el-button>
                </div>
            </div>
        <!-- </div> -->
      </el-form>
    </el-dialog>
</template>
<script>
import {Add} from '../../api/外出登记/outRecord'
  export default {
    name: "AddOrUpdate_",
    data() {
      return {
        formVisible: false,
        getId: '',
        IntheTime: '',

        OutRecordData:{
            // manualRecordId: '',
            personName: '',
            userName: '',
            state: '外出',
            inTime: '',
            signTime: '',
            visitor: '',
            mobile: '',
            remark: '',
        }
      }
    },
    methods: {
      init(id){

        const now = new Date();

        const year = now.getFullYear();
        const month = ('0' + (now.getMonth() + 1)).slice(-2);
        const day = ('0' + now.getDate()).slice(-2);
        const hour = ('0' + now.getHours()).slice(-2);
        const minutes = ('0' + now.getMinutes()).slice(-2);
        const seconds = ('0' + now.getSeconds()).slice(-2);
        const formattedDate = `${year}-${month}-${day} ${hour}:${minutes}:${seconds}`;
        this.OutRecordData.signTime = formattedDate;
        console.log(formattedDate);

        // 判断时间段
        if (hour >= 0 && hour < 6) {
          this.IntheTime = '早点休息吧。';
        } else if (hour >= 6 && hour < 10) {
          this.IntheTime = '早上好';
        }else if(hour >=10 && hour <12){
          this.IntheTime = '上午好';
        }else if (hour >= 12 && hour < 18) {
          this.IntheTime = '下午好';
        } else {
          this.IntheTime = '晚上好';
        }

        this.getId = id;
        this.formVisible = true;
        console.log(id);
      },
      AddOrUpdate(){
        console.log(this.OutRecordData);
        let params = new FormData();
        params.append("personName",this.OutRecordData.personName);
        params.append("userName",this.OutRecordData.userName);
        params.append("state",this.OutRecordData.state);
        params.append("inTime",this.OutRecordData.inTime);
        params.append("signTime",this.OutRecordData.signTime);
        params.append("visitor",this.OutRecordData.visitor);
        params.append("mobile",this.OutRecordData.mobile);
        params.append("remark",this.OutRecordData.remark);
        console.log(params);
        // this.$refs["OutRecordData"].validate((valid) => {
            // if(valid){
                if(this.getId == 0){
                  Add(this.OutRecordData).then(res =>{
                      // this.$emit('refreshReturnData')
                      console.log(res);
                  }).catch(err =>{
                      this.$message({
                          showClose: true,
                          message: 'Error'+err,
                          type: 'error'
                      });
                      console.log(err);
                  })
                }
            // }
        // })
      }
  }
}
</script>
<style scoped>
    *{
      margin: 0%;
      padding: 0%;
    }
    span{
      font-size: 14px;
      color: black;
      cursor: pointer;
    }
    a{
      text-decoration: none;
      font-size: 14px;
      color: black;
    }
    .coutent{
      width: auto;
      height: 400px;
      /* background: #84b9e5; */
      /* box-shadow: #999 2px 1px ; */
      display: flex;
      justify-content: center;
      flex-direction: column;
    }
    .helloName{
      display: flex;
      justify-content: flex-start;
      margin: 5px;
      color: black;
      width: 300px;
      /* height: 40px; */
    }
    .helloName:hover{
      color: rgb(115, 170, 234);
      /* border-bottom: 1px rgb(166, 162, 162) solid; */
    }
    .item-section{
      flex: 2;
      display: flex;
      flex-direction: row;
      /* align-items: center; */
      justify-content: center;
      margin: 8px;
      transition: 1s all;
      /* border-bottom: 1px #dde5e7 solid; */
    }
    .tiem-section-text{
      flex: 0.5;
      display: flex;
      justify-content: flex-end;
      /* background: red; */
      align-items: center;
      /* border-bottom: 1px blueviolet solid; */
    }
    .tiem-section-text>span{
      font-size: 16px;
      color: #000000;
    }
    .tiem-section-text>span:hover{
      color: #66b1ff;
      /* border-bottom: 1px #66b1ff solid; */
    }
    .tiem-section-input{
      flex: 2;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      /* background: #222; */
      margin-left: 5px;
      /* box-shadow: 0 0 5px #007bff; */
    }
    .tiem-section-input>input{
      width: 200px;
      height: 30px;
      border: none;
      outline: none;
      border-bottom: 2px #ccc solid;
      /* border-radius: 5px; */
      font-size: 12px;
      color: #000000;
      padding-left: 5px;
      margin: 5px;
      transition: 0.5s all;
    }
    .tiem-section-input>input:hover{
       border-color: #4ab3e0;
       box-shadow: 0 0 5px #4ab3e0;
    }
    .tiem-section-input>input:focus{
      width: 300px;
      height: 40px;
      border-color: #007bff;
      box-shadow: 0 0 5px #007bff;
      /* border: 1px #66b1ff solid; */
    }
    .tiem-section-input>input:not(:placeholder-shown){
      top: -10px;
      font-size: 16px;
      color: rgb(0, 0, 0);
    }
    .cancel{
      color: #999;
      font-size: 16px;
      cursor: pointer;
      display: flex;
      justify-content: flex-start;
      align-items: flex-end;
    }
    .item-section-end{

    }
</style>