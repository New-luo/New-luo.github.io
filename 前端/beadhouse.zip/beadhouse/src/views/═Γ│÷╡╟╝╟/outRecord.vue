<template>
    <div  v-permission="'39'">
        <h2 style="margin: auto;">外出登记</h2>
        <div class="content">
            <!-- 操作 -->
            <div class="operate">
                <el-breadcrumb separator="/" class="operate-data">
                    <el-breadcrumb-item v-permission="'34'"><span @click="toAddOrUpdate(0)">外出登记</span></el-breadcrumb-item>
                    <el-breadcrumb-item v-permission="'39'"> <span @click="operateToUpd()">未回归</span></el-breadcrumb-item>
                    <el-breadcrumb-item v-permission="'33'" style="cursor: pointer;"><span  @click="inTimehistory()">外出历史</span></el-breadcrumb-item>
                </el-breadcrumb>
                <!-- <div class="operate-data">
                    <el-button type="primary" v-permission="'34'" @click="toAddOrUpdate(0)">外出登记</el-button>
                    <el-button type="primary" v-permission="'39'" @click="operateToUpd()">未回归</el-button>
                    <el-button type="primary" v-permission="'33'" @click="inTimehistory()">外出历史</el-button>
                </div> -->
                <div class="operate-select">
                    <el-date-picker v-model="pager.beginTime" type="datetime" :disabled="pager.day ? true:false" placeholder="开始时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 195px;" @focus="beginMsg()">
                    </el-date-picker>
                    &nbsp;_&nbsp;
                    <el-date-picker v-model="pager.endTime" type="datetime" :disabled="pager.beginTime ? false:true" placeholder="结束的时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 195px;" @blur="endMsg()">
                    </el-date-picker>
                    <el-date-picker v-model="pager.day" type="datetime" :disabled="pager.beginTime ? true:false" placeholder="准确的选择外出or回来or登记时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 200px;" @focus="timeMsg()">
                    </el-date-picker>
                    <el-input placeholder="请输入内容" v-model="pager.searchText" clearable style="width: 200px;"></el-input>
                    <el-button type="primary" class="search" :disabled="pager.endTime < pager.beginTime ? true:false" @click="selectData ? init(pager) : init2(pager)">搜索</el-button>
                </div>
            </div>
            <!-- /操作 -->
            <!-- 列表数据 -->
            <div>
                <el-table :data="outRecordData" border style="width: auto; margin: auto;" @selection-change="selectionData">
                    <el-table-column type="selection" width="50"></el-table-column>
                    <el-table-column prop="manualRecordId" label="ID" width="180"></el-table-column>
                    <el-table-column prop="personId" label="你的ID" width="180"></el-table-column>
                    <el-table-column prop="realName" label="你的名字是？" width="180"></el-table-column>
                    <el-table-column prop="personName" label="外出人姓名" width="180"></el-table-column>
                    <el-table-column prop="state" label="状态" width="180">
                        <template slot-scope="scope">
                            <div class="cell" v-if="scope.row.state === '0'">
                                Loading Error
                            </div>
                            <div class="cell" v-if="scope.row.state == 1">
                                <p style="color: red; font-size: 14px">
                                    <!-- <i class="el-icon-error" style="color: red;"></i> -->
                                    外出
                                </p>
                            </div>
                            <div class="cell" v-else-if="scope.row.state == 2">
                                <p style="color: green; font-size: 14px;">
                                    <!-- <i class="el-icon-success" style="color: green;"></i> -->
                                    回来
                                </p>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="visitor" label="陪同人员" width="180"></el-table-column>
                    <el-table-column prop="mobile" label="联系电话" width="180"></el-table-column>
                    <el-table-column prop="inTime" label="外出时间" width="180"></el-table-column>
                    <el-table-column prop="outTime" label="回来时间" width="180"></el-table-column>
                    <el-table-column prop="remark" label="外出原因" width="180"></el-table-column>
                    <el-table-column prop="userName" label="登记人" width="180"></el-table-column>
                    <el-table-column prop="signTime" label="登记时间" width="180"></el-table-column>
                    <el-table-column prop="operate" label="操作" fixed="right" :width="operateIntOrOutTime ? '200' : '130'" style="transition: 1s all;">
                                <template slot-scope="scope">
                                    <span  @click="toAddOrUpdate(scope.row.manualRecordId)">修改</span>
                                    <span  @click="del(scope.row.manualRecordId)">删除</span>
                                    <span v-if="operateIntOrOutTime">
                                        <span v-if="scope.row.state == 1" @click="clickOutTime(scope.row.manualRecordId)">
                                            点击回归
                                        </span>
                                        <span v-if="scope.row.state == 2">
                                            点击外出
                                        </span>
                                    </span>
                                </template>
                    </el-table-column>
                </el-table>
            </div>
            <!-- /列表数据 -->
        </div>
        <!-- 分页器 -->
        <div class="block">
            <!-- <span class="demonstration">完整功能</span> -->
            <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="pager.current"
            :page-sizes="[5, 10, 15, 20]"
            :page-size="pager.size"
            layout="total, sizes, prev, pager, next, jumper"
            :total="pager.count">
            </el-pagination>
        </div>
        <!-- /分页器 -->
        <!-- 外出登记 -->
        <div class="fixed" v-if="Visiable">
            <div class="AddOrUpdContent">
                <div class="AddOrUpd-title">
                    <h4 style="width: auto; display: flex; margin: 10px; justify-content: center;">外出登记</h4>
                    <i class="el-icon-close" @click="AddOrUpdclose()"></i>
                </div>
            <!-- <div class="coutent"> -->
                <p class="helloName">{{IntheTime}}，{{Greetings}}</p>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>外出人姓名:</span>
                    </div>
                    <div class="tiem-section-input">
                        <input type="text" v-model="OutRecordData.personName" placeholder="请填写要外出的人的名字">
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>登记人:</span>
                    </div>
                    <div class="tiem-section-input">
                        <input type="text" v-model="OutRecordData.userName" placeholder="请填写登记人的姓名">
                    </div>
                </div>
                <div class="item-section" style="display: flex; flex: 0.3">
                    <div class="tiem-section-text">
                        <span>状态:</span>
                    </div>
                    <div class="tiem-section-input">
                        <el-radio label="外出" v-model="OutRecordData.state"></el-radio>
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>时间:</span>
                    </div>
                    <div class="tiem-section-input">
                        <el-date-picker v-model="OutRecordData.inTime" type="datetime" placeholder="外出时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 200px;">
                        </el-date-picker>
                        <span class="signTime">登记时间:</span>
                        <el-date-picker v-model="OutRecordData.signTime" type="datetime" :disabled="true" placeholder="登记时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 200px;">
                        </el-date-picker>
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>陪同人员:</span>
                    </div>
                    <div class="tiem-section-input">
                        <input type="text" v-model="OutRecordData.visitor" placeholder="请输入陪同人员的姓名，可不填写">
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>联系电话:</span>
                    </div>
                    <div class="tiem-section-input">
                        <input type="text" v-model="OutRecordData.mobile" placeholder="请输入你的联系电话">
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>外出原因:</span>
                    </div>
                    <div class="tiem-section-input">
                        <el-input type="textarea" :rows="2" :autosize="false" placeholder="请填写你的外出原因" v-model="OutRecordData.remark" class="custom-textarea"></el-input>
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <!-- <p class="cancel">取消</p> -->
                    </div>
                    <div class="tiem-section-input">
                        <el-button type="primary" style="width: 200px; height: 40px;" @click="AddOrUpdate()">确认</el-button>
                        <el-button style="width: 80px; height: 30px;" @click="AddOrUpdclose()">取消</el-button>
                    </div>
                </div>
            <!-- </div> -->
            </div>
        </div>
        <!-- /外出登记 -->
        <!-- 回来时间 -->
        <div class="fixed" v-if="UpdateVisiable">
            <div class="AddOrUpdContent">
                <div class="AddOrUpd-title">
                    <h4 style="width: auto; display: flex; margin: 10px; border-bottom: 1px block solid; justify-content: center;">回归登记</h4>
                    <i class="el-icon-close" @click="AddOrUpdclose()"></i>
                </div>
            <!-- <div class="coutent"> -->
                <p class="helloName">{{IntheTime}}，{{Greetings}}</p>
                <!-- <span class="userId">{{OutRecordData.manualRecordId}}</span> -->
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>外出人姓名:</span>
                    </div>
                    <div class="tiem-section-input">
                        <input type="text" v-model="OutRecordData.personName" placeholder="请填写要外出的人的名字">
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>登记人:</span>
                    </div>
                    <div class="tiem-section-input">
                        <input type="text" v-model="OutRecordData.userName" placeholder="请填写登记人的姓名">
                    </div>
                </div>
                <div class="item-section" style="display: flex; flex: 0.3">
                    <div class="tiem-section-text">
                        <span>状态:</span>
                    </div>
                    <div class="tiem-section-input">
                        <el-radio label="回来" v-model="OutRecordData.state2"></el-radio>
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>时间:</span>
                    </div>
                    <div class="tiem-section-input">
                        <span class="signTime">回归时间:</span>
                        <el-date-picker v-model="OutRecordData.signTime" type="datetime" :disabled="true" placeholder="登记时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 200px;">
                        </el-date-picker>
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>陪同人员:</span>
                    </div>
                    <div class="tiem-section-input">
                        <input type="text" v-model="OutRecordData.visitor" placeholder="请输入陪同人员的姓名，可不填写">
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>联系电话:</span>
                    </div>
                    <div class="tiem-section-input">
                        <input type="text" v-model="OutRecordData.mobile" placeholder="请输入你的联系电话">
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <span>外出原因:</span>
                    </div>
                    <div class="tiem-section-input">
                        <el-input type="textarea" :rows="2" :autosize="false" placeholder="请填写你的外出原因" v-model="OutRecordData.remark" class="custom-textarea"></el-input>
                    </div>
                </div>
                <div class="item-section">
                    <div class="tiem-section-text">
                        <!-- <p class="cancel">取消</p> -->
                    </div>
                    <div class="tiem-section-input">
                        <el-button type="primary" style="width: 200px; height: 40px;" @click="AddOrUpdate()">确认</el-button>
                        <el-button style="width: 80px; height: 30px;" @click="AddOrUpdclose()">取消</el-button>
                    </div>
                </div>
            <!-- </div> -->
            </div>
        </div>
        <!-- /回来时间 -->
    </div>
</template>
<script>
import axios from 'axios';
import {listPage,listPage2,Add,selectById,UpdateOutRecord,daleteOutRecord} from '../../api/外出登记/outRecord';
export default {
    name:"OutRecord_",
    data(){
        return{
            // 获取id的参数
            ids:[],
            getId: '',
            // 列表数据的参数
            outRecordData:[],
            // 分页 查询的参数
            pager:{
                current: 1,
                size: 5,
                count: 0,
                searchText: '',
                day: '',
                beginTime: '',
                endTime: ''
            },
            // 隐藏hmtl元素，点击后才将其显示。
            Visiable: false,
            UpdateVisiable: false,
            operateIntOrOutTime: true,
            // 时间参数 新增与修改的标题
            IntheTime: '',
            Slogan: [
              "在意未来的离别，而舍弃当时的幸福，也许是件浪费的事呢。 --Re:LieF 献给亲爱的你",
              "趁着年轻，跌倒了还能爬起来，多吸取教训，学会重新站起来的方法也是很重要的。 --Re:LieF 献给亲爱的你",
              "有些事情，就是因为失败过才做得到。 --Re:LieF 献给亲爱的你",
              "顾虑着将来的离别 而错过眼前本可以拥有的幸福 或许才更令人扼腕。 --Re:LieF 献给亲爱的你",
              "今天的心情如何？",
              "祝你有一个开心的一天！",
              "为美好的世界献上祝福！",
              "花开富贵",
              "让我们一起迎接快乐的明天,我们就是为此才有翅膀!  --苍之彼方的四重奏",
              "无论怎样的瞬间  都会有新的开始在歌唱",
              "想要成为无论多么悲伤的时候，也能够漂亮微笑的人吧。 --文学少女",
              "长夜伴浪破晓梦，梦晓破浪伴夜长。 --樱之诗",
              "世界如此残忍，我们依然要生活在这里。",
              "——夜晚的向日葵，存在的理由又是什么呢？ ——命中注定要朝向阳光生长，那夜晚的向日葵们，岂不是很辛苦？ ——哈哈，总能忍过去。没有太阳，有一点点星光，一点点希望，活着，就足够了吧。 ——如初春雪，暮春樱，夏晚荷，秋寒叶，天降物哀，执拗、纯粹而绝美。 ——美好的每一天。",
              "由岐：可是啊，不是说向日葵会一直朝太阳的方向盛开吗？ 朝夏天的太阳公公盛开，就像光明的象征一样······ 皆守：向日葵并没有朝太阳盛开哦······ 由岐：哎？是这样吗？ 皆守：噢······向日葵追寻太阳，是在花开之前······ 一旦开花了，就再也不会追着太阳了 由岐：这样啊",
              "与其像是等待希望一般生存着 不如在此刻竭尽全力",
              "如果是为了自己的幸福，就算是毁灭这个世界我也愿意。 --不死者之王",
              "当再一次面临着恐惧，困难 的选择时，就对着天空大声的喊出 再做一次尝试吧！ 毕竟我们就是为此而来的。--Re:LieF 献给亲爱的你",
              "幸福 离别 爱情 还有友情 都是美梦中的滑稽儿戏 全部都可以用金钱置换 可能明天就会死去。可能一切都会毫无意义。在早晨 夜晚 春天 秋天 不变的是总有人在某处死去。无论是梦想明天还是任何东西都不需要。只要你能活着就好。没错。原来我、是想唱出这样的曲子啊。--被生命所厌恶",
              "成为大人之后就舍弃掉的梦想它，何时我还能再拾起吗 不想失去的东西还满满有很多呢 所以说 我什么时候 都会一直守护下去​  --直到我舍弃梦想成为大人",
              "你那最初的话语，我无法用语言传达 所以 只能这样一直唱着，渐渐地 日复一日 年复一年，世界也黯然失色只要你给予的光芒没有褪去,无论何时 我都会一直歌唱着 --最初的声音",
              "天空的颜色 风的气味 大海的深沉 我的歌声 属于你的 那最初的声音 无论在世界的哪个角落 我都会歌唱 唱出那属於每个人的 最初的声音 --最初的声音"
          ],
            Greetings: '',
            timestamp: 0,
            // 新增和修改的参数
            OutRecordData:{
                manualRecordId: '',
                personName: '',
                userName: '',
                state: '外出',
                state2: '回来',
                inTime: '',
                outTime: '',
                signTime: '',
                visitor: '',
                mobile: '',
                remark: '',
            },
            // 控制数据查询的方式
            selectData: true
        }
    },
    methods:{
        // 初始化列表数据 分页 查询
        init(pager){
            listPage(pager).then(res =>{
                if(res.code == 300){
                    this.$message({
                        showClose: true,
                        message: '好像没有数据了（悲',
                        type: 'warning'
                    })
                    this.outRecordData = [];
                    this.pager.count = res.count;
                }
                if(res.code == 200){
                    this.$message({
                            showClose: true,
                            message: 'code 200',
                            type: 'success'
                    });
                    this.outRecordData = res.outRecordList;
                    this.pager.count = res.count;
                }
            }).catch(error =>{
                console.log(error);
                this.$message(error);
            })
        },
        init2(pager){
            listPage2(pager).then(res =>{
                if(res.code == 300){
                    this.$message({
                        showClose: true,
                        message: '好像没有数据了（悲',
                        type: 'warning'
                    })
                    this.outRecordData = [];
                    this.pager.count = res.count;
                }
                if(res.code == 200){
                    this.$message({
                            showClose: true,
                            message: 'code 200',
                            type: 'success'
                    });
                    this.outRecordData = res.outRecordList;
                    this.pager.count = res.count;
                }
            }).catch(error =>{
                console.log(error);
                this.$message(error);
            })
        },
        // 初始化 新增 or 修改
        toAddOrUpdate(id) {
            this.getId = id;
            
            const now = new Date();

            const year = now.getFullYear();
            const month = ('0' + (now.getMonth() + 1)).slice(-2);
            const day = ('0' + now.getDate()).slice(-2);
            const hour = ('0' + now.getHours()).slice(-2);
            const minutes = ('0' + now.getMinutes()).slice(-2);
            const seconds = ('0' + now.getSeconds()).slice(-2);
            const formattedDate = `${year}-${month}-${day} ${hour}:${minutes}:${seconds}`;
            if(id == 0){
                this.OutRecordData.signTime = formattedDate;
            }else{
                this.OutRecordData.outTime = formattedDate;
            }
            console.log(formattedDate);

            // 判断时间段
            if (hour >= 0 && hour < 6) {
                this.IntheTime = '早点休息吧。';
            } else if (hour >= 6 && hour < 10) {
                this.IntheTime = '早上好';
            }else if(hour >=10 && hour <12){
                this.IntheTime = '上午好';
            }else if (hour >= 12 && hour < 18) {
                this.IntheTime = '下午好';
            } else {
                this.IntheTime = '晚上好';
            }
            const randomIndex = Math.floor(Math.random() * this.Slogan.length);
            this.Greetings = this.Slogan[randomIndex];

            if(id == 0){
                this.Visiable = true;
            }else{
                if(this.selectData == true){
                    this.Visiable = true;
                    const datas = {
                        "cmd": "toUpdate",
                        "id": id
                    }
                    selectById(datas).then(res =>{
                        console.log(res);
                        this.OutRecordData = res.getIdList[0];
                        this.OutRecordData.state = "外出";
                        this.OutRecordData.outTime = formattedDate;
                    }).catch(error =>{
                        this.$message({
                            showClose: true,
                            message: 'Error'+error,
                            type: 'error'
                        })
                    })
                }else{
                    this.UpdateVisiable = true;
                    const datas = {
                        "cmd": "toUpdate",
                        "id": id
                    }
                    selectById(datas).then(res =>{
                        console.log(res);
                        this.OutRecordData = res.getIdList[0];
                        this.OutRecordData.state2 = "回来";
                        this.OutRecordData.outTime = formattedDate;
                    }).catch(error =>{
                        this.$message({
                            showClose: true,
                            message: 'Error'+error,
                            type: 'error'
                        })
                    })
                }
            }

        },
        // 新增或者修改
        AddOrUpdate(){
            // 表单验证
            let personName = this.OutRecordData.personName;
            let userName = this.OutRecordData.userName;
            let inTime = this.OutRecordData.inTime;
            let mobile = this.OutRecordData.mobile;
            // 判断外出人姓名是否为空
            if(personName == "" || personName == null){
                this.$message({
                    showClose: true,
                    message: '外出人姓名不能为空哦！',
                    type: 'error'
                })
                return;
            }
            // 判断外出人姓名是否为数字
            if(/^\d+$/.test(personName)){
                this.$message({
                    showClose: true,
                    message: '外出人姓名不能为数字哦！',
                    type: 'error'
                })
                return;
            }
            // 判断外出人姓名长度
            console.log(personName.length);
            if(personName.length > 10){
                this.$message({
                    showClose: true,
                    message: '你的名字真的有这么长吗！',
                    type: 'error'
                })
                return;
            }
            // 判断外出人名字是否为一个字
            if(personName.length == 1){
                this.$message({
                    showClose: true,
                    message: '你的名字真的只有一个字吗！',
                    type: 'error'
                })
                return;
            }
            // 判断登记人是否为空
            if(userName == "" || userName == null){
                this.$message({
                    showClose: true,
                    message: '登记人姓名不能为空哦！',
                    type: 'error'
                })
                return;
            }
            // 判断登记人是否为数字
            if(/^\d+$/.test(userName)){
                this.$message({
                    showClose: true,
                    message: '外出人姓名不能为数字哦！',
                    type: 'error'
                })
                return;
            }
            // 判断登记人的名字长度
            if(userName.length > 10){
                this.$message({
                    showClose: true,
                    message: '你的名字真的有这么长吗！',
                    type: 'error'
                })
                return;
            }
            // 判断登记人的名字是不是为一个字
            if(userName.length == 1){
                this.$message({
                    showClose: true,
                    message: '你的名字真的只有一个字吗！',
                    type: 'error'
                })
                return;
            }
            // 判断外出时间是否为空
            if(inTime == "" || inTime == null || inTime.length == 0){
                this.$message({
                    showClose: true,
                    message: '你的外出时间还没有填写哦！',
                    type: 'error'
                })
                return;
            }
            // 判断联系电话是否为空
            if(mobile == "" || mobile == null || mobile.length == 0){
                this.$message({
                    showClose: true,
                    message: '你的联系电话还没有填写哦！',
                    type: 'error'
                })
                return;
            }
            // 判断联系电话是否为字符串
            if(!/^\d+$/.test(mobile)){
                this.$message({
                    showClose: true,
                    message: '联系电话不能是文字哦！',
                    type: 'error'
                })
                return;
            }
            // 判断联系电话的长度是否正确
            if(mobile.length == 11 || mobile.length == 10){
                console.log(true);
            }else{
                this.$message({
                    showClose: true,
                    message: '请输入11位数字的或者10位数的联系电话！',
                    type: 'error'
                })
                return;
            }
            // 以上是表单验证

            if(this.getId == 0){
                if(this.OutRecordData.state == "外出"){
                    this.OutRecordData.state = 1;
                }
                if(this.OutRecordData.visitor == ""){
                    this.OutRecordData.visitor = "无";
                }
                if(this.OutRecordData.remark == ""){
                    this.OutRecordData.remark = "未填写";
                }
                let formData = {
                    "personName": this.OutRecordData.personName,
                    "state": this.OutRecordData.state,
                    "visitor": this.OutRecordData.visitor,
                    "mobile": this.OutRecordData.mobile,
                    "inTime": this.OutRecordData.inTime,
                    "remark": this.OutRecordData.remark,
                    "userName": this.OutRecordData.userName,
                    "signTime": this.OutRecordData.signTime
                };
                Add(formData).then(res =>{
                    console.log(res);
                    if(res.code == 300){
                        this.$message({
                            showClose: true,
                            message: '该人物已经是外出状态，请不要重复的填写，如有写错的地方，请点击修改！',
                            type: 'error'
                        })
                        this.OutRecordData.state = "外出";
                    }
                    if(res.code == 200){
                        this.$message({
                            showClose: true,
                            message: '新增成功！',
                            type: 'success'
                        })
                        this.Visiable = false;
                        this.init(this.pager);
                    }
                    if(res.code == 201){
                        this.$message({
                            showClose: true,
                            message: '我们的养老院好像没有这个人物呢？换一个试试吧！',
                            type: 'error'
                        })
                        this.OutRecordData.state = "外出";
                    }
                    if(res.code == 202){
                        this.$message({
                            showClose: true,
                            message: '新增失败！',
                            type: 'error'
                        })
                    }
                }).catch(error =>{
                    this.$message({
                        showClose: true,
                        message: 'Error'+error,
                        type: 'error'
                    })
                })
            }else{
                if(this.OutRecordData.state == "外出"){
                    this.OutRecordData.state = 1;
                }
                if(this.OutRecordData.state2 == "回来"){
                    this.OutRecordData.state = 2;
                }
                if(this.OutRecordData.visitor == ""){
                    this.OutRecordData.visitor = "无";
                }
                if(this.OutRecordData.remark == ""){
                    this.OutRecordData.remark = "未填写";
                }
                // alert(this.getId)
                let formData = {
                    "manualRecordId": this.getId,
                    "personName": this.OutRecordData.personName,
                    "state": this.OutRecordData.state,
                    "visitor": this.OutRecordData.visitor,
                    "mobile": this.OutRecordData.mobile,
                    "inTime": this.OutRecordData.inTime,
                    "remark": this.OutRecordData.remark,
                    "userName": this.OutRecordData.userName,
                    "signTime": this.OutRecordData.signTime,
                    "outTime": this.OutRecordData.outTime
                };
                UpdateOutRecord(this.OutRecordData).then(res =>{
                    if(res.code == 200){
                        this.$message({
                            showClose: true,
                            message: '修改成功！',
                            type: 'success'
                        })
                        if(this.selectData == true){
                            this.Visiable = false;
                            this.init(this.pager);
                        }else{
                            this.UpdateVisiable = false;
                            this.init2(this.pager);
                        }
                    }
                }).catch(error =>{
                    this.$message({
                        showClose: true,
                        message: '修改失败!',
                        type: 'error'
                    })
                })
                
                // this.UpdateVisiable = true;
            }
        },
        // 关闭页面
        AddOrUpdclose(){
            this.$confirm('此操作将会关闭此页面填写的数据不会保留, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
                }).then(() => {
                    this.OutRecordData = {};
                    this.OutRecordData.state = '外出';
                    this.OutRecordData.state2 = '回归'
                    if(this.selectData == true){
                        if(this.getId == 0){
                            this.Visiable = false;
                        }else{
                            this.Visiable = false;
                        }
                    }else{
                        this.Visiable = false;
                        this.UpdateVisiable = false;
                    }
                }).catch(() => {
                    this.$message({
                        showClose: true,
                        type: 'info',
                        message: '已取消关闭'
                });          
            });
        },
        // 删除
        del(id){
            this.$confirm('此操作将永久删除该数据, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                const datas = {
                    "cmd": "delete",
                    "id": id
                }
                daleteOutRecord(datas).then(res =>{
                    this.$message({
                        showClose: true,
                        message: '删除成功！',
                        type: 'success'
                    })
                    if(this.selectData == true){
                        this.init(this.pager);
                    }else{
                        this.init2(this.pager);
                    }
                })
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });          
            });
        },
        // 点击回归
        clickOutTime(id){
            this.$confirm('此操点击后将修改状态为回归, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                const now = new Date();

                const year = now.getFullYear();
                const month = ('0' + (now.getMonth() + 1)).slice(-2);
                const day = ('0' + now.getDate()).slice(-2);
                const hour = ('0' + now.getHours()).slice(-2);
                const minutes = ('0' + now.getMinutes()).slice(-2);
                const seconds = ('0' + now.getSeconds()).slice(-2);
                const formattedDate = `${year}-${month}-${day} ${hour}:${minutes}:${seconds}`;

                const dadas = {
                    "id": id,
                    "cmd": "toUpdateOutTime",
                    "outTime": formattedDate
                }
                selectById(dadas).then(res =>{
                    this.$message({
                        showClose: true,
                        message: '修改成功!',
                        type: 'success'
                    })
                    if(this.outRecordData == null || this.outRecordData.length == 0){
                        this.outRecordData = [];
                        this.init(this.pager);
                    }else{
                        this.init(this.pager);
                    }
                }).catch(error =>{
                    this.$message({
                        showClose: true,
                        message: '修改失败!',
                        type: 'error'
                    })
                })
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });          
            });
        },
        // 外出历史
        inTimehistory(){
            this.selectData = false;
            this.init2(this.pager);
            this.operateIntOrOutTime = false;
        },
        // 未回归
        operateToUpd(){
            this.selectData = true;
            this.init(this.pager);
            this.operateIntOrOutTime = true;
        },
        // 以下提示
        beginMsg(){
            this.$message({
                    showClose: true,
                    message: '提示：这是外出时间，回来时间，登记时间的时间范围哦~',
                    type: 'success'
            });
        },
        timeMsg(){
            this.$message({
                    showClose: true,
                    message: '提示：这是外出时间，回来时间，登记时间的 精准时间哦~',
                    type: 'success'
            });
        },
        endMsg(){
            if(this.pager.endTime < this.pager.beginTime){
                this.$message({
                        showClose: true,
                        message: '你的时间逆转？',
                        type: 'error'
                });
            }
        },
        // /以上提示
        selectionData(val){
            this.ids = val;
            console.log(this.ids[0].bedID);
        },
        handleSizeChange(val) {
            this.pager.size = val
            console.log(`每页 ${val} 条`);
            if(this.selectData == true){
                this.init(this.pager);
            }
            if(this.selectData == false){
                this.init2(this.pager);
            }
        },
        handleCurrentChange(val) {
            this.pager.current = val
            console.log(`当前页: ${val}`);
            if(this.selectData == true){
                this.init(this.pager);
            }
            if(this.selectData == false){
                this.init2(this.pager);
            }
        }
    },
    computed: {
        slogan() {
            return this.Greetings + this.timestamp;
        }
    },
    created(){
        if(this.selectData == true){
            this.init(this.pager);
        }else{
            this.init2(this.pager);
        }
    }
}
</script>
<style scoped>
    *{
        margin: 0;
        padding: 0%;
    }
    .content{
        margin: auto;
    }
    a {
  text-decoration: none;
  font-size: 14px;
  color: rgb(70, 179, 179);
  margin: 5px;
}
span {
  text-decoration: none;
  font-size: 14px;
  color: rgb(70, 179, 179);
  margin: 5px;
  cursor: pointer;
}
button {
  width: 80px;
  height: 30px;
}
.content{
        width: 1172px;
        height: auto;
        display: flex;
        justify-content: center;
        align-content: center;
        flex-direction: column;
        margin: auto;
    }
    .operate{
          display: flex;
          align-items: center;
          flex-direction: row;
      }
      .operate-data{
          display: flex;
          align-items: center;
          justify-content: flex-start;
      }
      .operate-select{
          /* margin-right: 0px; */
          display: flex;
          justify-content: flex-end;
          margin-left: 25px;
          margin-bottom: 5px;
      }
      .search{
          width: 80px;
          height: 40px;
      }
    .fixed{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); 
        z-index: 11;
    }
    .AddOrUpdContent{
        display: flex;
        flex-direction: column;
        /* align-items: center; */
        width: 800px;
        height: 600px;
        background: #ffffff;
        box-shadow: 0 0 3px #000000;
        margin: auto;
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
        /* box-shadow: #000000 1px 1px 1px 1px; */
        position: absolute;
        margin: auto;
        top: 0;
        bottom: 0;
        right: 0;
        left: 0;
        z-index: 1;
    }
    .AddOrUpd-title{
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
    }
    .helloName{
      display: flex;
      /* flex: 10; */
      justify-content: flex-start;
      margin: 5px;
      color: #999;
      width: auto;
      flex-wrap: wrap;
      /* height: 40px; */
    }
    .el-icon-close{
        display: flex;
        /* flex: 0.1; */
        justify-content: flex-end;
        /* width: 30px;
        height: 30px; */
        cursor: pointer;
        /* background: #999; */
        color: #999;
        margin-left: 670px;
    }
    .userId{
        display: flex;
        align-items: flex-end;
        cursor: inherit;
    }
    .item-section{
      flex: 2;
      display: flex;
      flex-direction: row;
      /* align-items: center; */
      justify-content: center;
      margin: 8px;
      transition: 1s all;
      /* border-bottom: 1px #dde5e7 solid; */
    }
    .tiem-section-text{
      flex: 1;
      display: flex;
      justify-content: flex-end;
      /* background: red; */
      align-items: center;
      /* border-bottom: 1px blueviolet solid; */
    }
    .tiem-section-text>span{
      font-size: 16px;
      color: #000000;
    }
    .tiem-section-text>span:hover{
      color: #66b1ff;
      /* border-bottom: 1px #66b1ff solid; */
    }
    .tiem-section-input{
      flex: 2;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      /* background: #222; */
      margin-left: 5px;
      overflow: none;
      /* box-shadow: 0 0 5px #007bff; */
    }
    .tiem-section-input>input{
      width: 200px;
      height: 30px;
      border: none;
      outline: none;
      border-bottom: 2px #ccc solid;
      /* border-radius: 5px; */
      font-size: 12px;
      color: #000000;
      padding-left: 5px;
      margin: 5px;
      transition: 0.5s all;
    }
    .tiem-section-input>input:hover{
       border-color: #4ab3e0;
       box-shadow: 0 0 5px #4ab3e0;
    }
    .tiem-section-input>input:focus{
      width: 300px;
      height: 40px;
      border-color: #007bff;
      box-shadow: 0 0 5px #007bff;
      /* border: 1px #66b1ff solid; */
    }
    .tiem-section-input>input:not(:placeholder-shown){
      top: -10px;
      font-size: 16px;
      color: rgb(0, 0, 0);
    }
    .signTime{
        color: black;
    }
    .custom-textarea .el-textarea__inner {
        overflow-y: auto; /* 显示垂直滚动条 */
        resize: none;
    }
    .cancel{
      color: #999;
      font-size: 16px;
      cursor: pointer;
      display: flex;
      justify-content: flex-start;
      align-items: flex-end;
    }
</style>