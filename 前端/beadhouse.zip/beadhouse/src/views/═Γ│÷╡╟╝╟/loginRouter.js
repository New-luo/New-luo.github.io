import VueRouter from "vue-router";
import Vue from "vue";
import Cookies from "js-cookie";

import login from './Talktoeachother.vue';
import OpenOutRecord from './outRecord.vue';


Vue.use(VueRouter)

const router = new VueRouter({
    routes: [
        {
            path: '/outRecordLogin',
            component: login
        },
        {
            path: '/OpenOutRecord',
            component: OpenOutRecord,
            meta: {requiresAuth: true}
        }
    ]
})

router.beforeEach((to,from,next) =>{
    console.log("login");
    const flag = this.$store.state.flag;
    if(flag == false){
        next({path: '/outRecordLogin'})
    }else{
        next({path: '/OpenOutRecord'})
    }
})

export default router