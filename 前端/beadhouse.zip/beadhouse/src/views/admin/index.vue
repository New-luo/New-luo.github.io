<template>
  <div style="height:100vh; margin-top:-58px;  font-size: 14px !important;">
    <el-container class="container123" >
      <el-aside :width="collapse ? '4%' : '13%'">
        <el-menu :default-active="menuIndex"
        :collapse="collapse"
        background-color="#1F2D3D"
        text-color="#fff"
        @select="handleSelect"
        :unique-opened="true"
        >
          <el-menu-item index="1">
            <i class="el-icon-s-home"></i>
            <span slot="title">首页</span>
          </el-menu-item>
          <el-menu-item index="9"  v-permission="'105'">
    <i class="el-icon-setting"></i>
    <span slot="title">供应商信息</span>
  </el-menu-item>
  <el-menu-item index="10"  v-permission="'26'">
    <i class="el-icon-setting"></i>
    <span slot="title">病情登记</span>
  </el-menu-item>
  <el-menu-item index="11"  v-permission="'39'">
    <i class="el-icon-setting"></i>
    <span slot="title">外出登记</span>
  </el-menu-item>
  <el-menu-item index="12"  v-permission="'115'">
    <i class="el-icon-setting"></i>
    <span slot="title">老人资料</span>
  </el-menu-item>

          <!-- <el-submenu index="2">
            <template slot="title">
              <i class="el-icon-office-building"></i>
              <span>楼房资料</span>
            </template>
            <el-menu-item index="2-1">楼房管理</el-menu-item>
            <el-menu-item index="2-2">供应商</el-menu-item>
          </el-submenu> -->
          <el-submenu index="3"  v-permission="'97'">
            <template slot="title">
              <i class="el-icon-collection"></i>
              <span>接待管理</span>
            </template>
            <el-menu-item index="3-1"  v-permission="'44'" >接待登记管理</el-menu-item>
            <el-menu-item index="3-2"  v-permission="'21'">老人亲属管理</el-menu-item>
            <el-menu-item index="3-3"  v-permission="'115'">老人信息管理</el-menu-item>
          </el-submenu>
          <el-submenu index="4"  v-permission="'98'">
            <template slot="title">
              <i class="el-icon-collection"></i>
              <span>床位管理</span>
            </template>
            <el-menu-item index="4-1"  v-permission="'17'">楼房资料管理</el-menu-item>
            <el-menu-item index="4-2"  v-permission="'31'">房间资料</el-menu-item>
            <el-menu-item index="4-3"  v-permission="'7'">床位</el-menu-item>
            <!-- <el-menu-item index="4-4">住宿安排</el-menu-item> -->
          </el-submenu>
         
          <el-submenu index="6"  v-permission="'99'">
            <template slot="title">
              <i class="el-icon-collection"></i>
              <span>货物管理</span>
            </template>
            <el-menu-item index="6-2"  v-permission="'59'">货物分类管理</el-menu-item>
            <el-menu-item index="6-3"  v-permission="'68'" >货物信息管理</el-menu-item>
            <el-menu-item index="6-4"  v-permission="'76'">货物采购管理</el-menu-item>
            <el-menu-item v-permission="'79'" index="6-5">货物订单管理</el-menu-item>
            <el-menu-item index="6-6"  v-permission="'86'">货物领用</el-menu-item>
            <el-menu-item index="6-7"  v-permission="'112'">货物领用详情</el-menu-item>
            <el-menu-item index="6-8"  v-permission="'92'">货物仓库</el-menu-item>
          </el-submenu>
          <el-submenu index="7"  v-permission="'100'">
            <template slot="title">
              <i class="el-icon-collection"></i>
              <span>药品管理</span>
            </template>
            <el-menu-item index="7-2"  v-permission="'63'">药品分类管理</el-menu-item>
            <el-menu-item index="7-3"  v-permission="'73'">药品信息管理</el-menu-item>
            <el-menu-item index="7-4"  v-permission="'77'">药品采购管理</el-menu-item>
            <el-menu-item index="7-5"  v-permission="'82'">药品订单管理</el-menu-item>
            <el-menu-item index="7-6"  v-permission="'88'">药品领用</el-menu-item>
            <el-menu-item index="7-7"  v-permission="'113'">药品领用详情</el-menu-item>
            <el-menu-item index="7-8"  v-permission="'91'">药品仓库</el-menu-item>
          </el-submenu>
          
            <el-submenu index="5" v-permission="'101'">
            <template slot="title">
              <i class="el-icon-collection"></i>
              <span>系统管理</span>
            </template>
            <el-menu-item  v-permission="'53'"  index="5-1">用户管理</el-menu-item>
            <el-menu-item  v-permission="'11'"  index="5-2">角色管理</el-menu-item>
          </el-submenu>
   

        </el-menu>
      </el-aside>

      <el-container>
        <el-header style="height: auto;">
          <el-row type="flex" style="align-items: center;" class="header-row">
            <div style="cursor: pointer;
            padding-right: 1%;
            font-size: 20px;
            display: flex;
            align-items: flex-end;" 
            @click="collapse = !collapse">
              <i :class=" collapse ? 'el-icon-s-unfold' : 'el-icon-s-fold'"></i>
            </div>
            <el-col style="display: flex; align-items: center;" :span="24">
              <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item :to="{path: '/1'}">首页</el-breadcrumb-item>
                <el-breadcrumb-item v-for="item in breadcrumb" v-if="item != '1'">
                  <span v-for="child in components" v-if="item === child.menuPath">{{ child.name }}</span>
                </el-breadcrumb-item>
              </el-breadcrumb>
            </el-col>    

        

  <el-col style="display: flex; align-items: center; margin-left:720px" :span="1"  >
    
    <div class="block"><el-avatar :size="30" :src="pic" style="margin-left:-220px"></el-avatar></div>   
  <el-dropdown :hide-on-click="false">
  <span class="el-dropdown-link" style="margin-left:-120px">
  {{welcomeMessage}}<i class="el-icon-arrow-down el-icon--right"></i>
  </span>
  <el-dropdown-menu slot="dropdown"style="margin-left:-120px">
    <el-dropdown-item>{{role}}</el-dropdown-item>
    <el-dropdown-item><a @click="add">修改密码</a></el-dropdown-item>
    <el-dropdown-item><a @click="delToken">退出系统</a></el-dropdown-item>
    <el-dropdown-item><a @click="clearTabs">清空标签页</a></el-dropdown-item>
  </el-dropdown-menu>
</el-dropdown>
</el-col>  
</el-row>

          
          <el-row>
            <el-tabs v-model="editableTabsValue" type="border-card" @tab-click="tab" @tab-remove="removeTab">
              <el-tab-pane
                v-for="(item,index) in tabs"
                :key="index"
                :label="item.title"
                :name="index + ''"
                :closable="item.title === '首页' ? false : true"
              >
              </el-tab-pane>
            </el-tabs>
          </el-row>
        </el-header>
        <el-main>
          <router-view></router-view>
          <!-- <transition name="el-zoom-in-top">
            <component :is="components[componentIndex].component" v-show="components[componentIndex].name === '首页' ? true : show"></component>
          </transition> -->
        </el-main>
      </el-container>
    </el-container>
    <el-dialog
      title="修改个人密码"
      :visible.sync="centerDialogVisible"
      width="30%"
      center>
      <el-form :model="dataForm" ref="dataForm" :rules="dataRule" inline label-width="100px" style="width:100%;">
        <el-row>
          <el-col :span="24">
            <el-form-item prop="passWord" label="旧密码">
              <el-input v-model="dataForm.passWord"/>
            </el-form-item>
    
            <el-form-item prop="newpassWord" label="新密码">
              <el-input v-model="dataForm.newpassWord"/>
            </el-form-item>
    
            <el-form-item prop="cfgpwdpassWord" label="确认密码">
              <el-input v-model="dataForm.cfgpwdpassWord"/>
            </el-form-item>
          </el-col>
        </el-row>
    
      </el-form>
      <span slot="footer" class="dialog-footer">
          <el-button @click="centerDialogVisible = false">取 消</el-button>
          <el-button type="primary"  @click="upload()">确 定</el-button>
        </span>
    </el-dialog>
  </div>
</template>
<script>
import {getpassword} from '../../api/user'
export default {
  name: 'Admin_',
 
  data() {
    return {
      centerDialogVisible: false,
      pic:'',
      dataForm:{
                   passWord:'',
                   newpassWord:'',
                   cfgpwdpassWord:'',
          },
          dataRule:{
            passWord: [
                { required: true, message: '旧密码不能为空', trigger: 'blur' }
            ],
            newpassWord: [
                { required: true, message: '新密码不能为空', trigger: 'blur' }
            ],
            cfgpwdpassWord: [
                { required: true, message: '确认密码不能为空', trigger: 'blur' },  
            ],
        },

      welcomeMessage:this.$Cookie.get('userName'),
      role:this.$Cookie.get('role'),
      editableTabsValue: localStorage.getItem('editableTabsValue') || '0',
      tabs: JSON.parse(localStorage.getItem('tabs')) || [{ title: '首页' }],
      breadcrumb: JSON.parse(localStorage.getItem('breadcrumb')) || [],
     
      components: [{
        name: '首页',
      
        menuPath: '1'
      },
      // {
      //   name: '楼房资料',
      //   menuPath: '2'
      // },
      // {
      //   name: '楼房管理',
      //   component: house,
      //   menuPath: '2-1'
      // },
      // {
      //   name: '供应商',
      //   component: supplier,
      //   menuPath: '2-2'
      // },
      {
        name: '接待管理',
        menuPath: '3'
      },
      {
        name: '接待登记管理',
        menuPath: '3-1'
      },
      {
        name: '老人亲属管理',
       
        menuPath: '3-2'
      },
      {
        name: '老人信息管理',
        menuPath: '3-3'
      },
      {
        name: '床位管理',
        menuPath: '4'
      },
      {
        name: '楼房资料管理',
       
        menuPath: '4-1'
      },
      {
        name: '房间资料',
       
        menuPath: '4-2'
      },
      {
        name: '床位',
        
        menuPath: '4-3'
      },
      // {
      //   name: '住宿安排',
      //   component: Tab13Component,
      //   menuPath: '4-4'
      // },
      {
        name: '系统管理',
        menuPath:'5'
      },
      {
        name: '用户管理',
        menuPath:'5-1',
      },
      {
        name: '角色管理',
        menuPath:'5-2',
      },

      {
        name: '货物管理',
        menuPath: '6'
      },
      {
        name: '货物供应商',
        menuPath: '6-1'
      },
      {
        name: '货物分类',
        menuPath: '6-2'
      },
      {
        name: '供应商信息',
        menuPath: '9'
      },
      {
        name: '货物信息管理',
        menuPath: '6-3'
      },
      {
        name: '货物采购管理',
        menuPath: '6-4'
      },
      {
        name: '货物订单管理',
        menuPath: '6-5'
      },
      {
        name: '货物领用',
        menuPath: '6-6'
      },  
      {
        name: '货物领用详情',
        menuPath: '6-7'
      },
      {
        name: '货物仓库',
        menuPath: '6-8'
      },
      {
        name: '药品管理',
        menuPath: '7'
      },
      {
        name: '药品分类',
        menuPath: '7-2'
      },
      {
        name: '药品信息管理',
        menuPath: '7-3'
      },
      {
        name: '药品采购管理',
        
        menuPath: '7-4'
      },
      {
        name: '药品订单管理',
      
        menuPath: '7-5'
      },
      {
        name: '药品领用',
        menuPath: '7-6'
      },
      {
        name: '药品领用详情',
        menuPath: '7-7'
      },
      {
        name: '药品仓库',
        menuPath: '7-8'
      },
      {
        name: '用户管理',
        menuPath: '8'
      },
      {
        name: '病情登记',
        menuPath: '10'
      },
      {
        name: '外出登记',
        menuPath: '11'
      },
      {
        name: '老人资料',
        menuPath: '12'
      },
    ],
      componentIndex: 0,
      editableTabsValue: '0',
      menuIndex: '1',
      show: false,
      collapse: false,
      breadcrumb: [],
      tabs:[{
        title: '首页'
      }]
     
    }
  },



  beforeMount() {
  // 从本地存储中获取标签页信息
  const tabs = JSON.parse(localStorage.getItem('tabs')) || [{ title: '首页' }];
  const editableTabsValue = localStorage.getItem('editableTabsValue') || '0';
  const breadcrumb = JSON.parse(localStorage.getItem('breadcrumb')) || [];

  this.tabs = tabs;
  this.editableTabsValue = editableTabsValue;
  this.breadcrumb = breadcrumb;

  // 根据标签页信息设置其他相关状态
  if (this.editableTabsValue !== null) {
    const index = parseInt(this.editableTabsValue);
    this.componentIndex = index;
    this.menuIndex = this.tabs[index].menuPath;
  }
},

  created(){
    if (this.$Cookie.get('token') === undefined || this.$Cookie.get('token') === '') {
        this.$router.push('/login');
      }
    const activeTabIndex = sessionStorage.getItem('activeTabIndex');
  if (activeTabIndex !== null) {
    this.activeTabIndex = parseInt(activeTabIndex);
  }
  this.pic = this.$Cookie.get('pic');
  console.log(this.pic)

  }, 

  methods: {
    add(){
    this.centerDialogVisible = true
},
    handleTabChange(index) {
    this.activeTabIndex = index;
    sessionStorage.setItem('activeTabIndex', index);
  },
    handleSelect(key,keyPath){
      // 创建‘面包屑’
      this.breadcrumb = keyPath
      this.components.some((item,index) =>{
        if(item.menuPath === key){
          this.menuIndex = key
          this.addTab(item.name)
         this.$router.push({ path: '/' + key })  // 使用路由进行跳转
          return true;
        }
      })
    },
    clearTabs() {
  this.tabs = [{ title: '首页' }]; // 清空标签页
  this.editableTabsValue = '0'; // 将当前选中的标签页值设为首页
  this.componentIndex = 0; // 将当前展示的组件索引设为首页
  this.menuIndex = '1'; // 将当前选中的菜单索引设为首页
  this.breadcrumb = []; // 清空面包屑导航
  this.show = false; // 关闭组件展示
  localStorage.setItem('tabs', JSON.stringify(this.tabs)); // 更新本地存储的标签页信息
  localStorage.setItem('editableTabsValue', this.editableTabsValue); // 更新本地存储的当前选中标签页值
  localStorage.setItem('breadcrumb', JSON.stringify(this.breadcrumb)); // 更新本地存储的面包屑导航信息
  this.$router.push('/1');
},
upload() {
  if(this.dataForm.newpassWord!=this.dataForm.cfgpwdpassWord){
        this.$message.error('新密码与确认密码不一致');
        return
  }
       let formData = new FormData();
    formData.append('password', this.dataForm.passWord);
    formData.append('newpassword', this.dataForm.newpassWord);
    this.$refs['dataForm'].validate((valid) => {
      if (valid) {
        getpassword(formData).then(res => { 
        if(res.codes==201){
          this.centerDialogVisible = true
        }else{
        this.centerDialogVisible = false
        this.$router.push('/login');
        this.$Cookie.remove('passWord');
        }
        this.$message({
          message: res.msg,
          type: 'success'
        });
      }).catch(error => {
        this.$message.error('你没有修改个人密码的权限,请与系统管理员联系');
      }); 
      }
    })
    },
delToken() {
     this.$confirm('此操作将退出该系统, 是否继续?', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    this.tabs = [{ title: '首页' }]; // 清空标签页
  this.editableTabsValue = '0'; // 将当前选中的标签页值设为首页
  this.componentIndex = 0; // 将当前展示的组件索引设为首页
  this.menuIndex = '1'; // 将当前选中的菜单索引设为首页
  this.breadcrumb = []; // 清空面包屑导航
  this.show = false; // 关闭组件展示
  localStorage.setItem('tabs', JSON.stringify(this.tabs)); // 更新本地存储的标签页信息
  localStorage.setItem('editableTabsValue', this.editableTabsValue); // 更新本地存储的当前选中标签页值
  localStorage.setItem('breadcrumb', JSON.stringify(this.breadcrumb)); // 更新本地存储的面包屑导航信息
    localStorage.removeItem('username');
      this.$Cookie.remove("token")
      this.$Cookie.remove('userName');
      this.$Cookie.remove('passWord');
      this.$Cookie.remove('time');
      this.$Cookie.remove('pic');
      this.$Cookie.remove('role');
    this.$notify({
      title: '退出成功',
      message: '欢迎再次回来！',
      type: 'success'
    });
    
    this.$router.push('/login');
  }).catch(() => {
    this.$message({
            type: 'info',
            message: '已取消此操作'
          });          
  });
},
    // 定位组件
    tab(tab){
      this.components.some((item,index) =>{
        if(item.name === tab.label){
          this.componentIndex = index
          this.menuIndex = item.menuPath
          var path = item.menuPath.split('-')
          path.pop()
          path.push(item.menuPath)
          this.breadcrumb = path
          this.show = true
          this.$router.push({ path: '/' + item.menuPath })
          return true;
        }
      })
    },
    // 添加tab
    addTab(e){
      // 查找重复项
      let flag = this.tabs.some((item,index) =>{
        if(item.title === e){
          this.editableTabsValue = index + ''
          this.show = true
          return true;
        }else{
          return false;
        }
      })
      if(flag){
        // 确认存在重复项，并定位组件
        this.components.some((item,index) =>{
          if(item.name === e){
            this.componentIndex = index
            this.show = true
            return true;
          }
        })
      }else{
        // 创建tab
        this.tabs.push({
          title: e
        })
        this.tabLocation()
      }
      localStorage.setItem('tabs', JSON.stringify(this.tabs));
  localStorage.setItem('editableTabsValue', this.editableTabsValue);
  localStorage.setItem('breadcrumb', JSON.stringify(this.breadcrumb));
    },
    // 移除tab
    removeTab(tabIndex){
      

      this.tabs.splice(tabIndex,1)
      var path = this.tabLocation()
      this.breadcrumb = path
      console.log(path)
      for (var i = 0; i < path.length; i++) {
  var element = path[i];
  console.log(element);
}
 this.$router.push({ path: '/' + element })
  localStorage.setItem('tabs', JSON.stringify(this.tabs));
  localStorage.setItem('editableTabsValue', this.editableTabsValue);
  localStorage.setItem('breadcrumb', JSON.stringify(this.breadcrumb));
    },
    // 标签页定位
    tabLocation(){
      var length = this.tabs.length
      var path
      this.editableTabsValue = length - 1 + ''
      this.components.some((item,index) => {
        if(this.tabs[length - 1].title === item.name){
          this.componentIndex = index
          path = item.menuPath.split('-')
          path.pop()
          path.push(item.menuPath)
          this.breadcrumb = path
          this.menuIndex = item.menuPath
          this.show = true
          return true;
        }
      })
      localStorage.setItem('tabs', JSON.stringify(this.tabs));
      localStorage.setItem('editableTabsValue', this.editableTabsValue);
      localStorage.setItem('breadcrumb', JSON.stringify(this.breadcrumb))
     return path
     
    },
    isCollapse(){
      this.collapse = !this.collapse
    },
    test(val){
      console.log(this.aaa)
    }
  }
}
</script>
<style> 
body {
  margin: 0;
  padding: 0;
}
/* *{
  font-size: 14px !important;
} */
/* #app {
  height: 100vh;
  margin: 0;
} */

.container123 {
  height: 100%;
}

.el-header {
  background-color: #F5F7FA;
  color: #333;
  text-align: center;
  position: static;
  padding: 0;
}
.header-row {
    background: #fff;
    margin-bottom: 0.2%;
    padding: 1%;
    box-shadow: 0 2px 4px 0 rgba(0,0,0,.12), 0 0 6px 0 rgba(0,0,0,.04);
}
.el-aside {
  background-color: #1F2D3D;
  transition: width .4s ease-in-out;
}
.el-menu{
  border: none;
}

.el-menu:not(.el-menu--collapse){
  width: 100%;
}

.el-menu-item, .el-submenu__title {
    height: 56px;
    list-style: none;
}

.el-menu-item{
  transition: border-color .2s,background-color .2s,color .2s;
}


.el-submenu .el-menu-item{
  min-width: 0px;
}

.el-main {
  background-color: #fff;
  color: #333;
  text-align: center;
  padding: 1%;
}

.el-tabs--border-card>.el-tabs__content {
    padding: 0;
}
.el-tabs--border-card{
  box-shadow: none;
  border: none;
  background: none;
}
.el-tabs__nav-scroll{
  padding: 0 1%;
}
.el-tabs--border-card>.el-tabs__header{
  border-bottom: 1px solid #E4E7ED;
  background: none;
}
.el-tabs--border-card>.el-tabs__header .el-tabs__item{
  margin-top: 1px;
  transition: all .1s cubic-bezier(.645,.045,.355,1);
}
.el-tabs--border-card>.el-tabs__header .el-tabs__item.is-active{
  border-top-color: #DCDFE6;
}

/* 滚动条样式 */
::-webkit-scrollbar {
    background-color: #fff0;
    width: 6px;
}
::-webkit-scrollbar-thumb {
    background-color: #ffffff3d;
    border-radius: 10px;
}
::-webkit-scrollbar-thumb:hover {
    background-color: #ffffff50;
}
</style>
