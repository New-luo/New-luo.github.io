<template>
  <div  v-permission="'21'">
    <div>
      <h2>老人亲属</h2>
    </div>
  <table align="center" width="900px">
      <tr>            
        <td>
          <el-form :inline="true" v-model="listQuery">
            <el-row :span="24">
                <el-form-item prop="realName">
                  <el-input v-model="listQuery.realName" placeholder="请输入老人姓名" @change="relativeList()" clearable/>
                </el-form-item>
                <el-form-item prop="relativeName">
                  <el-input v-model="listQuery.relativeName" placeholder="请输入亲属名称" @change="relativeList()" clearable/>
                </el-form-item>
                <el-form-item prop="mobile">
                  <el-input v-model="listQuery.mobile" placeholder="请输入亲属电话" @change="relativeList()" clearable/>
                </el-form-item>
                <el-button
                  type="primary"
                  style="margin-top: 8px; margin-left: 8px"
                  icon="el-icon-search"
                  @click="relativeList()"
                  >搜索</el-button
                >
                <el-button type="primary" style=" margin-top: 8px;"  icon="el-icon-plus"   @click="add(0) ">新增</el-button>
            </el-row>
        </el-form>
        </td>
      </tr>
  </table>
   <el-table :data="relative" border style="width: 100%">
      <el-table-column prop="relativeId" label="ID"></el-table-column>
      <el-table-column prop="realName" label="人员名称"></el-table-column>
      <el-table-column prop="relativeName" label="亲属名称"></el-table-column>
      <el-table-column prop="typeName" label="亲属关系"></el-table-column>
      <el-table-column prop="mobile" label="联系电话"></el-table-column>
      <el-table-column prop="addr" label="地址"></el-table-column>
      <el-table-column prop="remark" label="备注"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="primary" v-permission="'40'"  @click="add(scope.row.relativeId)" icon="el-icon-edit" circle></el-button>
          <el-button type="danger" v-permission="'20'" @click="dele(scope.row.relativeId)" icon="el-icon-delete" circle></el-button>
        </template>
      </el-table-column>
    </el-table>
<div class="block">
  <el-pagination
    @size-change="handleSizeChange"
    @current-change="handleCurrentChange"
    :current-page="listQuery.Current"
    :page-sizes="[5, 10, 20, 50]"
    :page-size="listQuery.size"
    layout="total, sizes, prev, pager, next, jumper"
    :total="listQuery.total">
   </el-pagination>
</div>
<add-or-update v-if="addOrUpdateVisible" ref="AddOrUpdate" @refreshReturnData="relativeList"/>
  </div>
</template>
<script>
// import { readonly } from 'vue';
import {list,del,zd,toAdd} from '../../api/relative'
import AddOrUpdate from './relativeAdd.vue' 

  export default{
      name:"Relative_",
      components:{
      AddOrUpdate
  },
  data(){
      return{
          // querySearch:[],     //客户名称自动弹窗
          // querySearch2:[],    //客户访问事由地址自动弹窗
          listQuery:{
              relativeId:'',   //人员ID
              size: 5 ,      //每页多少条数据
              Current:1,    //默认第一页
              total:0,     //总页数
          },
          relative: [],//列表
          addOrUpdateVisible:false,//新增修改弹窗
        };
      },
      created() {
        this.relativeList(); 
      },
  methods:{
  handleSizeChange(val) {
   console.log(`每页 ${val} 条`);
    this.listQuery.size = val
    this.relativeList(); 
  },
  handleCurrentChange(val) {
   console.log(`当前页: ${val}`);
    this.listQuery.Current = val 
    this.relativeList(); 
  },



//删除
dele(id) {
console.log(id);
    this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(() => {
      var params = this.listQuery
      var curPageSize = this.relative.length
      params.Current = curPageSize == 1 ? params.Current - 1 : params.Current
      del(id).then(res => {
        if(res.code==200){
          this.$message({
        type: 'success',
        message: '删除成功!'
      });
      this.relativeList(); 
        } 
      })
      .catch(err => {
        this.$message.error('你没有删除数据的权限,请与系统管理员联系');
  });
    })
    .catch(() => {
      this.$message({
        type: 'info',
        message: '已取消删除'
      });          
    });
  },

// 条件.分页.查询列表
relativeList() {
  console.log(this.listQuery)
  list(this.listQuery).then(res => {
    this.relative = res.page.records;  
    this.listQuery.total = res.page.total;  
    console.log(res)
  })
  .catch(err => {
    this.$message.error('你没有查询学校表数据的权限,请与系统管理员联系');
  });
},

add(id){
  this.addOrUpdateVisible=true;
  if(id===0){
    //$nextTick异步处理，调用对话框的初始化函数
    this.$nextTick(() => {
      const personinfoSelect = [];
      toAdd(id).then(res =>{
        for(let i = 0; i<res.personinfo.length; i++){
          const personinfos = res.personinfo[i];
          personinfoSelect.push(personinfos)
        }
        console.log(id,personinfoSelect);
      })
      this.$refs.AddOrUpdate.disabledVisible = false
      this.$refs.AddOrUpdate.init(id,personinfoSelect);
    })  
    }else {
      this.$nextTick(() => {
        this.$refs.AddOrUpdate.disabledVisible = true
        this.$refs.AddOrUpdate.init(id,null);
      }) 
    }
  },
}
  }
</script>