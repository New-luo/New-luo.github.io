<template>
  <!-- <div  v-permission="'49'"> -->
    <div  v-permission="'115'">
      <div>
        <h2>老人资料</h2>
      </div>
      <!-- 操作 -->
      <table align="center" width="1200px" class="operatTable">
          <tr>
            <td>
                  <el-tabs v-model="operatTabs" @tab-click="handleTabClick">
                      <el-tab-pane label="正常" name="select-normal"></el-tab-pane>
                      <el-tab-pane label="欠费" name="select-finArrearage"></el-tab-pane>
                      <el-tab-pane label="离院" name="select-leave"></el-tab-pane>
                  </el-tabs>
                  <!-- <el-button  plain @click="init(pager.flag = 1)">正常</el-button>
                  <el-button  plain @click="init(pager.flag = 2)">欠费</el-button>
                  <el-button  plain @click="init(pager.flag = 3)">离院</el-button>
                  <el-button  plain>入住登记</el-button>
                  <el-button type="warning" plain>外出登记</el-button>
                  <el-button type="primary" plain>接待登记</el-button> -->
            </td>
            <td>
              <el-tabs v-model="operatTabsuiils" @tab-click="handleTabClick">
                      <el-tab-pane label="申报错误" name="declare-error"></el-tab-pane>    
                      <el-tab-pane label="物品异常接收" name="declare-error-get"></el-tab-pane>    
                      <!-- <el-tab-pane label="审核" name="check"></el-tab-pane> -->
                      <el-tab-pane label="缴费" name="pay_the_fees"></el-tab-pane>
                      <el-tab-pane label="外出登记" name="outrecord"></el-tab-pane>
                      <!-- <el-tab-pane label="亲属接待" name="relative"></el-tab-pane> -->
                  </el-tabs>
          </td>  
            <td>
              <el-form :inline="true" v-model="pager">
                <el-row :span="24">
                  <el-form-item  prop="personId">
                        <el-input  placeholder="请输入" v-model="pager.like" clearable/>
                    </el-form-item>
                    <el-button type="primary"  style=" margin-top: 8px;margin-left:8px" icon="el-icon-search" @click="init(pager.flag)">搜索</el-button>
                    <el-button type="primary" style=" margin-top: 8px;"  icon="el-icon-plus"   @click="toAddOrUpdate(0) ">新增</el-button>
                </el-row>
            </el-form>
            </td>
          </tr>
      </table>
      <!-- /操作 -->
      <!-- 列表 -->
      <div class="personinfoTable">
        <el-table :data="personinfo" border style="width: 100%" @selection-change="selectionData">
                <el-table-column type="selection" width="50"></el-table-column>
                <el-table-column prop="personId" label="用户id" width="70"> </el-table-column>
                <el-table-column prop="faceUrl" label="人脸图片" width="180">
                    <template slot-scope="scope">
                        <img :src="Api+scope.row.faceUrl" alt="error" class="face">
                    </template>
                </el-table-column>
                <el-table-column prop="realName" label="姓名" width="80"> </el-table-column>
                <el-table-column prop="communityId" label="养老院id" width="85"></el-table-column>
                <el-table-column prop="communityName" label="养老院名称" width="95"></el-table-column>
                <el-table-column prop="houseId" label="楼房ID" width="70"> </el-table-column>
                <el-table-column prop="termName" label="所属楼栋" width="85"> </el-table-column>
                <el-table-column prop="houseName" label="房号" width="75"> </el-table-column>
                <el-table-column prop="bedId" label="床位ID" width="70"> </el-table-column>
                <el-table-column prop="bedNo" label="床位号" width="70"> </el-table-column>
                <el-table-column prop="bedState" label="床位状态" width="135">
                      <template slot-scope="scope">
                          <div v-if="scope.row.bedState == '1'">
                              <p style="color: #51e031; font-weight: bold;">空闲</p>
                          </div>
                          <div v-if="scope.row.bedState == '2'">
                              <p style="color: #ec7a8b">该人物当前使用中</p>
                          </div>
                          <div v-if="scope.row.bedState == '3'">
                              <p style="color: #8f9f1b; font-weight: bold;">预定</p>
                          </div>
                          <div v-if="scope.row.bedState == '4'">
                              <p style="color: red; font-weight: bold;">维修中</p>
                          </div>
                      </template>
                </el-table-column>
                <el-table-column prop="nothing" label="床位损坏申报状态" width="180">
                        <template slot-scope="scope">
                            <div v-for="i in excepts_info" :key="i.personId">
                                <div v-if="i.personId === scope.row.personId">
                                    <template v-if="i.excepts_state === 0">
                                        <p style="color: red;">待审核</p>
                                    </template>
                                    <template v-if="i.excepts_state === 1">
                                        <p style="color: #8f9f1b;">审核中</p>
                                    </template>
                                    <template v-else-if="i.excepts_state === 2">
                                        <p style="color: rgb(32, 219, 76);">已审核</p>
                                    </template>
                                    <template v-else-if="i.excepts_state === 3">
                                        <p style="color: red;">损坏，待更换床位</p>
                                    </template>
                                    <template v-else-if="i.excepts_state === 4">
                                        <p style="color: blue;">维修中</p>
                                    </template>
                                    <template v-else-if="i.excepts_state === 5">
                                        <p style="color: red;">作废</p>
                                    </template>
                                </div>
                            </div>
                        </template>
                </el-table-column>
                <el-table-column prop="outrecordstate" label="外出状态" width="120">
                      <template slot-scope="scope">
                          <div v-if="scope.row.outrecordstate == '' || scope.row.outrecordstate == null">
                              <p style="color: #8f9f1b;">未有外出记录</p>
                          </div>
                          <div v-else-if="scope.row.outrecordstate == 1">
                              <p :loading="true" style="color: red;">外出</p>
                          </div>
                          <div v-else>
                              <p style="color: rgb(32, 219, 76);">回来</p>
                          </div>
                      </template>
                </el-table-column>
                <el-table-column prop="stayType" label="入住状态" width="120">
                      <template slot-scope="scope">
                          <div v-if="scope.row.stayType == 1">
                              <p style="color: rgb(32, 219, 76);">已入住</p>
                          </div>
                          <div v-if="scope.row.stayType == 2">
                              <p style="color: #92a15d">换房</p>
                          </div>
                      </template>
                </el-table-column>
                <el-table-column prop="sex" label="性别" width="70"> </el-table-column>
                <el-table-column prop="cardNo" label="身份证号" width="180"> </el-table-column>
                <el-table-column prop="age" label="年龄" width="70"> </el-table-column>
                <el-table-column prop="mobile" label="手机号" width="180"> </el-table-column>
                <!-- <el-table-column prop="relativeName" label="老人亲属名称" width="120"> </el-table-column>      
                <el-table-column prop="typeName" label="老人亲属关系" width="120"> </el-table-column>       -->
                <el-table-column prop="chairman" label="紧急联系人电话" width="180"> </el-table-column>      
                <el-table-column prop="personType" label="付款类型" width="180">
                  <template slot-scope="scope">
                    <div v-if="scope.row.personType == 1">
                        <p style="color: red;">按日收费</p>
                    </div>
                    <div v-if="scope.row.personType == 2">
                        <p style="color: blue;">按月收费</p>
                    </div>
                    <div v-if="scope.row.personType == 3">
                        <p style="color: #92a15d;">按年收费</p>
                    </div>
                    <div v-if="scope.row.personType == 4">
                        <p style="color: violet;">其它方式</p>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column prop="state" label="状态" width="80">
                    <template slot-scope="scope">
                        <div v-if="scope.row.state == 1">
                            <p style="color: rgb(32, 219, 76);">正常</p>
                        </div>
                        <div v-if="scope.row.state == 2">
                            <p style="color: red;">欠费</p>
                        </div>
                        <div v-if="scope.row.state == 3">
                            <p style="color: rgb(200, 255, 127);">离院</p>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column prop="inTime" label="入院时间" width="130"> </el-table-column>
                <el-table-column prop="expireDate" label="离开时间" width="130"> </el-table-column>
                <el-table-column prop="creater" label="创建者" width="80"> </el-table-column>
                <el-table-column prop="remark" label="备注" width="230"> </el-table-column>
            <!-- </el-table-column> -->
            <el-table-column label="操作" fixed="right" width="200px">
              <template slot-scope="scope"> 
                <div class="rightOptions">
                  <div class="UpdateOptions">
                    <span @click="toAddOrUpdate(scope.row.personId)">修改</span>
                  </div>
                  <div class="delOptions">
                    <span @click="dele(scope.row.personId)">删除</span>
                  </div>
                  <div class="faceOptions">
                    <span v-if="scope.row.faceUrl == 'null'">
                        上传头像
                    </span>
                    <span v-else @click="toUpdate_face(scope.row.personId)">
                        修改头像
                    </span>
                  </div>
                  <div class="delOptions">
                      <span v-if="scope.row.state == 2" @click="pay_the_fees(scope.row.personId)">缴费</span>
                  </div>
                </div>
                <!-- <el-button type="primary" @click="toAddOrUpdate(scope.row.personId)" icon="el-icon-edit" circle></el-button>
                <el-button type="danger" @click="dele(scope.row.personId)" icon="el-icon-delete" circle></el-button> -->
                <div class="delOptions">
                  <span type="primary" @click="go(scope.row.realName)" circle>药品领用</span>
                </div>
                <div class="faceOptions">
                  <span type="primary" @click="gos(scope.row.realName)" circle>货物领用</span>
                </div>
              </template>
            </el-table-column>
          </el-table>
      </div>
      <!-- /列表 -->
      <!-- 新增or修改 -->
        <div class="fixed" v-if="Visiable">
              <div class="AddOrUpdContent">
                  <div class="item">
                      <div class="item-title">
                          <div class="item-title-h">
                              <h2 v-if="flag == false">新增</h2>
                              <h2 v-if="flag == true">修改</h2>
                          </div>
                          <div class="item-title-close">
                            <i class="el-icon-close" @click="AddOrUpdateClose()"></i>
                          </div>
                      </div>
                  </div>
                  <div class="item">
                      <div class="item-text">
                          <p>用户ID:</p>
                      </div>
                      <div class="item-input">
                          <el-input style="width: 250px;" :disabled="true" v-model="AddOrUpdData.personId" placeholder="请输入用户ID"></el-input>
                      </div>
                      <div class="item-text">
                          <p>用户姓名:</p>
                      </div>
                      <div class="item-input">
                          <el-input style="width: 250px;" v-model="AddOrUpdData.realName" placeholder="请输入用户姓名"></el-input>
                      </div>
                  </div>
                  <div class="item">
                      <div class="item-text">
                          <p>性别:</p>
                      </div>
                      <div class="item-input">
                          <el-radio-group v-model="AddOrUpdData.sex">
                              <el-radio label="男"></el-radio>
                              <el-radio label="女"></el-radio>
                          </el-radio-group>
                      </div>
                      <div class="item-text">
                          <p>年龄:</p>
                      </div>
                      <div class="item-input">
                          <el-input style="width: 250px;" v-model="AddOrUpdData.age" placeholder="请输入年龄"></el-input>
                      </div>
                  </div>
                  <div class="item">
                      <div class="item-text">
                          <p>紧急联系人电话:</p>
                      </div>
                      <div class="item-input">
                          <el-input style="width: 250px;" v-model="AddOrUpdData.chairman" placeholder="请输入紧急联系人电话"></el-input>
                      </div>
                      <div class="item-text">
                          <p>手机号:</p>
                      </div>
                      <div class="item-input">
                          <el-input style="width: 250px;" v-model="AddOrUpdData.mobile" placeholder="请输入手机号"></el-input>
                      </div>
                  </div>
                  <div class="item">
                    <div class="item-text">
                          <p>身份证号:</p>
                      </div>
                      <div class="item-input">
                          <el-input v-model="AddOrUpdData.cardNo" style="width: 400px;" placeholder="请输入身份证号"></el-input>
                      </div>
                  </div>
                  <div class="item">
                      <div class="item-text">
                          <p>入院时间:</p>
                      </div>
                      <div class="item-input">
                          <el-date-picker type="datetime" :disabled="true" placeholder="选择日期时间" value-format="yyyy-MM-dd HH:mm:ss" v-model="AddOrUpdData.inTime"></el-date-picker>
                      </div>
                  </div>
                  <div class="item" v-if="flag">
                      <div class="item-text">
                          <p>离开时间:</p>
                      </div>
                      <div class="item-input">
                          <el-date-picker type="datetime" placeholder="选择日期时间" value-format="yyyy-MM-dd HH:mm:ss" v-model="AddOrUpdData.expireDate"></el-date-picker>
                      </div>
                  </div>
                  <div class="item">
                      <div class="item-text">
                          <p>创建者:</p>
                      </div>
                      <div class="item-input">
                          <el-input v-model="AddOrUpdData.creater" style="width: 400px;" placeholder="请输入创建者"></el-input>
                      </div>
                  </div>
                  <div class="item">
                      <div class="item-text">
                          <p>养老院:</p>
                      </div>
                      <div class="item-input">
                          <el-select v-model="AddOrUpdData.communityId" style="width: 150px;">
                            <el-option
                              v-for="community in selectedCommunity"
                              :key="community.communityid"
                              :label="community.communityname"
                              :value="community.communityid">
                            </el-option>
                          </el-select>
                      </div>
                      <div class="item-text">
                          <p>房号:</p>
                      </div>
                      <div class="item-input">
                          <el-select v-model="AddOrUpdData.houseId" style="width: 150px;">
                            <el-option
                              v-for="house in selectedHouse"
                              :key="house.houseId"
                              :label="house.termName + house.houseName"
                              :value="house.houseId">
                            </el-option>
                          </el-select>
                      </div>
                      <div class="item-text">
                          <p>床位号:</p>
                      </div>
                      <div class="item-input">
                          <el-select v-model="AddOrUpdData.bedId" style="width: 150px;">
                            <el-option
                              v-for="bed in selectedBedId"
                              :key="bed.bedID"
                              :label="bed.bedNO + bed.state"
                              :value="bed.bedID"
                              :disabled="bed.state != '空闲' ? true : false">
                            </el-option>
                          </el-select>
                      </div>
                  </div>
                  <div class="item">
                      <div class="item-text">
                          <p>付款类型:</p>
                      </div>
                      <div class="item-input">
                          <el-radio-group v-model="AddOrUpdData.personType" @input="personType(AddOrUpdData.personType)">
                              <el-radio label="按日收费"></el-radio>
                              <el-radio label="按月收费"></el-radio>
                              <el-radio label="按年收费"></el-radio>
                              <el-radio label="其它方式"></el-radio>
                          </el-radio-group>
                      </div>
                  </div>  
                  <div class="item">
                      <div class="item-text">
                          <p>备注:</p>
                      </div>
                      <div class="item-input">
                          <el-input style="width: 540px;" type="textarea" placeholder="请输入备注内容" v-model="AddOrUpdData.remark" class="remark"></el-input>
                      </div>
                  </div>
                  <div class="item">
                      <div class="item-commit" v-if="flag == false">
                          <el-button type="primary" @click="openfinance()">下 一 步</el-button>
                      </div>
                      <div class="item-commit" v-if="flag == true">
                          <el-button type="primary" @click="commitUpdate()">确 认</el-button>
                      </div>
                      <div class="item-close">
                        <el-button @click="AddOrUpdateClose()">取 消</el-button>
                      </div>
                  </div>
              </div>
        </div>
      <!-- /新增or修改 -->
      <!-- 亲属登记 -->
      <div class="fixed" v-if="relativeVisiable">
        <div class="relative">
            <div class="finance-title">
                <div class="finance-title-left">
                    <i class="el-icon-arrow-left finance-i-left" @click="openrelativeleft()"></i>
                </div>
                <div class="finance-title-text">
                    <h2>请登记你的亲属_</h2>
                </div>
                <div class="finance-title-close">
                    <i class="el-icon-close finance-i-close" @click="relativeClose()"></i>
                </div>
            </div>
            <div class="item">
                <div class="item-text">
                    <p>亲属名称:</p>
                </div>
                <div class="item-input">
                    <el-input style="width: 250px;" v-model="relativeData.relativeName" placeholder="请输入你的亲属名称"></el-input>
                </div>
            </div>
            <div class="item">
                <div class="item-text">
                    <p>亲属关系:</p>
                </div>
                <div class="item-input">
                    <el-input style="width: 250px;" v-model="relativeData.typeName" placeholder="请输入你与亲属的关系"></el-input>
                </div>
            </div>
            <div class="item">
                <div class="item-text">
                    <p>联系电话:</p>
                </div>
                <div class="item-input">
                    <el-input style="width: 250px;" v-model="relativeData.mobile" placeholder="请输入亲属的联系电话"></el-input>
                </div>
            </div>
            <div class="item">
                <div class="item-text">
                    <p>地址:</p>
                </div>
                <div class="item-input">
                    <el-cascader
                    v-model="relative_address_value"
                    :options="relative_address"
                    @change="relative_address_change"
                    clearable
                    filterable
                    style="width: 300px;">
                    </el-cascader>
                </div>
            </div>
            <div class="item">
                <div class="item-text">
                    <p>备注:</p>
                </div>
                <div class="item-input">
                    <el-input v-model="relativeData.remark" style="width: 380px;" type="textarea" placeholder="请输入备注内容" class="remark"></el-input>
                </div>
            </div>
            <div class="item">
                <div class="item-input">
                    <div class="item-commit">
                        <el-button type="primary" @click="openfinance()">下 一 步</el-button>
                    </div>
                    <div class="item-close">
                        <el-button @click="relativeClose()">取 消</el-button>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <!-- /亲属登记 -->
      <!-- 缴费 -->
      <div class="fixed" v-if="financeVisiable">
          <div class="finance">
              <div class="finance-title">
                  <div class="finance-title-left">
                      <i class="el-icon-arrow-left finance-i-left" @click="openrelativeleft()"></i>
                  </div>
                  <div class="finance-title-text">
                      <h2>请缴费_</h2>
                  </div>
                  <div class="finance-title-close">
                      <i class="el-icon-close finance-i-close" @click="financeClose()"></i>
                  </div>
              </div>
              <!-- <div class="finance-item">
                  <div class="finance-item-text">
                      <p>缴费人姓名:</p>
                  </div>
                  <div class="finance-item-input">
                      <el-input style="width: 200px;"></el-input>
                  </div>
              </div> -->
              <div class="finance-item">
                  <div class="finance-item-text">
                      <p>住宿费金额:</p>
                  </div>
                  <div class="finance-item-input">
                      <el-input style="width: 200px;" v-model="financeData.stayMoney" :disabled="true"></el-input>
                  </div>
              </div>
              <div class="finance-item">
                  <div class="finance-item-text">
                      <p>付款方式:</p>
                  </div>
                  <div class="finance-item-input">
                      <el-radio-group v-model="financeData.paidType" @input="paidType(financeData.paidType)">
                          <el-radio label="1">微信</el-radio>
                          <el-radio label="2">支付宝</el-radio>
                          <el-radio label="3">银行卡</el-radio>
                          <el-radio label="4">现金</el-radio>
                      </el-radio-group>
                  </div>
              </div>
              <div class="finance-item">
                  <el-collapse v-model="financePayment" accordion>
                      <el-collapse-item :title="PaymentTitle" name="1">
                          <!-- 根据条件展示不同内容 -->
                          <div v-if="PaymentTitle === '微信支付'">
                              <img src="./image/微信支付.jpg" alt="error" class="paymentPic">
                          </div>
                          <div v-if="PaymentTitle === '支付宝'">
                              <img src="./image/支付宝.jpg" alt="error" class="paymentPic">
                          </div>
                          <div v-if="PaymentTitle === '银行卡'">
                              <el-input style="width: 200px;" placeholder="请输入你的银行卡号"></el-input>
                          </div>
                          <div v-if="PaymentTitle === '现金'">
                              <p style="color: red;">请联系工作人员，19195416491</p>
                          </div>
                      </el-collapse-item>
                  </el-collapse>
              </div>
              <div class="finance-item">
                  <div class="finance-item-text">
                      <p>付款类别:</p>
                  </div>
                  <div class="finance-item-input">
                      <el-select style="width: 200px;" v-model="financeData.feeProjId" :disabled="true">
                          <!-- <el-option :label="住宿" :value="1"></el-option> -->
                      </el-select>
                  </div>
              </div>
              <div class="finance-item">
                  <div class="finance-item-text">
                      <p>操作人:</p>
                  </div>
                  <div class="finance-item-input">
                      <p style="color: red; font-size: 16px;">{{financeData.operator}}</p>
                  </div>
              </div>
              <div class="finance-item">
                  <div class="finance-item-text">
                      <p>备注:</p>
                  </div>
                  <div class="finance-item-input">
                      <el-input v-model="financeData.remark" style="width: 380px;" type="textarea" placeholder="请输入备注内容" class="remark"></el-input>
                  </div>
              </div>
              <div class="finance-item">
                  <div class="item-commit">
                    <el-button type="primary" @click="Add()" :loading="financeLoading ? true : false">{{finance_commitText}}</el-button>
                  </div>
                  <div class="item-close">
                    <el-button @click="financeClose()">取 消</el-button>
                  </div>
              </div>
          </div>
      </div>
      <!-- /缴费 -->
      <!-- 头像上传 -->
      <div class="fixed" v-if="UploadVisiable">
        <div class="upload">
              <div class="upload-title">
                  <i class="el-icon-arrow-left upload-i-left" @click="openUploadleft()"></i>
                  <p>上传头像</p>
                  <i class="el-icon-close upload-close" @click="UploadClose()"></i>
              </div>
              <div class="upload-item">
                <div class="upload-text">
                    <p>请上传你的头像:</p>
                </div>
                <div class="upload-input" v-if="upload_flag == true">
                    <el-upload
                        class="upload-demo"
                        action="http://localhost:8088/systeam/open-personinfo/Upload-personinfo?cmd=upload"
                        :on-preview="handlePreview"
                        :on-remove="handleRemove"
                        :before-remove="beforeRemove"
                        multiple
                        :limit="3"
                        :on-exceed="handleExceed"
                        name="fileList"
                        :file-list="fileList">
                        <el-button size="small" type="primary">点击上传</el-button>
                    </el-upload>
                </div>
                <div class="upload-input" v-if="upload_flag == false">
                    <el-upload
                        class="upload-demo"
                        action="http://localhost:8088/systeam/open-personinfo/Upload-personinfo?cmd=update-face"
                        :on-preview="handlePreview"
                        :on-remove="handleRemove"
                        :before-remove="beforeRemove"
                        multiple
                        :limit="3"
                        :on-exceed="handleExceed"
                        name="fileList"
                        :file-list="fileList">
                        <el-button size="small" type="primary">点击上传</el-button>
                    </el-upload>
                </div>
              </div>
              <div class="upload-item">
                <div class="demo-image__preview">
                        <el-image 
                            style="width: 100px; height: 100px"
                            :src="Api+uploadFaceurl">
                        </el-image>
                </div>
              </div>
              <div class="upload-item">
                  <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
              </div>
              <div class="upload-item">
                      <div class="item-commit">
                        <el-button type="primary" @click="UploadCommit()">确 定</el-button>
                      </div>
                      <div class="item-close">
                        <el-button @click="UploadClose()">取 消</el-button>
                      </div>
              </div>
        </div>
      </div>
      <!-- /头像上传 -->
      <!-- 外出登记 -->
      <div class="fixed" v-if="outRecordVisiable">
          <div class="outRecord">
              <div class="AddOrUpd-title">
                  <h4 style="width: auto; display: flex; margin: 10px; justify-content: center;">外出登记</h4>
                  <i class="el-icon-close outrecord-i-close" @click="outRecordClose()"></i>
              </div>
          <!-- <div class="coutent"> -->
              <!-- <div class="nice-is-day"> -->
                  <!-- <div class="nice-is-day-time"> -->
                      <!-- <p></p> -->
                  <!-- </div> -->
                  <!-- <div class="nice-is-day-text"> -->
                      <p class="helloName">{{IntheTime}}，{{Greetings}}</p>
                  <!-- </div> -->
              <!-- </div> -->
              <div class="item-section">
                  <div class="tiem-section-text">
                      <span>外出人姓名:</span>
                  </div>
                  <div class="tiem-section-input">
                      <input type="text" v-model="OutRecordData.personName" placeholder="请填写要外出的人的名字">
                  </div>
              </div>
              <div class="item-section">
                  <div class="tiem-section-text">
                      <span>登记人:</span>
                  </div>
                  <div class="tiem-section-input">
                      <input type="text" v-model="OutRecordData.userName" placeholder="请填写登记人的姓名">
                  </div>
              </div>
              <div class="item-section" style="display: flex; flex: 0.3">
                  <div class="tiem-section-text">
                      <span>状态:</span>
                  </div>
                  <div class="tiem-section-input">
                      <el-radio label="外出" v-model="OutRecordData.state"></el-radio>
                  </div>
              </div>
              <div class="item-section">
                  <div class="tiem-section-text">
                      <span>时间:</span>
                  </div>
                  <div class="tiem-section-input">
                      <el-date-picker v-model="OutRecordData.inTime" type="datetime" placeholder="外出时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 200px;">
                      </el-date-picker>
                      <span class="signTime">登记时间:</span>
                      <el-date-picker v-model="OutRecordData.signTime" type="datetime" :disabled="true" placeholder="登记时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 200px;">
                      </el-date-picker>
                  </div>
              </div>
              <div class="item-section">
                  <div class="tiem-section-text">
                      <span>陪同人员:</span>
                  </div>
                  <div class="tiem-section-input">
                      <input type="text" v-model="OutRecordData.visitor" placeholder="请输入陪同人员的姓名，可不填写">
                  </div>
              </div>
              <div class="item-section">
                  <div class="tiem-section-text">
                      <span>联系电话:</span>
                  </div>
                  <div class="tiem-section-input">
                      <input type="text" v-model="OutRecordData.mobile" placeholder="请输入你的联系电话">
                  </div>
              </div>
              <div class="item-section">
                  <div class="tiem-section-text">
                      <span>外出原因:</span>
                  </div>
                  <div class="tiem-section-input">
                      <el-input type="textarea" :rows="2" :autosize="false" placeholder="请填写你的外出原因" v-model="OutRecordData.remark" class="custom-textarea"></el-input>
                  </div>
              </div>
             <div class="upload-item">
                      <div class="item-commit">
                        <el-button type="primary" @click="outRecordCommit()">确 定</el-button>
                      </div>
                      <div class="item-close">
                        <el-button @click="outRecordClose()">取 消</el-button>
                      </div>
              </div>
          <!-- </div> -->
          </div>
      </div>
      <!-- /外出登记 -->
      <!-- 物品异常申报 -->
      <div class="fixed" v-if="item_ExceptsVisiable">
          <div class="item_Excepts">
              <div class="AddOrUpd-title">
                  <h4 style="width: auto; display: flex; margin: 10px; justify-content: center;">物品异常申报</h4>
                  <i class="el-icon-close Excepts-i-close" @click="item_Excepts_close()"></i>
              </div>
          <!-- <div class="coutent"> -->
              <!-- <div class="nice-is-day"> -->
                  <!-- <div class="nice-is-day-time"> -->
                      <!-- <p></p> -->
                  <!-- </div> -->
                  <!-- <div class="nice-is-day-text"> -->
                      <p class="helloName">{{IntheTime}}，{{Greetings}}</p>
                  <!-- </div> -->
              <!-- </div> -->
              <div class="item-section">
                  <div class="tiem-section-text">
                      <span>申报人姓名:</span>
                  </div>
                  <div class="tiem-section-input">
                      <input type="text" v-model="item_ExceptsData.realName" placeholder="请填写申报异常人的名字">
                  </div>
              </div>
              <div class="item-section">
                  <div class="tiem-section-text">
                      <span>异常物品:</span>
                  </div>
                  <div class="tiem-section-input">
                      {{item_ExceptsData.excepts_name}}
                  </div>
              </div>
              <div class="item-section">
                  <div class="tiem-section-text">
                      <span>时间:</span>
                  </div>
                  <div class="tiem-section-input">
                      <el-date-picker v-model="item_ExceptsData.excepts_Time" type="datetime" :disabled="true" placeholder="异常时间"  value-format="yyyy-MM-dd HH:mm:ss" style="width: 200px;">
                      </el-date-picker>
                  </div>
              </div>
              <div class="item-section">
                  <div class="tiem-section-text">
                      <span>描述:</span>
                  </div>
                  <div class="tiem-section-input">
                      <el-input type="textarea" :rows="2" :autosize="false" placeholder="请填写异常描述" v-model="item_ExceptsData.excepts_info" class="custom-textarea"></el-input>
                  </div>
              </div>
             <div class="upload-item">
                      <div class="item-commit">
                        <el-button type="primary" @click="item_Excepts_commit()">确 定</el-button>
                      </div>
                      <div class="item-close">
                        <el-button @click="item_Excepts_close()">取 消</el-button>
                      </div>
              </div>
          <!-- </div> -->
          </div>
      </div>
      <!-- /物品异常申报 -->
      <!-- 物品审核详情 -->
      <div class="fixed" v-if="item_des_ExceptsVisiable">
        <div class="item_des_Excepts">
                <div class="item_des_Excepts_title">
                  <div class="finance-title-left">
                      <!-- <i class="el-icon-arrow-left finance-i-left" @click="openrelativeleft()"></i> -->
                  </div>
                  <div class="finance-title-text">
                      <h2>物品审核详情_</h2>
                  </div>
                  <div class="finance-title-close">
                      <i class="el-icon-close item-des-Excepts-i-close" @click="item_des_Close()"></i>
                  </div>
                </div>
                <div class="item_des_Excepts_title">
                  <p class="helloName">{{IntheTime}}，{{Greetings}}</p>
                </div>
                <div class="item_des_Excepts-operates">
                    <input type="button" value="接收" class="item_des_Excepts-operates-reception" @click="item_des_Excepts_get()">
                    <input type="button" value="审核" class="item_des_Excepts-operates-check" @click="item_des_Excepts_check()">
                    <input type="button" value="作废" class="item_des_Excepts-operates-cancellation" @click="item_des_Excepts_cancellation()">
                    <input type="button" value="删除" class="item_des_Excepts-operates-delate" @click="item_des_Excepts_batch_dalete()">
                </div>
                <div class="item_des_Excepts-item">
                    <el-table :data="item_ExceptsDatas" border style="width: 100%" @selection-change="selectionData2">
                        <el-table-column type="selection" width="50" fixed="left"></el-table-column>
                        <el-table-column prop="itemExceptsId" label="ID" width="70"></el-table-column>
                        <el-table-column prop="personId" label="用户id" width="70"></el-table-column>
                        <el-table-column prop="realName" label="用户姓名" width="120"> </el-table-column>
                        <el-table-column prop="excepts_name" label="异常物品名称" width="120"> </el-table-column>
                        <el-table-column prop="excepts_Time" label="申报时间" width="120"> </el-table-column>
                        <el-table-column prop="excepts_state" label="异常状态" width="120">
                            <template slot-scope="scope">
                                <div v-if="scope.row.excepts_state == 0">
                                    <p style="color: red;">待审核</p>
                                </div>
                                <div v-if="scope.row.excepts_state == 1">
                                    <p style="color: #8f9f1b;">审核中</p>
                                </div>
                                <div v-if="scope.row.excepts_state == 2">
                                    <p style="color: rgb(32, 219, 76);">已审核</p>
                                </div>
                                <div v-if="scope.row.excepts_state == 3">
                                    <p style="color: red;">损坏，待更换床位</p>
                                </div>
                                <div v-if="scope.row.excepts_state == 4">
                                    维修中
                                </div>
                                <div v-if="scope.row.excepts_state == 5">
                                    作废
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="check_time" label="审核时间" width="120"> </el-table-column>
                        <el-table-column prop="excepts_info" label="物品异常描述" width="120"> </el-table-column>
                        <!-- <el-table-column
                            fixed="right"
                            label="操作"
                            width="200">
                            <template slot-scope="scope">
                                <el-button @click="handleClick(scope.row)" type="text" size="small"><p style="font-size: 15px;">审核</p></el-button>
                                <el-button type="text" size="small"><p style="font-size: 15px;">修改</p></el-button>
                            </template>
                        </el-table-column> -->
                    </el-table>
                    <div class="block">
                        <el-pagination
                        @size-change="handleSizeChange2"
                        @current-change="handleCurrentChange2"
                        :current-page="pager2.current"
                        :page-sizes="[5, 10, 15, 20]"
                        :page-size="pager2.size"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="pager2.total">
                        </el-pagination>
                    </div>
                </div>
                <div class="finance-item">
                  <div class="item-commit">
                    <el-button type="primary" @click="Add()">保存</el-button>
                  </div>
                  <div class="item-close">
                    <el-button @click="financeClose()">取 消</el-button>
                  </div>
              </div>
        </div>
      </div>
      <!-- /物品审核详情 -->
      <!-- 分页器 -->
      <div class="block">
        <el-pagination
          class="pager"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pager.Current"
          :page-sizes="[5, 10, 20, 30]"
          :page-size="pager.size"
          layout="total, sizes, prev, pager, next, jumper"
          :total="pager.total">
        </el-pagination>
      </div>
      <!-- /分页器 -->
  </div>
</template>
<script>
import axios from 'axios';
import {add,Update,selectPage,getId,list,zd,del,get_item_excepts,item_excepts_get,item_excepts_deleteBatch,item_Excepts_cancellation,to_update_face} from '../../api/老人资料/personinfo';
import {pay_the_fees_finance} from '../../api/费用/finance';
import {Add} from '../../api/外出登记/outRecord'
import {getDate} from '../../utils/getDate';
import relative_address_data from './relative_address.json'
import { Table } from 'element-ui';

  export default{
  name:"personinfo_",
  data(){
      return{
          Api: process.env.VUE_APP_BASE_API, //后台接口地址
          // querySearch:[],     //客户名称自动弹窗
          // querySearch2:[],    //客户访问事由地址自动弹窗
          // 分页参数
          ids: [],
          ids2: [],
          pager:{
              like: '',
              flag: 1,
              size: 5,      //每页多少条数据
              Current:1,    //默认第一页
              total:0,     //总页数
          },
          pager2:{
            current: 1,
            size: 5,
            total: 0
          },
          // 列表数据
          personinfo: [],
          houseData: [],
          bedData: [],
          communityData: [],
          Visiable:false,//新增修改弹窗
          UploadVisiable:false,// 文件上传弹窗
          financeVisiable: false, // 缴费弹窗
          outRecordVisiable: false, // 外出登记弹窗
          relativeVisiable: false, // 亲属登记弹窗
          item_ExceptsVisiable: false, // 物品异常弹窗
          item_des_ExceptsVisiable: false,
          // 新增修改参数
          AddOrUpdData: {
              personType:'按日收费', 
              state:'',
              personId:'',
              communityId:"",
              houseId:"",
              bedId:"",
              realName:'',
              sex:'男',  
              cardNo:'',
              age:'',
              mobile:'',
              chairman:'',
              faceUrl:'',
              inTime:'',
              expireDate:'',
              creater:'',
              remark:'',
          },
          // 文件长传
          fileList:[],
          upload_flag: true,
          uploadFaceurl: '',
          // 控制新增or修改弹窗input组件显示
          flag: false,
          // 初始化 养老院，楼房，床位数据 下拉框
          selectedBedId: [],
          selectedHouse:[],
          selectedCommunity:[],
          // 费用参数
          financeData:{
              personId: '',
              stayMoney: 60.9,
              paidType: '1',
              feeProjId: '住宿',
              operator: '',
              remark: '',
              paidDate: '',
              expireDate: '',
              operTime: '',
              modeofpayment: '',

          },
          finance_commitText: '确认支付',
          // 外出登记参数
          OutRecordData:{
              manualRecordId: '',
              personName: '',
              userName: '',
              state: '外出',
              state2: '回来',
              inTime: '',
              outTime: '',
              signTime: '',
              visitor: '',
              mobile: '',
              remark: '',
          },
        //   亲属登记参数
        relativeData:{
            personId: '',
            relativeName: '',
            typeName: '',
            mobile: '',
            addr: '',
            remark: '',
        },
        relative_address_value: [],
        relative_address: relative_address_data,

        // 物品异常参数
        item_ExceptsData:{
            realName: '',
            itemExceptsId: '',
            excepts_typeId: 1,
            personId: '',
            excepts_name: '床',
            excepts_state: 0,
            excepts_Time: '',
            excepts_info: ''
        },
        item_ExceptsDatas: [],

          // 确认支付 加载
          financeLoading: false,
          financePayment: '1',
          paymentPic: './image/微信支付.jpg',
          PaymentTitle: '微信支付',

          operatTabs: 'select-normal',
          operatTabsuiils: '',
          IntheTime: '',
          Greetings: '',
          Slogan: [
              "在意未来的离别，而舍弃当时的幸福，也许是件浪费的事呢。 --Re:LieF 献给亲爱的你",
              "趁着年轻，跌倒了还能爬起来，多吸取教训，学会重新站起来的方法也是很重要的。 --Re:LieF 献给亲爱的你",
              "有些事情，就是因为失败过才做得到。 --Re:LieF 献给亲爱的你",
              "顾虑着将来的离别 而错过眼前本可以拥有的幸福 或许才更令人扼腕。 --Re:LieF 献给亲爱的你",
              "今天的心情如何？",
              "祝你有一个开心的一天！",
              "为美好的世界献上祝福！",
              "花开富贵",
              "让我们一起迎接快乐的明天,我们就是为此才有翅膀!  --苍之彼方的四重奏",
              "无论怎样的瞬间  都会有新的开始在歌唱",
              "想要成为无论多么悲伤的时候，也能够漂亮微笑的人吧。 --文学少女",
              "长夜伴浪破晓梦，梦晓破浪伴夜长。 --樱之诗",
              "世界如此残忍，我们依然要生活在这里。",
              "——夜晚的向日葵，存在的理由又是什么呢？ ——命中注定要朝向阳光生长，那夜晚的向日葵们，岂不是很辛苦？ ——哈哈，总能忍过去。没有太阳，有一点点星光，一点点希望，活着，就足够了吧。 ——如初春雪，暮春樱，夏晚荷，秋寒叶，天降物哀，执拗、纯粹而绝美。 ——美好的每一天。",
              "由岐：可是啊，不是说向日葵会一直朝太阳的方向盛开吗？ 朝夏天的太阳公公盛开，就像光明的象征一样······ 皆守：向日葵并没有朝太阳盛开哦······ 由岐：哎？是这样吗？ 皆守：噢······向日葵追寻太阳，是在花开之前······ 一旦开花了，就再也不会追着太阳了 由岐：这样啊",
              "与其像是等待希望一般生存着 不如在此刻竭尽全力",
              "如果是为了自己的幸福，就算是毁灭这个世界我也愿意。 --不死者之王",
              "当再一次面临着恐惧，困难 的选择时，就对着天空大声的喊出 再做一次尝试吧！ 毕竟我们就是为此而来的。--Re:LieF 献给亲爱的你",
              "幸福 离别 爱情 还有友情 都是美梦中的滑稽儿戏 全部都可以用金钱置换 可能明天就会死去。可能一切都会毫无意义。在早晨 夜晚 春天 秋天 不变的是总有人在某处死去。无论是梦想明天还是任何东西都不需要。只要你能活着就好。没错。原来我、是想唱出这样的曲子啊。--被生命所厌恶",
              "成为大人之后就舍弃掉的梦想它，何时我还能再拾起吗 不想失去的东西还满满有很多呢 所以说 我什么时候 都会一直守护下去​  --直到我舍弃梦想成为大人",
              "你那最初的话语，我无法用语言传达 所以 只能这样一直唱着，渐渐地 日复一日 年复一年，世界也黯然失色只要你给予的光芒没有褪去,无论何时 我都会一直歌唱着 --最初的声音",
              "天空的颜色 风的气味 大海的深沉 我的歌声 属于你的 那最初的声音 无论在世界的哪个角落 我都会歌唱 唱出那属於每个人的 最初的声音 --最初的声音"
          ],
          get_personinfo_Id: "http://localhost:8088/systeam/open-personinfo/getId",
          excepts_info: [],
          excepts_info_flag: false,
      };
  },
  methods:{
    // 条件.分页.查询列表
    //asdasd
    init(flag){
      //alert(flag)
      this.excepts_info = [];
      if(flag == 1){
          this.pager.flag = 1;
      }else if(flag == 2){
          this.pager.flag = 2;
      }else{
          this.pager.flag = 3;
      }
      selectPage(this.pager).then(res =>{
          if(res.code == 300){
              this.$message({
                  showClose: true,
                  message: '好像没有数据了（悲',
                  type: 'warning'
              })
          }
          if(res.code == 200){
            console.log(res)
            this.personinfo = res.personinfoList;
            this.pager.total = res.count;
            for (let i = 0; i < res.item_exceptsList.length; i++) {
                let excepts_state = res.item_exceptsList[i];
                this.excepts_info.push(excepts_state);
            }
          }
      }).catch(err =>{
          this.$message({
              showClose: true,
              message: 'error'+err,
              type: 'error'
          })
      })
    },
    // 新增or修改
    toAddOrUpdate(id) {
      this.Visiable = true;

      if(id == 0){
          this.flag = false;
          // 初始化数据
          this.AddOrUpdData.inTime = getDate();
          let url = "http://localhost:8088/systeam/open-personinfo/toAdd";
          axios({
            url: url,
            method: 'post',
            params: {

            }
          }).then(res =>{
            if(this.selectedBedId.length !== 0 && this.selectedBedId != null){
                  this.selectedBedId = [];
              }
              if(this.selectedHouse.length !== 0 && this.selectedHouse != null){
                  this.selectedHouse = [];
              }
              if(this.selectedCommunity.length !== 0 && this.selectedCommunity != null){
                  this.selectedCommunity = [];
              }
              for(let i = 0; i < res.data.bed.length; i++) {
                  let bed = res.data.bed[i];
                  if (bed.state === "1") {
                    bed.state = "空闲";
                  } 
                  if (bed.state === "2") {
                    bed.state = "使用中";
                  } 
                  if (bed.state === "3") {
                    bed.state = "预定";
                  } 
                  if (bed.state === "4") {
                    bed.state = "维修中";
                  } 
                  this.selectedBedId.push(bed);
              }
              for(let i = 0; i < res.data.house.length; i++){
                  let house = res.data.house[i];
                  this.selectedHouse.push(house);
              }
              for(let i = 0; i < res.data.Community.length; i++){
                  let community = res.data.Community[i];
                  this.selectedCommunity.push(community);
              }
              this.AddOrUpdData.personType = "按日收费";
              this.AddOrUpdData.bedId = this.selectedBedId[0].bedID;
              this.AddOrUpdData.houseId = this.selectedHouse[0].houseId;
              this.AddOrUpdData.communityId = this.selectedCommunity[0].communityid;
              this.AddOrUpdData.creater = res.data.operator[0].userName;
              this.financeData.operator = res.data.operator[0].userName;

              console.log(res.data);
              
          }).catch(err =>{
              this.$message({
                  showClose: true,
                  message: 'Error'+err,
                  type: 'error'
              })
          })
      }else{
          this.flag = true;
          // alert(id)
          const dadas = {
              "id": id,
              "cmd": "toUpdate"
          }
          getId(dadas).then(res =>{
            console.log(res.personifyList);
            this.AddOrUpdData = res.personifyList[0];
            if(this.selectedBedId.length !== 0 && this.selectedBedId != null){
                  this.selectedBedId = [];
              }
              if(this.selectedHouse.length !== 0 && this.selectedHouse != null){
                  this.selectedHouse = [];
              }
              if(this.selectedCommunity.length !== 0 && this.selectedCommunity != null){
                  this.selectedCommunity = [];
              }
              if(this.AddOrUpdData.personType == "1"){
                  this.AddOrUpdData.personType = "按日收费";
              }
              if(this.AddOrUpdData.personType == "2"){
                  this.AddOrUpdData.personType = "按月收费";
              }
              if(this.AddOrUpdData.personType == "3"){
                  this.AddOrUpdData.personType = "按年收费";
              }
              if(this.AddOrUpdData.personType == "4"){
                  this.AddOrUpdData.personType = "其它方式";
              }
              for(let i = 0; i < res.bed.length; i++) {
                  let bed = res.bed[i];
                  if (bed.state === "1") {
                    bed.state = "空闲";
                  } 
                  if (bed.state === "2") {
                    bed.state = "使用中";
                  } 
                  if (bed.state === "3") {
                    bed.state = "预定";
                  } 
                  if (bed.state === "4") {
                    bed.state = "维修中";
                  } 
                  this.selectedBedId.push(bed);
              }
              for(let i = 0; i < res.house.length; i++){
                  let house = res.house[i];
                  this.selectedHouse.push(house);
              }
              for(let i = 0; i < res.Community.length; i++){
                  let community = res.Community[i];
                  this.selectedCommunity.push(community);
              }
              this.AddOrUpdData.bedId = this.selectedBedId[0].bedID;
              this.AddOrUpdData.houseId = this.selectedHouse[0].houseId;
              this.AddOrUpdData.communityId = this.selectedCommunity[0].communityid;
          })
      }
    },
    // 新增
    Add(){
        let modeofpayment = this.AddOrUpdData.personType;

        if(modeofpayment == "按日收费"){
            this.AddOrUpdData.personType = 1;
        }
        if(modeofpayment == "按月收费"){
            this.AddOrUpdData.personType = 2;
        }
        if(modeofpayment == "按年收费"){
            this.AddOrUpdData.personType = 3;
        }
        if(modeofpayment == "其它方式"){
            this.AddOrUpdData.personType = 4;
        }

        if(this.financeData.paidType == "微信"){
              this.financeData.paidType = 1;
        }
        if(this.financeData.paidType == "支付宝"){
              this.financeData.paidType = 2;
        }
        if(this.financeData.paidType == "银行卡"){
              this.fileList.paidType = 3;
        }
        if(this.financeData.paidType == "现金"){
              this.financeData.paidType = 4;
        }

        // let sex = this.AddOrUpdData.sex == "男" ? 1 : 2;
        const dadas = {
            // 老人资料参数
            "realName": this.AddOrUpdData.realName,
            "sex": this.AddOrUpdData.sex,
            "age": this.AddOrUpdData.age,
            "chairman": this.AddOrUpdData.chairman,
            "mobile": this.AddOrUpdData.mobile,
            "cardNo": this.AddOrUpdData.cardNo,
            "inTime": this.AddOrUpdData.inTime,
            "creater": this.AddOrUpdData.creater,
            "communityId": this.AddOrUpdData.communityId,
            "houseId": this.AddOrUpdData.houseId,
            "bedId": this.AddOrUpdData.bedId,
            "personType": this.AddOrUpdData.personType,
            "state": 1,
            "remark": this.AddOrUpdData.remark,
            "financeList": {
                  // 费用参数
                  "stayMoney": this.financeData.stayMoney,
                  "paidType": this.financeData.paidType,
                  "feeProjId": 1,
                  "operator": this.financeData.operator,
                  "finaceremark": this.financeData.remark,
                  "modeofpayment": modeofpayment,
                  "paidMonth": getDate(),
                  "operTime": getDate(),
                  "paidDate": getDate(),
            }
           /*  "relativeList": {
                  // 亲属登记参数
                  "relativeName": this.relativeData.relativeName,
                  "typeName": this.relativeData.typeName,
                  "mobile": this.relativeData.mobile,
                  "addr": this.relative_address_value,
                  "remark": this.relativeData.remark
            } */
        }
        add(dadas).then(res =>{
            console.log(dadas);
            this.financeLoading = true;
            this.finance_commitText = "正在支付中，请稍等...";
            setTimeout(() =>{
                if(res.code == 200){
                    this.$message({
                        showClose: true,
                        message: 'code 200',
                        type: 'success'
                    })
                    this.financeLoading = false;
                    this.finance_commitText = "支付成功！";
                    this.init(this.pager.flag);
                    this.Visiable = false;
                    this.financeVisiable = false;
                    this.UploadVisiable = true;
                    this.finance_commitText = "确认支付";
                }else{
                    this.$message({
                        showClose: true,
                        message: 'error',
                        type: 'error'
                    })
                }
            },1000)
        }).catch(err =>{
            this.$message({
                showClose: true,
                message: '新增失败',
                type: 'error'
            })
        })
    },
    // 修改
    commitUpdate(){
        if(this.AddOrUpdData.personType == "按日收费"){
            this.AddOrUpdData.personType = 1;
        }
        if(this.AddOrUpdData.personType == "按月收费"){
            this.AddOrUpdData.personType = 2;
        }
        if(this.AddOrUpdData.personType == "按年收费"){
            this.AddOrUpdData.personType = 3;
        }
        if(this.AddOrUpdData.personType == "其它方式"){
            this.AddOrUpdData.personType = 4;
        }
        // let sex = this.AddOrUpdData.sex == "男" ? 1 : 2;
        const dadas = {
            "personId": this.AddOrUpdData.personId,
            "realName": this.AddOrUpdData.realName,
            "sex": this.AddOrUpdData.sex,
            "age": this.AddOrUpdData.age,
            "chairman": this.AddOrUpdData.chairman,
            "mobile": this.AddOrUpdData.mobile,
            "cardNo": this.AddOrUpdData.cardNo,
            "inTime": this.AddOrUpdData.inTime,
            "state": this.AddOrUpdData,
            "expireDate": this.AddOrUpdData.expireDate,
            "creater": this.AddOrUpdData.creater,
            "communityId": this.AddOrUpdData.communityId,
            "houseId": this.AddOrUpdData.houseId,
            "bedId": this.AddOrUpdData.bedId,
            "personType": this.AddOrUpdData.personType,
            "remark": this.AddOrUpdData.remark,
        }
        console.log(this.AddOrUpdData.state);
        Update(dadas).then(res =>{
            if(res.code == 200){
                this.$message({
                    showClose: true,
                    message: '修改成功',
                    type: 'success'
                })
                this.init(this.pager.flag)
                this.Visiable = false;
                //this.UploadVisiable = true;
            }
        }).catch(err =>{
            this.$message({
                showClose: true,
                message: 'Error' + err,
                type: 'error'
            })
        })
    },
    // 文件上传
    UploadCommit(){
        axios({
            url: "http://localhost:8088/systeam/open-personinfo//Upload-personinfo",
            method: "post",
            params:{

            }
        }).then(res =>{
            if(res.data.code == 200){
                this.$message({
                  showClose: true,
                  message: '上传成功',
                  type: 'success'
                })
                this.init(this.pager.flag);
                this.UploadVisiable = false;
            }
        })
    },
    //删除
    dele(id) {
    console.log(id);
        this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          del(id).then(res => {
            var params = this.pager
            var curPageSize = this.personinfo.length
            params.Current = curPageSize == 1 ? params.Current - 1 : params.Current
            if(res.code==200){
              this.$message({
            type: 'success',
            message: '删除成功!'
          });
              this.init(this.pager.flag)
            } 
          })
          .catch(error => {
            this.$message.error('你没有删除数据的权限,请与系统管理员联系');
      });
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });          
        });
    },
    // 外出登记
    outRecordCommit(){
      // 表单验证
          let personName = this.OutRecordData.personName;
          let userName = this.OutRecordData.userName;
          let inTime = this.OutRecordData.inTime;
          let mobile = this.OutRecordData.mobile;
          // 判断外出人姓名是否为空
          if(personName == "" || personName == null){
              this.$message({
                  showClose: true,
                  message: '外出人姓名不能为空哦！',
                  type: 'error'
              })
              return;
          }
          // 判断外出人姓名是否为数字
          if(/^\d+$/.test(personName)){
              this.$message({
                  showClose: true,
                  message: '外出人姓名不能为数字哦！',
                  type: 'error'
              })
              return;
          }
          // 判断外出人姓名长度
          console.log(personName.length);
          if(personName.length > 10){
              this.$message({
                  showClose: true,
                  message: '你的名字真的有这么长吗！',
                  type: 'error'
              })
              return;
          }
          // 判断外出人名字是否为一个字
          if(personName.length == 1){
              this.$message({
                  showClose: true,
                  message: '你的名字真的只有一个字吗！',
                  type: 'error'
              })
              return;
          }
          // 判断登记人是否为空
          if(userName == "" || userName == null){
              this.$message({
                  showClose: true,
                  message: '登记人姓名不能为空哦！',
                  type: 'error'
              })
              return;
          }
          // 判断登记人是否为数字
          if(/^\d+$/.test(userName)){
              this.$message({
                  showClose: true,
                  message: '外出人姓名不能为数字哦！',
                  type: 'error'
              })
              return;
          }
          // 判断登记人的名字长度
          if(userName.length > 10){
              this.$message({
                  showClose: true,
                  message: '你的名字真的有这么长吗！',
                  type: 'error'
              })
              return;
          }
          // 判断登记人的名字是不是为一个字
          if(userName.length == 1){
              this.$message({
                  showClose: true,
                  message: '你的名字真的只有一个字吗！',
                  type: 'error'
              })
              return;
          }
          // 判断外出时间是否为空
          if(inTime == "" || inTime == null || inTime.length == 0){
              this.$message({
                  showClose: true,
                  message: '你的外出时间还没有填写哦！',
                  type: 'error'
              })
              return;
          }
          // 判断联系电话是否为空
          if(mobile == "" || mobile == null || mobile.length == 0){
              this.$message({
                  showClose: true,
                  message: '你的联系电话还没有填写哦！',
                  type: 'error'
              })
              return;
          }
          // 判断联系电话是否为字符串
          if(!/^\d+$/.test(mobile)){
              this.$message({
                  showClose: true,
                  message: '联系电话不能是文字哦！',
                  type: 'error'
              })
              return;
          }
          // 判断联系电话的长度是否正确
          if(mobile.length == 11 || mobile.length == 10){
              console.log(true);
          }else{
              this.$message({
                  showClose: true,
                  message: '请输入11位数字的或者10位数的联系电话！',
                  type: 'error'
              })
              return;
          }
          // 以上是表单验证

              if(this.OutRecordData.state == "外出"){
                  this.OutRecordData.state = 1;
              }
              if(this.OutRecordData.visitor == ""){
                  this.OutRecordData.visitor = "无";
              }
              if(this.OutRecordData.remark == ""){
                  this.OutRecordData.remark = "未填写";
              }
              let formData = {
                  "personName": this.OutRecordData.personName,
                  "state": this.OutRecordData.state,
                  "visitor": this.OutRecordData.visitor,
                  "mobile": this.OutRecordData.mobile,
                  "inTime": this.OutRecordData.inTime,
                  "remark": this.OutRecordData.remark,
                  "userName": this.OutRecordData.userName,
                  "signTime": this.OutRecordData.signTime
              };
              Add(formData).then(res =>{
                  console.log(res);
                  if(res.code == 300){
                      this.$message({
                          showClose: true,
                          message: '该人物已经是外出状态，请不要重复的填写，如有写错的地方，请点击修改！',
                          type: 'error'
                      })
                      this.OutRecordData.state = "外出";
                  }
                  if(res.code == 200){
                      this.$message({
                          showClose: true,
                          message: '新增成功！',
                          type: 'success'
                      })
                      this.outRecordVisiable = false;
                      this.init(this.pager.flag);
                  }
                  if(res.code == 201){
                      this.$message({
                          showClose: true,
                          message: '我们的养老院好像没有这个人物呢？换一个试试吧！',
                          type: 'error'
                      })
                      this.OutRecordData.state = "外出";
                  }
                  if(res.code == 202){
                      this.$message({
                          showClose: true,
                          message: '新增失败！',
                          type: 'error'
                      })
                  }
              }).catch(error =>{
                  this.$message({
                      showClose: true,
                      message: 'Error'+error,
                      type: 'error'
                  })
              })
    },
    toUpdate_face(id){
        // alert(id)
        const datas = {
            "personId": id
        }
        to_update_face(datas).then(res =>{

        }).catch(err =>{
            this.$message({
                showClose: true,
                message: 'code 500',
                type: 'error'
            })
        })
    },
    // 点击缴费
    pay_the_fees(id){
      // alert(id)
      this.$confirm('本次缴费，将会自动按照原本的缴费方案来支付费用，如需修改方案请去修改原本的方案, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
      }).then(() => {
          const datas = {
              "personId": id,
              "paidMonth": getDate(),
              "paidDate": getDate(),
              "operTime": getDate(),
          }
          pay_the_fees_finance(datas).then(res =>{
              if(res.code == 200){
                  this.$message({
                      showClose: true,
                      message: 'pay the fees finance success',
                      type: 'success'
                  })
                  this.init(this.pager.flag)
              }
          }).catch(err =>{
              this.$message({
                  showClose: true,
                  message: 'Error' + err,
                  type: 'error'
              })
          })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    },
    // 提交物品异常信息
    item_Excepts_commit(){
        console.log(this.item_ExceptsData.personId);
        let url = "http://localhost:8088/systeam/open-personinfo/Add-item_excepts";
        axios({
            url: url,
            method: 'post',
            params:{
                "excepts_typeId": this.item_ExceptsData.excepts_typeId,
                "personId": this.item_ExceptsData.personId,
                "excepts_name": this.item_ExceptsData.excepts_name,
                "excepts_state": this.item_ExceptsData.excepts_state,
                "excepts_Time": this.item_ExceptsData.excepts_Time,
                "excepts_info": this.item_ExceptsData.excepts_info
            }
        }).then(res =>{
            this.$message({
                showClose: true,
                message: '已提交！请等待工作人员进行审核',
                type: 'success'
            })
            this.item_ExceptsVisiable = false;
            this.init(this.pager.flag)
        }).catch(err =>{
            this.$message({
                showClose: true,
                message: 'Error'+err,
                type: 'error'
            })
        })
    },
    handleTabClick(tab,event){
      let name = tab.name;
      if(name == "select-normal"){
          this.init(this.pager.flag = 1);
      }
      if(name == "select-finArrearage"){
          this.init(this.pager.flag =2);
      }
      if(name == "select-leave"){
          this.init(this.pager.flag = 3);
      }
      if(name == "outrecord"){
        
          let flag = this.operateTabs_id_no("to_outrecord");
          if(flag == false){
              return;
          }
          //alert(id)
          let id =  this.ids[0].personId;


          this.outRecordVisiable = true;
          const now = new Date();
          const hour = ('0' + now.getHours()).slice(-2);
          // 判断时间段
          this.IntheTime = getDate();
          // 判断时间段
          if (hour >= 0 && hour < 6) {
              this.IntheTime = '早点休息吧。';
          } else if (hour >= 6 && hour < 10) {
              this.IntheTime = '早上好';
          }else if(hour >=10 && hour <12){
              this.IntheTime = '上午好';
          }else if (hour >= 12 && hour < 18) {
              this.IntheTime = '下午好';
          } else {
              this.IntheTime = '晚上好';
          }
          const randomIndex = Math.floor(Math.random() * this.Slogan.length);
          this.Greetings = this.Slogan[randomIndex];
          this.OutRecordData.signTime = getDate();

          axios({
              url: this.get_personinfo_Id,
              method: 'post',
              params:{
                  'id': id,
                  'cmd': "outRecord"
              }
          }).then(res =>{
              this.OutRecordData.personName = res.data.personifyList[0].realName;
              this.OutRecordData.userName = res.data.operator[0].userName;
              this.OutRecordData.mobile = res.data.personifyList[0].mobile;
              console.log(res.data)
          })

      }
      if(name == "relative"){

          let flag = this.operateTabs_id_no("to_relative");
          if(flag == false){
              return;
          }
          //alert(id)
          let id =  this.ids[0].personId;
      }
      if(name == "declare-error"){

        let flag = this.operateTabs_id_no("to_declare-error");
        if(flag == false){
            return;
        }
        //alert(id)
        let id =  this.ids[0].personId;
        axios({
            url: this.get_personinfo_Id,
            method: 'post',
            params:{
                "id": id,
                "cmd": 'declare-error'
            }
        }).then(res =>{
            this.item_ExceptsData.personId = res.data.personifyList[0].personId
            this.item_ExceptsData.realName = res.data.personifyList[0].realName;
            this.item_ExceptsData.excepts_Time = getDate();
        })
        const now = new Date();
        const hour = ('0' + now.getHours()).slice(-2);
        // 判断时间段
        this.IntheTime = getDate();
        // 判断时间段
        if (hour >= 0 && hour < 6) {
            this.IntheTime = '早点休息吧。';
        } else if (hour >= 6 && hour < 10) {
            this.IntheTime = '早上好';
        }else if(hour >=10 && hour <12){
            this.IntheTime = '上午好';
        }else if (hour >= 12 && hour < 18) {
            this.IntheTime = '下午好';
        } else {
            this.IntheTime = '晚上好';
        }
        const randomIndex = Math.floor(Math.random() * this.Slogan.length);
        this.Greetings = this.Slogan[randomIndex];
        this.item_ExceptsVisiable = true;
          

      }
      if(name == "declare-error-get"){
        this.item_des_Excepts_init();
      }
      console.log(name)
      //console.log(tab,event);
    },
    item_des_Excepts_init(){
        const now = new Date();
        const hour = ('0' + now.getHours()).slice(-2);
        // 判断时间段
        this.IntheTime = getDate();
        // 判断时间段
        if (hour >= 0 && hour < 6) {
            this.IntheTime = '早点休息吧。';
        } else if (hour >= 6 && hour < 10) {
            this.IntheTime = '早上好';
        }else if(hour >=10 && hour <12){
            this.IntheTime = '上午好';
        }else if (hour >= 12 && hour < 18) {
            this.IntheTime = '下午好';
        } else {
            this.IntheTime = '晚上好';
        }
        const randomIndex = Math.floor(Math.random() * this.Slogan.length);
        this.Greetings = this.Slogan[randomIndex];
        get_item_excepts(this.pager2).then(res =>{
            this.item_ExceptsDatas = res.item_exceptsList;
            this.pager2.total = res.count;
        }).catch(err =>{

        })
        console.log("this pager");
        this.item_des_ExceptsVisiable = true;
    },
    item_des_Excepts_get(){
        let flag = this.operateTabs_id_no2("item_des_Excepts_get");
        if(flag == false){
            return;
        }
        let url = "http://localhost:8088/systeam/open-personinfo/update_item_excepts_state1";
        let personId = this.ids2[0].personId;
        let itemExceptsId = this.ids2[0].itemExceptsId;
        axios({
            url: url,
            method: 'post',
            params:{
                "personId": personId,
                "itemExceptsId": itemExceptsId
            }
        }).then(res =>{
            if(res.data.code == 200){
                this.$message({
                    showClose: true,
                    message: 'code 200',
                    type: 'success'
                })
                this.item_des_Excepts_init(this.pager2);
                this.init(this.pager.flag);
                this.ids2 = [];
            }
            if(res.data.code == 201){
                this.$message({
                    showClose: true,
                    message: res.data.msg,
                    type: 'error'
                })
            }
        }).catch(err =>{
            this.$message({
                showClose: true,
                message: 'code 500',
                type: 'error'
            })
        })
    },
    item_des_Excepts_check(){
        let flag = this.operateTabs_id_no2("item_des_Excepts_check");
        if(flag == false){
            return;
        }
        let url = "http://localhost:8088/systeam/open-personinfo/update_item_excepts_state2";
        let personId = this.ids2[0].personId;
        let itemExceptsId = this.ids2[0].itemExceptsId;
        axios({
            url: url,
            method: 'post',
            params:{
                "personId": personId,
                "itemExceptsId": itemExceptsId,
                "check_time": getDate()
            }
        }).then(res =>{
            if(res.data.code == 200){
                this.$message({
                    showClose: true,
                    message: 'code 200',
                    type: 'success'
                })
                this.init(this.pager.flag)
                this.item_des_Excepts_init();
                // this.ids2 = [];
            }
            if(res.data.code == 201){
                this.$message({
                    showClose: true,
                    message: res.data.msg,
                    type: 'error'
                })
            }
        }).catch(err =>{
            this.$message({
                showClose: true,
                message: 'code 500',
                type: 'error'
            })
        })
    },
    item_des_Excepts_cancellation(){
        let id = this.ids2;
        if(id.length == 0){
            this.$message({
                showClose: true,
                message: '请勾选需操作的人物',
                type: 'error'
            })
            return false;
        }

        let personId = "";
        let itemExceptsId = "";

        for(let i = 0; i<this.ids2.length; i++){
            personId += this.ids2[i].personId + ",";
            itemExceptsId += this.ids2[i].itemExceptsId + ",";
        }

        const datas = {
            "personIds": personId,
            "itemExceptsIds": itemExceptsId
        }

        item_Excepts_cancellation(datas).then(res =>{
            if(res.code == 201){
                this.$message({
                    showClose: true,
                    message: res.msg,
                    type: 'error'
                })
            }
            if(res.code == 200){
                this.$message({
                    showClose: true,
                    message: 'code 200',
                    type: 'success'
                })
                this.item_des_Excepts_init(this.pager2);
                this.init(this.pager.flag);
            }
        }).catch(err =>{
            this.$message({
                showClose: true,
                message: 'code 500',
                type: 'error'
            })
        })
    },
    item_des_Excepts_batch_dalete(){
        let idArray = "";
        let id = this.ids2;
        if(id.length == 0){
            this.$message({
                showClose: true,
                message: '请勾选需操作的人物',
                type: 'error'
            })
            return false;
        }
        
        for(let i = 0; i<this.ids2.length; i++){
            idArray += this.ids2[i].itemExceptsId + ",";
        }
        console.log(idArray);
        this.$confirm('删除后数据不可修复, 是否继续?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
        }).then(() => {
            const datas = {
                "idArray": idArray
            }
            item_excepts_deleteBatch(datas).then(res =>{
                if(res.code == 200){
                    this.$message({
                        showClose: true,
                        message: '删除成功',
                        type: 'success'
                    })
                    this.item_des_Excepts_init(this.pager2);
                    this.init(this.pager.flag)
                }
            }).catch(err =>{
                this.$message({
                    showClose: true,
                    message: '删除失败',
                    type: 'error'
                })
            })
        }).catch(() => {
            this.$message({
                type: 'info',
                message: '已取消删除'
            });          
        });

    },
    // 判断用户是否选择的数据，或者多选了数据
    operateTabs_id_no(cmd){
        console.log(cmd);
        let id = this.ids
        if(id.length == 0){
            this.$message({
                showClose: true,
                message: '请勾选需操作的人物',
                type: 'error'
            })
            return false;
        }
        if(id.length >= 2){
            this.$message({
                showClose: true,
                message: '只能勾选一条数据哦！',
                type: 'error'
            })
            return false;
        }
    },
    operateTabs_id_no2(cmd){
        console.log(cmd);
        let id = this.ids2
        if(id.length == 0){
            this.$message({
                showClose: true,
                message: '请勾选需操作的人物',
                type: 'error'
            })
            return false;
        }
        if(id.length >= 2){
            this.$message({
                showClose: true,
                message: '只能勾选一条数据哦！',
                type: 'error'
            })
            return false;
        }
    },
    // 根据选择的支付方案来决定支付金额
    personType(personType){
      console.log(personType)
      if(personType == "按日收费"){
          this.financeData.stayMoney = 60.9;
      }
      if(personType == "按月收费"){
          this.financeData.stayMoney = 1827.3;
      } 
      if(personType == "按年收费"){
          this.financeData.stayMoney = 22228.5;
      }
      if(personType == "其它方式"){
          this.financeData.stayMoney = "未知";
      }
    },
    // 根据选择的支付方案来决定支付方式
    paidType(paidType){
      console.log(paidType)
      if(paidType == "1"){
          this.PaymentTitle = "微信支付"
      }
      if(paidType == "2"){
          this.PaymentTitle = "支付宝"
      }
      if(paidType == "3"){
          this.PaymentTitle = "银行卡"
      }
      if(paidType == "4"){
          this.PaymentTitle = "现金"
      }
    },
    // 关闭新增or修改弹窗
    AddOrUpdateClose() {
      if(this.flag == false){
        this.Visiable = false;
      }else{
        this.AddOrUpdData = [];
        this.Visiable = false;
      }
    },
    // 回到新增弹窗，同时关闭缴费弹窗
    openrelativeleft(){
        this.financeVisiable = false;
        this.Visiable = true;
    },
    // 回到亲属登记窗口，同时关闭缴费弹窗
    openfinanceleft(){
        this.financeVisiable = false;
        this.relativeVisiable = true;
    },
    // 回到缴费弹窗，同时关闭头像上传弹窗
    openUploadleft(){
      this.UploadVisiable = false;
      this.financeVisiable = true;
    },
    // 前往亲属登记弹窗，同时关闭新增弹窗
    openreative(){
        this.Visiable = false;
        this.relativeVisiable = true;
    },
    // 前往缴费弹窗,同时关闭新增弹窗
    openfinance(){
    //   this.relativeVisiable = false;
      this.Visiable = false;
      this.financeVisiable = true;
    },
    // 前往头像上传弹窗，同时关闭缴费弹窗
    openUpload(){
      this.financeVisiable = false;
      this.UploadVisiable = true;
    },
    flagInit(flag){
      flag = this.pager.flag;
      if(flag == 1){
          this.init(1);
      }
      if(flag == 2){
          this.init(2);
      }
      if(flag == 3){
          this.init(3);
      }
    },
    relative_address_change(value){
        // this.relative_address_value = value[0]+value[1]+value[2];
        console.log(value[0]+"/"+value[1]+"/"+value[2]);
    },
    go(name){
      console.log(name);
      this.$router.push({ path: '/7-6', query: { name: name }});
    },
    gos(name){
      this.$router.push({ path: '/6-6', query: { name: name }});
    },
    relativeClose(){
        this.relativeVisiable = false;
    },
    // 关闭缴费弹窗
    financeClose(){
      this.financeVisiable = false;
    },
    // 关闭文件上传弹窗
    UploadClose(){
      this.UploadVisiable = false;
    },
    // 关闭外出登记弹窗
    outRecordClose(){
      this.outRecordVisiable = false;
    },
    // 关闭物品异常
    item_Excepts_close(){
        this.item_ExceptsVisiable = false;
    },
    // 关闭物品异常接收
    item_des_Close(){
        this.item_des_ExceptsVisiable = false
    },
    selectionData(val){
          this.ids = val;
    },
    selectionData2(val){
          this.ids2 = val;
    },
    handlePreview(file) {
    console.log('预览文件', file);
    },
    handleRemove(file, fileList) {
      console.log('移除文件', file, fileList);
    },
    beforeRemove(file, fileList) {
      // 返回false可以阻止文件被移除
      return this.$confirm(`确定移除 ${file.name}？`);
    },
    handleExceed(files, fileList) {
      this.$message.warning(`当前限制选择 ${this.limit} 个文件，已选择 ${files.length + fileList.length} 个文件，超出的文件将不会上传`);
    },
    handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
        this.pager.size = val
        this.init(this.pager.flag); 
    },
    handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
        this.pager.Current = val 
        this.init(this.pager.flag); 
    },
    handleSizeChange2(val) {
        console.log(`每页 ${val} 条`);
        this.pager2.size = val
        this.operatTabsuiils = "declare-error-get";
        this.item_des_Excepts_init(this.pager2);
    },
    handleCurrentChange2(val) {
        console.log(`当前页: ${val}`);
        this.pager2.current = val 
        this.operatTabsuiils = "declare-error-get";
        this.item_des_Excepts_init(this.pager2);
    },
  },
  created() {
      this.init(this.pager.flag)
      let url = "http://localhost:8088/systeam/open-personinfo/UpdateState";
      axios({
          url: url,
          method: 'post',
          params:{

          }
      }).then(res =>{
          if(res.data.row != 0){
              this.$notify({
                  title: '提示',
                  message: '今日需缴费人数'+res.data.row,
                  offset: 100
              });
              console.log("code: 200 Update true")
          }else{
              this.$message({
                  showClose: true,
                  message: 'code 200',
                  type: 'success'
              })
          }
      }).catch(err =>{
          this.$message({
              showClose: true,
              message: 'Error'+err,
              type: 'success'
          })
      })
  },
}
</script>
<style scoped>
.personinfoTable{
  display: flex;
  width: 1400px;
  height: auto;
  margin: auto;
}
.fixed{
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5); 
      z-index: 11;
  }
  .AddOrUpdContent{
      display: flex;
      flex-direction: column;
      /* align-items: center; */
      width: 800px;
      height: 780px;
      background: #ffffff;
      box-shadow: 0 0 3px #000000;
      margin: auto;
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;
      /* box-shadow: #000000 1px 1px 1px 1px; */
      position: absolute;
      margin: auto;
      top: 0;
      bottom: 0;
      right: 0;
      left: 0;
      z-index: 1;
  }
  .item{
    flex: 1;
    display: flex;
    width: 100%;
    justify-content: center;
    align-items: center;
    flex-direction: row;
    flex-wrap: wrap;
  }
  .item-title{
    flex: 0.5;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
  }
  .item-title-h{
    flex: 4;
    display: flex;
    justify-content: flex-start;
    align-items: center;
  }
  .item-title-close{
    flex: 0.2;
    display: flex;
  }
  .el-icon-close{
    display: flex;
    justify-content: flex-end;
    cursor: pointer;
    position: absolute;
    margin-left: 190px;
    margin-top: -20px;
    color: #000000;
  }
  .item-text{
    flex: 0.9;
    display: flex;
    margin: 3px;
    justify-content: flex-end;
  }
  .item-text>p:hover{
    color: rgb(118, 196, 229);
  }
  .item-input{
    flex: 2;
    display: flex;
    justify-content: flex-start;
    align-items: center;

  }
  .item-commit{
    flex: 3;
    display: flex;
    justify-content: flex-end;
  }
  .item-close{
    flex: 1;
    display: flex;
    justify-content: flex-start;
    align-items: flex-end;
  }
  .item-commit>button{
    width: 200px;
    height: 40px;
    border-radius: 0%;
  }
  .item-close>button{
    width: 80px;
    text-align: center;
    justify-content: center;
    line-height: 0px;
    height: 30px;
    border-radius: 0%;
    margin: 10px;
    cursor: pointer;
  }
  .remark{
    overflow: auto;
  }
  .finance{
      display: flex;
      flex-direction: column;
      /* align-items: center; */
      width: 620px;
      height: 640px;
      background: #ffffff;
      box-shadow: 0 0 3px #000000;
      margin: auto;
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;
      /* box-shadow: #000000 1px 1px 1px 1px; */
      position: absolute;
      margin: auto;
      top: 0;
      bottom: 0;
      right: 0;
      left: 0;
      z-index: 1;
      transition: 1s all;
  }
  .finance-title{
      flex: 0.5;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
  }
  .finance-title-left{
      flex: 1;
      display: flex;
      justify-content: flex-start;
      align-items: flex-start;
  }
  .finance-i-left{
      color: #000000;
      cursor: pointer;
      margin-top: -30px;
      margin-left: 5px;
      font-size: 20px;
  }
  .finance-i-left:hover{
      color: #47b5e0;
  }
  .finance-title-text{
      flex: 3;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      text-align: center;
  }
  .finance-item-text>p:hover{
      color: #47b5e0;
  }
  .finance-title-close{
      flex: 1;
      display: flex;
      justify-content: flex-end;
      align-items: flex-start;
  }
  .finance-i-close{
      margin-top: -30px;
      margin-left: 5px;
      color: #000000;
      font-size: 20px;
  }
  .finance-i-close:hover{
      color: red;
  }
  .finance-item{
      flex: 1;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
  }
  .finance-item-text{
      flex: 1;
      display: flex;
      justify-content: flex-end;
      align-items: center;
  }
  .finance-item-input{
      flex: 2;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      margin-left: 5px;
  }
  .upload{
      display: flex;
      flex-direction: column;
      /* align-items: center; */
      width: 400px;
      height: 400px;
      background: #ffffff;
      box-shadow: 0 0 3px #000000;
      margin: auto;
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;
      /* box-shadow: #000000 1px 1px 1px 1px; */
      position: absolute;
      margin: auto;
      top: 0;
      bottom: 0;
      right: 0;
      left: 0;
      z-index: 1;
      transition: 1s all;
  }
  .upload-title{
      display: flex;
      flex: 0.5;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
  }
  .upload-close{
      position: absolute;
      margin-left: 350px;
  }
  .upload-item{
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
  }
  .upload-text{
      flex: 1;
      display: flex;
      justify-content: flex-end;
  }
  .upload-input{
      flex: 2;
      display: flex;
      justify-content: flex-start;
      margin: 5px;
  }
  .face{
      width: 80px;
      height: 80px;
      object-fit: contain;
      color: #ec7a8b;
  }
  .rightOptions{
      display: flex;
      justify-content: center;
      flex-direction: row;
      align-items: center;
  }
  .faceOptions{
      width: auto;
      height: 20px;
      margin: 3px;
      color: #80adbe;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
  }
  .UpdateOptions{
      width: auto;
      height: 30px;
      margin: 3px;
      color: #47b5e0;
      cursor: pointer;
      display: flex;
      align-items: center;
  }
  .delOptions{
      width: auto;
      height: 30px;
      margin: 3px;
      color: #ec7a8b;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
  }
  .paymentPic{
      width: 140px;
      height: 140px;
      object-fit: contain;
      color: #ec7a8b;
  }
  .upload-i-left{
      position: absolute;
      margin-left: -370px;
      margin-top: -20px;
      color: #000000;
      font-size: 20px;
      cursor: pointer;
  }
  .upload-i-left:hover{
      color: #47b5e0;
  }
  .outRecord{
      display: flex;
      flex-direction: column;
      /* align-items: center; */
      width: 800px;
      height: 780px;
      background: #ffffff;
      box-shadow: 0 0 3px #000000;
      margin: auto;
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;
      /* box-shadow: #000000 1px 1px 1px 1px; */
      position: absolute;
      margin: auto;
      top: 0;
      bottom: 0;
      right: 0;
      left: 0;
      z-index: 1;
  }
  .AddOrUpd-title{
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
  }
  .helloName{
    display: flex;
    /* flex: 10; */
    justify-content: flex-start;
    margin: 5px;
    color: #999;
    width: auto;
    flex-wrap: wrap;
    /* height: 40px; */
  }
  .outrecord-i-close{
      display: flex;
      /* flex: 0.1; */
      justify-content: flex-end;
      /* width: 30px;
      height: 30px; */
      cursor: pointer;
      /* background: #999; */
      color: #000000;
      font-size: 20px;
      margin-left: 770px;
  }
  .outrecord-i-close:hover{
      color: red;
  }
  .userId{
      display: flex;
      align-items: flex-end;
      cursor: inherit;
  }
  .item-section{
    flex: 2;
    display: flex;
    flex-direction: row;
    /* align-items: center; */
    justify-content: center;
    margin: 8px;
    transition: 1s all;
    /* border-bottom: 1px #dde5e7 solid; */
  }
  .tiem-section-text{
    flex: 1;
    display: flex;
    justify-content: flex-end;
    /* background: red; */
    align-items: center;
    /* border-bottom: 1px blueviolet solid; */
  }
  .tiem-section-text>span{
    font-size: 16px;
    color: #000000;
  }
  .tiem-section-text>span:hover{
    color: #66b1ff;
    /* border-bottom: 1px #66b1ff solid; */
  }
  .tiem-section-input{
    flex: 2;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    /* background: #222; */
    margin-left: 5px;
    overflow: none;
    /* box-shadow: 0 0 5px #007bff; */
  }
  .tiem-section-input>input{
    width: 200px;
    height: 30px;
    border: none;
    outline: none;
    border-bottom: 2px #ccc solid;
    /* border-radius: 5px; */
    font-size: 12px;
    color: #000000;
    padding-left: 5px;
    margin: 5px;
    transition: 0.5s all;
  }
  .tiem-section-input>input:hover{
     border-color: #4ab3e0;
     box-shadow: 0 0 5px #4ab3e0;
  }
  .tiem-section-input>input:focus{
    width: 300px;
    height: 40px;
    border-color: #007bff;
    box-shadow: 0 0 5px #007bff;
    /* border: 1px #66b1ff solid; */
  }
  .tiem-section-input>input:not(:placeholder-shown){
    top: -10px;
    font-size: 16px;
    color: rgb(0, 0, 0);
  }
  .signTime{
      color: black;
  }
  .custom-textarea .el-textarea__inner {
      overflow-y: auto; /* 显示垂直滚动条 */
      resize: none;
  }
  .nice-is-day{
      flex: 1;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
  }
  .nice-is-day-time{
      flex: 0.5;
      display: flex;
      justify-content: flex-end;
      align-items: center;
  }
  .nice-is-day-text{
      flex: 1;
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items: center;
      justify-content: flex-start;
  }
  .relative{
      display: flex;
      flex-direction: column;
      /* align-items: center; */
      width: 600px;
      height: 540px;
      background: #ffffff;
      box-shadow: 0 0 3px #000000;
      margin: auto;
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;
      /* box-shadow: #000000 1px 1px 1px 1px; */
      position: absolute;
      margin: auto;
      top: 0;
      bottom: 0;
      right: 0;
      left: 0;
      z-index: 1;
  }
  .operatTable{
    position: sticky;
    top: 0;
    z-index: 5;
    background: #fff;
    /* opacity: 0.5; */
  }
  .item_Excepts{
    display: flex;
      flex-direction: column;
      /* align-items: center; */
      width: 700px;
      height: 680px;
      background: #ffffff;
      box-shadow: 0 0 3px #000000;
      margin: auto;
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;
      /* box-shadow: #000000 1px 1px 1px 1px; */
      position: absolute;
      margin: auto;
      top: 0;
      bottom: 0;
      right: 0;
      left: 0;
      z-index: 1;
  }
  .Excepts-i-close{
        display: flex;
      /* flex: 0.1; */
      justify-content: flex-end;
      /* width: 30px;
      height: 30px; */
      cursor: pointer;
      /* background: #999; */
      color: #000000;
      font-size: 20px;
      margin-left: 670px;
  }
  .Excepts-i-close:hover{
    color: red;
  }
  .item_des_Excepts{
    display: flex;
      flex-direction: column;
      /* align-items: center; */
      width: 800px;
      height: 780px;
      background: #ffffff;
      box-shadow: 0 0 3px #000000;
      margin: auto;
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;
      /* box-shadow: #000000 1px 1px 1px 1px; */
      position: absolute;
      margin: auto;
      top: 0;
      bottom: 0;
      right: 0;
      left: 0;
      z-index: 1;
  }
  .item_des_Excepts_title{
    flex: 0.1;
    display: flex;
    /* background: red; */
  }
  .item_des_Excepts-operates{
    flex: 0.1;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    align-items: flex-end;
    justify-content: flex-start;
    margin-bottom: 5px;
  }
  .item_des_Excepts-operates>input{
    width: 100px;
    height: 30px;
    outline: none;
    border: none;
    cursor: pointer;
    /* margin: 5px; */
    /* border: 1px black solid; */
  }
  .item_des_Excepts-operates-reception{
    color: #fff;
    background-color: #67c23a;
    border-color: #67c23a;
  }
  .item_des_Excepts-operates-reception:hover{
      opacity: 0.7;
  }
  .item_des_Excepts-operates-check{
    color: #fff;
    background-color: #f56c6c;
    border-color: #f56c6c;
  }
  .item_des_Excepts-operates-check:hover{
    opacity: 0.7;
  }
  .item_des_Excepts-operates-cancellation{
    color: #fff;
    background-color: #e6a23c;
    border-color: #e6a23c;
  }
  .item_des_Excepts-operates-cancellation:hover{
    opacity: 0.7;
  }
  .item_des_Excepts-operates-delate{
    color: #fff;
    background-color: #e63c3c;
    border-color: #ef5959;
  }
  .item_des_Excepts-operates-delate:hover{
    opacity: 0.7;
  }
  .item_des_Excepts-item{
    flex: 1
  }
  .item-des-Excepts-i-close{
    flex: 0.2;
    display: flex;
    position: absolute;
    margin-top: 7px;
    color: black;
    font-size: 20px;
  }
  .item-des-Excepts-i-close:hover{
    color: red;
  }
</style>