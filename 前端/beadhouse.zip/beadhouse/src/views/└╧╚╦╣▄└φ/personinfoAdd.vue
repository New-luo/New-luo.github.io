<template>
  <el-dialog :title="dataForm.personId > 0 ? '修改' : '新增'" :visible.sync="centerDialogVisible" width="60%" center>
    <el-form :model="dataForm" ref="dataForm" inline label-width="100px" style="width:100%;">
      <el-row>
        <!-- 左侧内容 -->
        <el-col :span="12">
          <el-form-item prop="realName" label="姓名:">
            <el-input v-model="dataForm.realName" />
          </el-form-item>

          <el-form-item prop="sex" label="性别:">
            <el-input v-model="dataForm.sex" />
          </el-form-item> 

          <el-form-item prop="cardNo" label="身份证号:">
            <el-input v-model="dataForm.cardNo" />
          </el-form-item>

          <el-form-item prop="age" label="年龄:">
            <el-input v-model="dataForm.age" />
          </el-form-item>

          <el-form-item prop="mobile" label="手机号:">
            <el-input v-model="dataForm.mobile" />
          </el-form-item>

          <el-form-item prop="chairman" label="紧急联系人电话:">
            <el-input v-model="dataForm.chairman" />
          </el-form-item>

          <el-form-item prop="faceUrl" label="人脸图片:">
                <input type="file">
          </el-form-item>
        </el-col>
        <!-- 右侧内容 -->
        <el-col :span="12">

          <el-form-item prop="personType" label="人员类别:">
            <el-select v-model="personType" clearable>
              <el-option v-for="item in Typeoptions" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>              
          
                    <el-form-item prop="state" label="类别:">
            <el-select v-model="stateitm" clearable>
              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item> 

          <el-form-item prop="expireDate" label="入院时间:">
            <el-date-picker v-model="dataForm.expireDate" type="datetime" format="yyyy-MM-dd HH:mm:ss"
              value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择日期时间"></el-date-picker>
          </el-form-item>

          <el-form-item prop="inTime" label="离开时间:">
            <el-date-picker v-model="dataForm.inTime" type="datetime" format="yyyy-MM-dd HH:mm:ss"
              value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择日期">
            </el-date-picker>
          </el-form-item>

            <el-form-item prop="creater" label="创建者:">
            <el-input v-model="dataForm.creater" />
          </el-form-item>

          <el-form-item prop="remark" label="备注:">
            <el-input v-model="dataForm.remark" />
          </el-form-item>
;
        </el-col>
      </el-row>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="centerDialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="upload()">确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { list, add, getid } from '../../api/personinfo'
export default {
  name: 'PersoninfoAdd_',
  data() {
    return {
      stateitm: '',
      options: [
        {
          value: 1,
          label: '正常'
        },
        {
          value: 2,
          label: '欠费'
        },
                {
          value: 3,
          label: '离院'
        }
      ],
      personType:'',
       Typeoptions:[
        {value: '按年收费',label: '按年收费'},
        {value: '按月收费',label: '按月收费'}, 
        {value: '按日收费',label: '按日收费'},
        {value: '其他',label: '其他'},
      ], 
      dataForm: {
            personType:'', 
            state:'',
            personId:'',
            communityId:'',
            houseId:'',
            bedId:'',
            realName:'',
            sex:'',  
            cardNo:'',
            age:'',
            mobile:'',
            chairman:'',
            faceUrl:'',
            inTime:'',
            expireDate:'',
            creater:'',
            remark:'',

      },
      centerDialogVisible: false,
    }
  },
  created() {

  },
  methods: {
    init(id) {
      this.centerDialogVisible = true
      console.log(id)
      getid(id).then(res => {
        // alert("this")
        if (id > 0) {
          let {personId,bedId,personType,state,communityId,houseId,realName,sex,  cardNo,age,mobile,chairman,faceUrl,inTime,expireDate,creater,remark } = res.data[0];
          console.log("类别是：" + state);
          if (state == '1') {
            console.log("正常");
            this.stateitm = '正常';
          } else if(state == '2') {
            this.stateitm = '欠费';
          }else if(state=='3'){
            this.stateitm='离院'
          }
          this.dataForm = {
            personId,bedId,personType,state,communityId,houseId,realName,sex,  cardNo,age,mobile,chairman,faceUrl,inTime,expireDate,creater,remark
          };
        } else {
          this.dataForm.personId = 0;
          this.dataForm.bedId = '';
          this.dataForm.personType = '';
          this.dataForm.state = '';
          this.dataForm.communityId = '';
          this.dataForm.houseId = '';
          this.dataForm.realName = '';
          this.dataForm.sex = '';
          this.dataForm.cardNo = '';
          this.dataForm.age = '';
          this.dataForm.mobile = '';
          this.dataForm.chairman = '';
          this.dataForm.faceUrl = '';
          this.dataForm.inTime = '';
          this.dataForm.expireDate = '';
           this.dataForm.creater = '';
           this.dataForm.remark = '';
          this.stateitm = 1;
        }
      }).catch(err => {
        console.log(err)
        this.centerDialogVisible = false;
        this.$message.error('你没有修改数据的权限,请与系统管理员联系');
      });
    },
    handleDateTimeChange() {
      this.dataForm.visitTime = new Date(this.dataForm.visitTime);
    },


    upload(){
      if(this.stateitm == '正常'){
          this.stateitm = '1';
      }else if(this.stateitm == '欠费'){
          this.stateitm = '2';
      }else if(this.stateitm == '离院'){
        this.stateitm = '3';
      }
      console.log(this.stateitm);
      let formData = new FormData();
      formData.append('personId', this.dataForm.personId);
      formData.append('bedId', this.dataForm.bedId);
      formData.append('personType', this.dataForm.personType);
      formData.append('state', this.dataForm.stateitm);
      formData.append('communityId', this.dataForm.communityId);
      formData.append('houseId', this.dataForm.houseId);
      formData.append('realName', this.dataForm.realName);
      formData.append('sex', this.sex);
      formData.append('cardNo', this.cardNo);
      formData.append('age', this.age);
      formData.append('mobile', this.mobile);
      formData.append('chairman', this.chairman);
       formData.append('faceUrl', this.faceUrl);
       formData.append('inTime', this.inTime);
       formData.append('expireDate', this.expireDate);
       formData.append('creater', this.creater);
      formData.append('remark', this.dataForm.remark);
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          add(formData).then(res => {
            this.centerDialogVisible = false
            this.$message({
              message: res.msg,
              type: 'success'
            });
            this.$emit('refreshReturnData')
          }).catch(err => {
            this.$message.error('你没有新增数据的权限,请与系统管理员联系');
          });
        }
      })
    },
    handleAvatarSuccess(res, file) {
        this.imageUrl = URL.createObjectURL(file.raw);
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isLt2M = file.size / 1024 / 1024 < 2;


        if (!isJPG) {
          this.$message.error('上传头像图片只能是 JPG 格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!');
        }
        return isJPG && isLt2M;
      }
  }
  }
</script>
<style scoped>
  .avatar-uploader .el-upload {
    border: 1px dashed #000000;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>