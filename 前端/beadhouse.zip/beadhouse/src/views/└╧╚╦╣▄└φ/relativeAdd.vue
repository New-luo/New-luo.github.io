<template>
  <el-dialog :title="dataForm.relativeId > 0 ? '修改' : '新增'" :visible.sync="centerDialogVisible" width="60%" center>
    <el-form :model="dataForm" ref="dataForm" :rules="dataRule" inline label-width="100px" style="width:100%;">
      <el-row>
        <!-- 左侧内容 --> 
        <el-col :span="12">
          <el-form-item prop="personId" label="人员名称:">
            <el-select v-model="dataForm.personId" clearable filterable :disabled="disabledVisible" v-if="flag == true">
              <el-option v-for="(personinfo, index) in personinfoSelects[0]" :key="index" :label="personinfo.realName" :value="personinfo.personId"></el-option>
            </el-select>
            <el-input v-if="flag == false" v-model="realName" :disabled="true"></el-input>
            <!-- <el-input v-model="dataForm.personId" /> -->
          </el-form-item>

          <el-form-item prop="relativeName" label="亲属名称:">
            <el-input v-model="dataForm.relativeName" />
          </el-form-item>

          <el-form-item prop="typeName" label="亲属关系:">
            <el-input v-model="dataForm.typeName" />
          </el-form-item>
        </el-col>
        <!-- 右侧内容 -->
        <el-col :span="12">
          <el-form-item prop="mobile" label="联系电话:">
            <el-input v-model="dataForm.mobile" />
          </el-form-item>

          <el-form-item prop="addr" label="地址:">
            <el-input v-model="dataForm.addr" />
          </el-form-item>

          <el-form-item prop="remark" label="备注：">
            <el-input v-model="dataForm.remark" />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="centerDialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="upload()">确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { list, add, relativeById } from '../../api/relative'
export default {
  data() {
    return {
      dataForm: {
        relativeId: 0,
        personId: '',
        relativeName: '',
        typeName: '',
        mobile: '',
        addr: '',
        remark: '',
      },
      centerDialogVisible: false,
      disabledVisible: false,
      dataRule: {
        personId: [
          { required: true, message: '人员ID不能为空', trigger: 'blur' }
        ],
        relativeName: [
          { required: true, message: '亲属名称不能为空', trigger: 'blur' }
        ],
        mobile: [
          { required: true, message: '联系电话不能为空', trigger: 'blur' },
          { min: 8, max: 20, message: '联系电话必须在8~11位之间', trigger: 'blur' },
        ],
        typeName: [
          { required: true, message: '亲属关系不能为空', trigger: 'blur' },

        ],
        remark: [
          { required: true, message: '备注不能为空', trigger: 'blur' },
        ],
        addr: [
          { required: true, message: '地址不能为空', trigger: 'blur' },
        ],
      },
      personinfoSelects: [],
      flag: true,
      realName: ''
    };

  },
  created() {

  },
  methods: {
    init(id,personinfoSelect) {
      console.log('id:', id)
      if (id === 0) {
          this.flag = true;
          this.centerDialogVisible = true;
          const personinfos = personinfoSelect;
          this.personinfoSelects.push(personinfos);
          // console.log(this.personinfoSelects.splice(0,1));
          // this.dataForm.personId = this.personinfoSelects[0][0].personId
          this.dataForm = {
              relativeId: 0,
              personId: '',
              relativeName: '',
              typeName: '',
              mobile: '',
              addr: '',
              remark: '',
          }        
      }else{
          this.flag = false;
          this.centerDialogVisible = true    
          relativeById(id).then(res => {
            console.log(res.data.personify[0].realName);

            this.dataForm = res.data.relative 
            this.realName = res.data.personify[0].realName
            
          }).catch(err => {
            console.log(err)
            this.centerDialogVisible = false;
            this.$message.error('你没有修改数据的权限,请与系统管理员联系');
          });
      }


    },
    handleDateTimeChange() {
      this.dataForm.visitTime = new Date(this.dataForm.visitTime);
    },


    upload() {
      let formData = new FormData();
      formData.append('relativeId', this.dataForm.relativeId);
      formData.append('personId', this.dataForm.personId);
      formData.append('relativeName', this.dataForm.relativeName);
      formData.append('typeName', this.dataForm.typeName);
      formData.append('mobile', this.dataForm.mobile);
      formData.append('addr', this.dataForm.addr);
      formData.append('remark', this.dataForm.remark);
      this.$refs['dataForm'].validate((valid) => {
        if (valid) {
          add(formData).then(res => {
            this.centerDialogVisible = false
            this.$message({
              message: res.msg,
              type: 'success'
            });
            this.$emit('refreshReturnData')
          }).catch(err => {
            this.$message.error('你没有新增数据的权限,请与系统管理员联系');
          });
        }
      })
    }
  }
};
</script>