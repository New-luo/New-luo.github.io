<template>
    <div class="mai">
        <el-input
        placeholder="请输入内容"
        v-model="like"
        clearable>
        </el-input>
        <el-button @click="init()" style="width: 200px">搜索</el-button>
        <el-button @click="isDisplayed=true" style="width: 200px">搜索</el-button>
        <el-table>
            <el-table-column prop="communityId" label="养老院id" width="180"> </el-table-column>
            <el-table-column prop="bedId" label="床位号" width="180"> </el-table-column>
            <el-table-column prop="realName" label="姓名" width="180"> </el-table-column>
            <el-table-column prop="sex" label="性别" width="180"> </el-table-column>
            <el-table-column prop="cardNo" label="身份证号" width="180"> </el-table-column>
            <el-table-column prop="age" label="年龄" width="180"> </el-table-column>
            <el-table-column prop="mobile" label="手机号" width="180"> </el-table-column>
            <el-table-column prop="chairman" label="紧急联系人电话" width="180"> </el-table-column>
            <el-table-column prop="faceUrl" label="人脸图片" width="180"> </el-table-column>
            <el-table-column prop="personType" label="人员类别" width="180"> </el-table-column>
            <el-table-column prop="state" label="类别" width="180"> </el-table-column>
            <el-table-column prop="inTime" label="入院时间" width="180"> </el-table-column>
            <el-table-column prop="expireDate" label="离开时间" width="180"> </el-table-column>
            <el-table-column prop="creater" label="创建者" width="180"> </el-table-column>
            <el-table-column prop="remark" label="备注" width="180"> </el-table-column>
        </el-table>
        <div class="block">
    <!-- <span class="demonstration">完整功能</span> -->
            <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pager.curPage"
                :page-sizes="[5, 10, 15, 20]"
                :page-size="pager.size"
                layout="total, sizes, prev, pager, next, jumper"
                :total="pager.total">
            </el-pagination>
        </div>
        <div class="addo" v-if="isDisplayed">
            <div>
                <!-- 用户id:<input type="text" v-model="personId"> -->
            </div>

            <div>
                <!-- 养老院id:<input type="text" v-model="communityId"> -->
            </div>

            <div>
                <!-- 房号:<input type="text" v-model="houseId"> -->
            </div>

            <div>
                <!-- 床位号:<input type="text" v-model="bedId"> -->
            </div>
            
            <div>
                姓名:<input type="text" v-model="realName">
            </div>
            
            <div>
                性别:<input type="text" v-model="sex">
            </div>
            
            <div>
                身份证号:<input type="text" v-model="cardNo">
            </div>
            
            <div>
                年龄:<input type="text" v-model="age">
            </div>
            
            <div>
                手机号:<input type="text" v-model="mobile">
            </div>
            
            <div>
                紧急联系人电话:<input type="text" v-model="chairman">
            </div>
            
            <div>
                人脸图片:<input type="text" v-model="faceUrl">
            </div>
            
            <div>
                <!-- 人员类别:<input type="text" v-model="personType"> -->
<el-select v-model="personType" placeholder="请选择">
  <el-option
    v-for="item in options"
    :key="item.value"
    :label="item.label"
    :value="item.value">
  </el-option>
</el-select>
            </div>
            
            <div>
                类别:<input type="text" v-model="state">
            </div>
            
            <div>
                入院时间:  <div class="block">
    <span class="demonstration">默认</span>
    <el-date-picker v-model="expireDate" type="datetime" value-format="yyyy-MM-dd HH:mm:ss" style="width: 190px;"></el-date-picker>
  </div>
            </div>
                        
            <div>
                离开时间:  <div class="block">
    <span class="demonstration">默认</span>
    <el-date-picker v-model="inTime" type="datetime" value-format="yyyy-MM-dd HH:mm:ss" style="width: 190px;"></el-date-picker>
  </div>
            </div>
                        
            <div>
                创建者:<input type="text" v-model="creater">
            </div>
                        
            <div>
                备注:<input type="text" v-model="remark">
            </div>
        <input type="button" value="确定" @click="Add()">
        </div>
    </div>
</template>
<script>
import axios from 'axios';
export default {
    name: "Personinfo_",
    data(){
        return{
        options: [{
          value: '按年收费',
          label: '按年收费'
        }, {
          value: '按月收费',
          label: '按月收费'
        }, {
          value: '按日收费',
          label: '按日收费'
        },{
          value: '其他',
          label: '其他'
        },], 
        personId:'',
        communityId:'',
        houseId:'',
        bedId:'',
        realName:'',
        sex:'',  
        cardNo:'',
        age:'',
        mobile:'',
        chairman:'',
        faceUrl:'',
        personType:'',
        state:'',
        inTime:'',
        expireDate:'',
        creater:'',
        remark:'',
            personinfoData:[],
            like: "",
            pager:{
                curPage: 1,
                size: 5,
                total: 0
            },
            isDisplayed: false,
        }

    },
    
    methods:{
        Add(){
            let url ="http://localhost:8088/systeam/open-personinfo/add-personinfo";
            axios({
            url: url,
            method: "post",
                params:{
                // 'personId':this.personId,
                // 'communityId':this.communityId,
                // 'houseId':this.houseId,
                // 'bedId':this.bedId,
                'realName':this.realName,
                'sex':this.sex,
                'cardNo':this.cardNo,
                'age':this.age,
                'mobile':this.mobile,
                'chairman':this.chairman,
                'faceUrl':this.faceUrl,
                'personType':this.personType,
                'state':this.state,
                'inTime':this.inTime,
                'expireDate':this.expireDate,
                'creater':this.creater,
                'remark':this.remark,
                    }
            }).then(res=>{
                this.$message({
                    showClose: true,
                    message: '新增成功',
                    type: 'success'
                });
                this.isDisplayed = false
                this.init();
            }).catch(err=>{
                console.error(err);
                this.$message(err)
            })
        },
        init(){
            let url = "http://localhost:8088/systeam/open-personinfo/select-personinfo";
            axios({
                url: url,
                method: "post",
                params:{
                    "curPage": this.pager.curPage,
                    "size": this.pager.size,
                    "like": this.like
                },
            }).then(res =>{
                console.log(res.data.personifyList);
                this.personinfoData = res.data.list;
                this.pager.total = res.data.count;
            }).catch(error=>{
                this.$message.error("错误")
            })
        },
        handleSizeChange(val) {
            this.pager.size = val;
            console.log(`每页 ${val} 条`);
            this.init();
        },
        handleCurrentChange(val) {
            this.pager.curPage = val;
            console.log(`当前页: ${val}`);
            this.init();
        }
    },
    created(){
        this.init();
    }

}
</script>
<style scoped>
*{
    margin: 0%;
}
.addo{
    width: 400px;
    height: 500px;
    background: rgb(246, 242, 242);
  border: 1px solid black;
  position: absolute;
  left:100px ;
  top:100px ;
}
</style>