<template>
    <div  v-permission="'105'">
        <el-row :gutter="0" type="flex" class="header-bar">
            <el-col :span="18" :offset="0">
                <el-row type="flex">
                    <el-col :span="1.5">
                        <el-button @click="addWindow"  v-permission="'103'" type="primary" class="add">添加<i class="el-icon-plus el-icon--right"></i></el-button>
                    </el-col>
                </el-row>
            </el-col>
            <el-col :span="6">
                <el-input placeholder="请输入内容" v-model="params.search" class="search">
                    <el-button slot="append" icon="el-icon-search" @click="search"></el-button>
                </el-input>
            </el-col>
        </el-row>

        <el-table :data="supplierData" style="width: 100%">
            <el-table-column prop="supplierId" label="ID"/>
            <el-table-column prop="supplierName" label="供应商"/>
            <el-table-column label="分类" prop="suppliers">
  <template slot-scope="scope">
    <span v-if="scope.row.suppliers === '0'">药品供应商</span>
    <span v-else-if="scope.row.suppliers === '1'">货物供应商</span>
  </template>
</el-table-column>
            <el-table-column prop="contact" label="联系人"/>
            <el-table-column prop="mobile" label="电话"/>
            <el-table-column prop="address" label="地址"/>
            <el-table-column prop="remark" label="备注"/>
            <el-table-column label="操作" width="210%" fixed="right">
            <template slot-scope="scope">
                <el-button @click="editInit(scope.row)"  v-permission="'106'" type="primary" icon="el-icon-edit">更改</el-button>
                <el-button @click="del(scope.row.supplierId)" type="primary"  v-permission="'104'" icon="el-icon-delete">删除</el-button>
            </template>
            </el-table-column>
        </el-table>
        <div class="block" style="margin-top: 1%;">
            <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="params.curPage"
            :page-sizes="pageSizes"
            :page-size="params.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
            </el-pagination>
        </div>
        <!-- 编辑窗 -->
        <el-dialog title="编辑" :visible.sync="dialogFormVisible">
            <el-form :model="form">
                <el-form-item label="供应商：" class="form-row">
                    <el-input v-model="form.supplierName" autocomplete="off" clearable></el-input>
                </el-form-item>
                <el-form-item label="联系人：" class="form-row">
                    <el-input v-model="form.contact" clearable></el-input>
                </el-form-item>
                <el-form-item label="电话：" class="form-row">
                    <el-input v-model="form.mobile" clearable></el-input>
                </el-form-item>
                <el-form-item label="地址：" class="form-row">
                    <el-input v-model="form.address" clearable></el-input>
                </el-form-item>
                <el-form-item label="备注：" class="form-row">
                    <el-input v-model="form.remark" clearable></el-input>
                </el-form-item>
            <el-form-item label="供应商：" class="form-row">
  <el-select v-model="form.suppliers" clearable style="margin-left:-500px">
    <el-option label="药品供应商" value="0"></el-option>
    <el-option label="货物供应商" value="1"></el-option>
  </el-select>
</el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="update" :loading="loading" v-if="actType">保 存</el-button>
                <el-button type="primary" @click="add" :loading="loading" v-else>确 认</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
    import '../../resourcces/css/house.css'
    import {list,insert,update,del} from '../../api/publicApi'
    export default{
        name: 'Supplier_',
        data(){
            return{
                supplierData: [],
                total: 0,
                pageSizes: [10,20,30,40],
                params: {
                    "pageSize": 10,
                    "curPage": 1,
                    "search": ''
                },
                dialogFormVisible: false,
                form: {
                    supplierName:'',
                    contact: '',
                    mobile: '',
                    address: '',
                    remark: '',
                    suppliers:'0',
                },
                actType: false,
                loading: false
            }
        },
        created(){
            this.init(this.params)
        },
        methods: {
            init(params){
                list(params,'supplier/list').then(res=>{
                    console.log(res)
                    this.supplierData = res.list
                    console.log(this.supplierData)
                    this.total = res.total
                }).catch(err=>{
                    this.$message({
                        showClose: true,
                        message: err,
                        type: 'error'
                    })
                })
            },
            editInit(val){
                console.log(val)
                this.actType = true
                this.form.supplierId = val.supplierId //*!
                this.form.supplierName = val.supplierName
                this.form.contact = val.contact
                this.form.mobile = val.mobile
                this.form.address = val.address
                this.form.remark = val.remark
                this.form.suppliers = val.suppliers
                this.dialogFormVisible = true
            },
            addWindow(){
                this.actType = false
                this.dialogFormVisible = true
            },
            add(){
                console.log(this.form)
                insert(this.form,'supplier/insert').then(res => {
                    console.log(res)
                    if(res.addChanged){
                        this.loading = false
                        this.dialogFormVisible = false
                        this.init(this.params)
                        this.$message({
                            showClose: true,
                            message: '添加成功！',
                            type: 'success'
                        })
                    }
                }).catch(err => {
                    this.loading = false
                    this.dialogFormVisible = false
                    this.$message({
                        showClose: true,
                        message: err,
                        type: 'error'
                    })
                })
            },
            del(id){
                this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    del(id,'supplier/del').then(res => {
                        var params = this.params
                        var curPageSize = this.supplierData.length
                        params.curPage = curPageSize == 1 ? params.curPage - 1 : params.curPage
                        this.init(params)
                        this.$message({
                            type: 'success',
                            message: '删除成功!',
                            showClose: true
                        })
                    }).catch(err => {
                        this.$message({
                            showClose: true,
                            message: err,
                            type: 'error'
                        })
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除',
                        showClose: true
                    });          
                });
            },
            update(){
                this.loading = true
                update(this.form,'supplier/update').then(res => {
                    if(res.changed){
                        this.loading = false
                        this.dialogFormVisible = false
                        this.init(this.params)
                        this.$message({
                            showClose: true,
                            message: '更改成功！',
                            type: 'success'
                        })
                    }
                }).catch(err => {
                    this.loading = false
                    this.dialogFormVisible = false
                    this.$message({
                        showClose: true,
                        message: err,
                        type: 'error'
                    })
                    console.log(err)
                })
            },
            search(){
                this.params.curPage = 1
                this.init(this.params)
            },
            handleSizeChange(val) {
                this.params.pageSize = val
                this.init(this.params)
            },
            handleCurrentChange(val) {
                this.params.curPage = val
                this.init(this.params)
            },
            test(){
                this.form.houseId = this.houseId
                console.log('from:',this.form)
                console.log(this.supplierData)
            }
        }
    }
</script>