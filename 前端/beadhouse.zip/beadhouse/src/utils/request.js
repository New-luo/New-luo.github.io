import axios from 'axios'
import Cookie from 'js-cookie'

// 创建axios实例
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API , // api的base_url
  timeout: 300000, // 请求超时时间
  headers:{
    'Content-Type':'application/json'
  }
})

// request拦截器
service.interceptors.request.use(
  config => {
    config.headers['token'] = Cookie.get("token")
    console.log("url:",config.url)
    return config
  },
  error => {
    console.log(error)
    return Promise.reject(error)
  }
)

// response拦截器
service.interceptors.response.use(
  response => {
    const res = response.data
    const config = response.config
    // 二进制流处理
    if (config && config.responseType === 'blob') {
      return response
    }
    if (res.code === 401) {
      alert('登录状态已过期，请您重新登录');
      // this.$router.push('/login');
      router.replace('/login');
    }
     else if (res.code !== 200) {
      console.log('请求异常：')
      // this.$message('请求异常')
    } else {
      console.log('请求地址：', response.config.url)
    }
    return res
  },
  error => {
    console.log('请求异常：' + error)
    return Promise.reject(error)
  }
)

export default service
