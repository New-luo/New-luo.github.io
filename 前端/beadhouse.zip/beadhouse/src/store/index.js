import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex);
export default new Vuex.Store({
  state: {
    name: '一开始的名字，哪里都可以看见',
    userName: '用户登录了的用户名',
    password: '',
    count: 0,
    flag: false,
    todos: [
      { id: 1, text: '已登录', done: true },
      { id: 2, text: '未登录', done: false }
    ],
    loggedIn: false
  },
  getters: {
    doneTodos: state => {
      if (state.loggedIn) {
        return state.todos.filter(todo => todo.id === 1);
      } else {
        return state.todos.filter(todo => !todo.done);
      }
    }
  },
  actions: {
    text(context, param) {

    },
    add(context) {
      context.commit('increment');
    }
  },
  mutations: {
    test(state) {
      console.log(state);
    },
    increment(state) {
      state.count++;
    },
    setUserName(state, param) {
      state.userName = param;
      state.flag = true;
    },
    setPassWord(state, param) {
      state.password = param;
      state.flag = true;
    },
    setLoggedIn(state, loggedIn) {
      state.loggedIn = loggedIn;
      console.log(state);
    }
  }
});
