import Vue from 'vue'
import VueRouter from 'vue-router'


Vue.use(VueRouter)
const routes=[
    // {
    //     path: '/',
    //     name:'ht',
    //     component: () =>import('../views/login/user.vue')
    // },
    // {
    //     path: '/',
    //     component: () =>import('../views/index.vue')
    // },
    {
        path: '/',
        name:'ht',
        component: () =>import('@/views/admin'),

        children: [
            {
                path: '/1',
                name:'1',
                component: () =>import('../views/index2.vue'),
            },

            {
              path: '/vue1',
              component: () =>import('../views/采购清单/货物出库/index.vue')
          },
          {
            path: '/3-1',
            component: () =>import('../views/接待管理/接待登记/Reception')
          },
          {
            path: '/3-2',
            component: () =>import('../views/老人管理/relative')
          },
          {
            path: '/3-3',
            component: () =>import('../views/老人管理/personinfom')
          },
          {
            path: '/4-1',
            component:  () =>import('../views/床位管理/house.vue')
          },
          {
            path: '/4-3',
            component: () =>import('../views/床位管理/bedmanage.vue')
          },
          {
            path: '/4-4',
            component: () =>import('../views/床位管理/stayinfo.vue')
          },
          {
            path: '/4-2',
            component: ()=>import('../views/房间资料/index.vue')
          },
          {
            path: '/5-1',
            component: ()=>import('../views/用户管理/user/user.vue')
          },
          {
            path: '/5-2',
            component: ()=>import('../views/用户管理/角色列表.vue')
          },
          {
            path: '/6-1',
            component: () =>import('../views/采购清单/货物出库/index.vue')
          },
          {
            path: '/6-2',
            component: () =>import('../views/仓库管理/products.vue')
          },
          {
            path: '/6-3',
            component: () =>import('../views/采购清单/index.vue')
          },
          {
            path: '/6-4',
            component: () =>import('../views/采购清单/货物列表/index.vue')
          },
          {
            path: '/6-5',
            component: () =>import('../views/采购清单/货物入库/index.vue')
         }, 
         {
          path: '/6-6',
          component: () =>import('../views/采购清单/货物出库/index.vue')
       }, 
       {
        path: '/6-7',
        component: () =>import('../views/采购清单/货物领用信息/index.vue')
     }, 
          {
            path: '/6-8',
            component: () =>import('../views/采购清单/货物仓库/index.vue')
         },  
          {
            path: '/7-2',
            component: () =>import('../views/药品管理/药品分类/drugs.vue')
          },
          {
            path: '/7-3',
            component: () =>import('../views/药品管理/药品信息/Drug.vue')
          },
          {
            path: '/7-4',
            component: () =>import('../views/采购清单/药品列表/index.vue')
          },
          {
            path: '/7-5',
            component: () =>import('../views/采购清单/药品入库/index.vue')
          },
          {
            path: '/7-6',
            component: () =>import('../views/采购清单/药品出库/index.vue')
          },
          {
            path: '/7-7',
            component: () =>import('../views/采购清单/药品领用信息/index.vue')
          },
          {
            path: '/7-8',
            component: () =>import('../views/采购清单/药品仓库/index.vue')
          },
          {
            path: '/9',
            component: () =>import('../views/supplier/index.vue')
          },
          {
            path: '/10',
            component: () =>import('../views/病情登记/index.vue')
          },
          {
            path: '/11',
            component: () =>import('../views/外出登记/outRecord.vue')
          },
          {
            path: '/12',
            component: () =>import('../views/老人管理/personinfom')
         }, 
          ]
    },



    {
        path: '/后台',
        component: () => import('../views/采购清单/货物列表/index')
    },
     {
        path: '/11',
        component: () =>import('../views/采购清单/货物出库/index.vue')
     },     
      
     {
        path: '/14',
        component: () =>import('../views/采购清单/货物领用信息/index.vue')
     },     
     {
        path: '/15',
        component: () =>import('../views/采购清单/药品仓库/index.vue')
     },     
     {
        path: '/16',
        component: () =>import('../views/采购清单/货物仓库/index.vue')
     },    
     {
        path: '/ck',
        component: () =>import('../views/仓库管理/products.vue')
     },

     {
        path: '/10',
        component: () =>import('../views/用户管理/角色列表.vue')
     },
     
     {
        path: '/13',
        component: () =>import('../views/用户管理/user/user.vue')
     },
     {
        path: '/login',
        component: () =>import('../views/login/login.vue')
    }, 

    {
        path: '/12',
        component: () =>import('../views/接待管理/接待登记/Reception.vue')
     },

      {
        path: '/ht',
        component: () =>import('../views/index.vue')
     },
    {
        path: '/bedmanage',
        component: () =>import('../views/床位管理/bedmanage.vue')
    },
    {
        path: '/hou',
        component: () =>import('../views/房间资料/index.vue')
    },
    {
        path:'/Relative',
        component: () =>import('../views/老人管理/relative.vue')
    },
    {
        path: '/house',
        component: () =>import('../views/床位管理/house.vue')
    },
    {
        path: '/test',
        component: () => import('../views/床位管理/test.vue')
    },
    {
        path: '/personinfo',
        component: () =>import('../views/老人管理/personinfom.vue')
    },
    {
        path: '/index',
        component: () =>import('../views/采购清单/index.vue')
    },
    {
        path: '/Stayinfo',
        component: () =>import('../views/床位管理/stayinfo.vue')
    },
    {
        path: '/admin',
        component: () =>import('@/views/admin')
    },
    {
        path: '/situation',
        component: () =>import('../views/病情登记/index.vue')
    },
    {
        path: '/OutRecord',
        component: () =>import('../views/外出登记/outRecord.vue'),
        meta: {
            requiresAuth: true
        }
    },
    {
        path: '/Products',
        component: () =>import('../views/仓库管理/products.vue')
    },
    {
        path: '/Storage',
        component: () =>import('../views/仓库管理/仓库信息/storage.vue')
    },
    {
        path: '/Talktoeachother',
        component: () =>import('../views/外出登记/Talktoeachother.vue'),
        meat: {
            requiresAuth: true
        }
    },

    {
        path: '/supplier',
        component: () =>import('../views/ai.vue')
    }

    // {
    //     path: 'bedmanage',
    //     component: () =>import('../views/仓库管理/bedmanage.vue')
    // },
    // {
    //     path: 'bedmanage',
    //     component: () =>import('../views/安全管理/bedmanage.vue')
    // },
    // {
    //     path: 'bedmanage',
    //     component: () =>import('../views/老人管理/bedmanage.vue')
    // },
    // {
    //     path: 'bedmanage',
    //     component: () =>import('../views/费用管理/bedmanage.vue')
    // },
    // {
    //     path: 'bedmanage',
    //     component: () =>import('../views/接待管理/bedmanage.vue')
    // },
]

export default new VueRouter({
    routes
})

// VueRouter.beforeEach((to, from, next) => {
//     const flag = this.$store.state.flag;
//     if (to.path === '/Talktoeachother') {
//       next()
//     } else {
//       if (flag) {
//         next()
//       } else {
//         next({ path: '/Talktoeachother' })
//       }
//     }
// })
