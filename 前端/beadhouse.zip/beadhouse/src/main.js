import Vue from 'vue'
import App from './App.vue'
import router from './router'
import '@/directive/permission.js'
//导入Vuex
import store from './store'
//全局引入
import Cookie from 'js-cookie'

//引入ElementUI组件
import ElementUI from 'element-ui'
//引入ElementUI的css样式表
import 'element-ui/lib/theme-chalk/index.css'



//其他页面需要使用Cookie是，使用$Cookie
Vue.prototype.$Cookie = Cookie
Vue.config.productionTip = false
Vue.use(ElementUI)

new Vue({
  router,
  store,
  render: function (h) { return h(App) },
}).$mount('#app')
